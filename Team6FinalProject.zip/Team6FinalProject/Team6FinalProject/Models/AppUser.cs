﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class AppUser : IdentityUser
    {

        [Required(ErrorMessage = "First name is required.")]
        [Display(Name = "First Name")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        [Display(Name = "Full Name")]
        public String FullName {
            get { return FirstName + " " + LastName; }
        }


        [Required(ErrorMessage = "Street address is required.")]
        [Display(Name = "Street Address")]
        public String StreetAddress { get; set; }

        [Required(ErrorMessage = "City is required.")]
        [Display(Name = "City")]
        public String City { get; set; }

        [Required(ErrorMessage = "State is required.")]
        [Display(Name = "State")]
        public String State { get; set; }

        [Required(ErrorMessage = "Zip Code is required.")]
        [Display(Name = "Zip Code")]
        public String ZipCode { get; set; }
        public String MiddleInitial { get; set; }

        //[Display(Name = "Birthday")]
        //edited birthday to be a string because seeded it's a string 
        public string Birthday { get; set; }

        //For disabling a user 

        public bool IsDisabled { get; set; }// = false;

        public List<Order> Orders { get; set; }

        public List<CreditCard> CreditCards { get; set; }
        [InverseProperty("Author")]
        public List<Review> ReviewsWritten { get; set; }
        [InverseProperty("Approver")]
        public List<Review> ReviewsApproved { get; set; }

        public AppUser()
        {
            if (CreditCards == null)
            {
                CreditCards = new List<CreditCard>();
            }
        }
    }

}
