﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    public class Procurement
    {
        public Int32 ProcurementID { get; set; }

        [Display(Name = "Procurement Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime ProcurementDate { get; set; }

        [Display(Name = "Procurement Orderer")]
        public String ProcurementOrderer { get; set; }

        [Display(Name = "Procurement Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal ProcurementOrderTotal
        {
            get { return ProcurementDetails.Sum(r => r.ProcurementExtendedBookCost); }
        }

        public Boolean IsPending { get; set; }

        public AppUser AppUser { get; set; }

        public List<ProcurementDetail> ProcurementDetails { get; set; }

        public Procurement()
        {
            if (ProcurementDetails == null)
            {
                ProcurementDetails = new List<ProcurementDetail>();
            }
        }
    }

}
