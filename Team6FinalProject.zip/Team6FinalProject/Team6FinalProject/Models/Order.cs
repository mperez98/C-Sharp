﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class Order
    {
        public const Decimal SALES_TAX = 0.00825m;

        public Int32 OrderID { get; set; }

        [Display(Name = "Order Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime OrderDate { get; set; }


        [Display(Name = "Order Subtotal")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderSubtotal
        {
            get { return OrderDetails.Sum(od => od.ExtendedPrice); }
        }


        [Display(Name = "Order Quantity")]
        public Decimal OrderQuantity
        {
            get { return OrderDetails.Sum(od => od.Quantity); }
        }

        /* [Display(Name = "Sales Tax")]
         [DisplayFormat(DataFormatString = "{0:C}")]
         public Decimal SalesTax
         {
             get { return OrderSubtotal * SALES_TAX; }
         } */

        [Display(Name = "Shipping")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Shipping { get; set; }


        [Display(Name = "Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderTotal
        {
            get { return OrderSubtotal + Shipping; }
        }

        public Decimal AfterCouponOrderTotal { get; set; }

        [Display(Name = "Credit Card Used")]
        public CreditCard CreditCardUsed { get; set; }


        [Display(Name = "Pending?")]
        public Boolean IsPending { get; set; }

        public List<OrderDetail> OrderDetails { get; set; }
        public AppUser AppUser { get; set; }
        public Coupon Coupon { get; set; }

        public Order()
        {
            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }

}
