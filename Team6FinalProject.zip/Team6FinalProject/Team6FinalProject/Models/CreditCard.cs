﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class CreditCard
    {
        public Int32 CreditCardID { get; set; }

        [Display(Name = "Credit Card Number")]
        [Range(16, 16, ErrorMessage = "Credit Card must be 16 digits")]
        public string Card { get; set; }

        [Display(Name = "Type of Credit Card (Visa, American Express, Discover, MasterCard)")]
        public string CreditCardType { get; set; }

        //Navigational 
        public AppUser AppUser { get; set; }

    }

}
