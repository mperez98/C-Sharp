﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ProcurementDetail
    {
        public Int32 ProcurementDetailID { get; set; }

        [Display(Name = "Copies To Order")]
        [DefaultValue(5)]
        [Range(0, 1000000, ErrorMessage = "Copies to order must be greater than 0")]
        public Decimal CopiesToOrder { get; set; }

        [Range(0, 1000000, ErrorMessage = "Book Cost must be greater than 0")]
        [Display(Name = "Procurement Book Cost")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal ProcurementBookCost { get; set; }


        [Range(0, 10000000, ErrorMessage = "Price must be greater than 0!")]
        [Display(Name = "Procurement Extended Book Cost")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal ProcurementExtendedBookCost { get; set; }

        [Display(Name = "Quantity")]
        [Range(1, 10000000, ErrorMessage = "Quantity must be greater than 1")]
        public Int32 Quantity { get; set; }

        public Boolean IsReceived { get; set; }

        public Procurement Procurement { get; set; }

        public Book Book { get; set; } 
    }

}
