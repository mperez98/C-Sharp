﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class Genre
    {
        public Int32 GenreID { get; set; }

        [Required(ErrorMessage = "Genre Name is required.")]
        [Display(Name = "Genre Name")]
        public String GenreName { get; set; }

        public List<Book> Books { get; set; }
    }

}
