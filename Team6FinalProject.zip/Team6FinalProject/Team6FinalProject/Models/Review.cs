﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    public class Review
    {
        public Int32 ReviewID { get; set; }

        [Display(Name = "Review Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime ReviewDate { get; set; }

        [Display(Name = "Rating")]
        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5")]
        public Decimal Rating { get; set; }

        [Display(Name = "Is Review Approved?")]
        public bool IsApproved { get; set; }

        [Display(Name = "Is Review Pending?")]
        public bool IsPending { get; set; }

        [Display(Name = "Written Review")]
        [MaxLength(100)] //review must be less than 100 characters 
        public String WrittenReview { get; set; }

        public AppUser Author { get; set; }
        public AppUser Approver { get; set; }
        public  Book Book { get; set; }

    }

}
