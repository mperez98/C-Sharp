﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Team6FinalProject.Models;
using Microsoft.AspNetCore.Identity;

// Change this namespace to match your project
namespace Team6FinalProject.Models
{
    public class RoleEditModel
    {
        public IdentityRole Role { get; set; }
        public IEnumerable<AppUser> Members { get; set; }
        public IEnumerable<AppUser> NonMembers { get; set; }
    }

    public class RoleModificationModel
    {
        [Required]
        public string RoleName { get; set; }
        public string[] IdsToAdd { get; set; }
        public string[] IdsToDelete { get; set; }
        public string[] IdsToDisable { get; set; }
        public string[] IdsToEnable { get; set; }
    }

    public class DisableAccount
    {
        public List<AppUser> EnabledCustomer { get; set; }
        public List<AppUser> DisabledCustomer { get; set; }
        public List<AppUser> EnabledEmployee { get; set; }
        public List<AppUser> DisabledEmployee { get; set; }
        public List<AppUser> EnabledManager { get; set; }
        public List<AppUser> DisabledManager { get; set; }

       
        public List<AppUser> Customers { get; set; }
        public List<AppUser> Managers { get; set; }
        public List<AppUser> Employees { get; set; }

        public DisableAccount()
        {
            if (EnabledCustomer == null)
            {
                EnabledCustomer = new List<AppUser>();
            }

            if (DisabledCustomer == null)
            {
                DisabledCustomer = new List<AppUser>();
            }


            if (EnabledEmployee == null)
            {
                EnabledEmployee = new List<AppUser>();
            }

            if (DisabledEmployee == null)
            {
                DisabledEmployee = new List<AppUser>();
            }


            if (EnabledManager == null)
            {
                EnabledManager = new List<AppUser>();
            }

            if (DisabledManager == null)
            {
                DisabledManager = new List<AppUser>();
            }




        }
    }

    
}