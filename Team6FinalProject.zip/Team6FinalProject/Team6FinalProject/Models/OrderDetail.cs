﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class OrderDetail
    {
        public Int32 OrderDetailID { get; set; }

        [Display(Name = "Quantity")]
        [Range(1, 10000000, ErrorMessage = "Quantity must be greater than 1")]
        public Int32 Quantity { get; set; }

        [Display(Name = "Price Paid")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal PricePaid { get; set; }

        [Display(Name = "Extended Price")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal ExtendedPrice { get; set; }

        public Order Order { get; set; }
        public Book Book { get; set; }
    }

}
