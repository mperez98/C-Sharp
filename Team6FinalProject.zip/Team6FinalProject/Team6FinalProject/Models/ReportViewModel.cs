﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System;

namespace Team6FinalProject.Models
{

    // It should display Customer Name, Email, total quantity, 
    //total revenue, total weighted average cost, and profit margin for each customer
    public class ReviewViewModel : AppUser
    {

        [Display(Name = "Employee Username")]
        public string EmployeeUsername { get; set; }

        [Required]
        [Display(Name = "Full Name")]
        public string ReviewerName { get; set; }

        [Display(Name = "Number of Reviews Approved")]
        public Int32 NumApproved { get; set; }

        [Display(Name = "Number of Reviews Rejected")]
        public Int32 NumRejected { get; set; }

    }


    //It should display Customer Name, Email, total quantity,
    //total revenue, total weighted average cost, 
    //and profit margin for each customer

    public class CustomerViewModel : AppUser
    {

        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Display(Name = "Customer Email Address")]
        public string CustomerEmail { get; set; }

        [Display(Name = "Total Quantity")]
        public Int32 CustomerQuantity { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Revenue")]
        public Decimal CustomerRevenue { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Weighted Average Cost")]
        public Decimal CustomerWAC { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Profit Margin")]
        public Decimal CustomerProfitMargin { get; set; }

    }


    public class TotalViewModel : OrderDetail
    {
    
        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Revenue")]
        public Decimal TotalRevenue { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Cost")]
        public Decimal TotalCost { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Total Profit")]
        public Decimal TotalProfit { get; set; }

    }

    public class InventoryView : Book
    {

        [Display(Name = "Book Title")]
        public String BookTitle { get; set; }

        [Display(Name = "Number of Books")]
        public Decimal NumBooks { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Average Cost of Book")]
        public Decimal BookAvgCost { get; set; }

    }

    public class OrderView : OrderDetail
    {

        [Display(Name = "Order ID")]
        public Int32 OrderID { get; set; }

        [Display(Name = "Order Quantity")]
        public Decimal OrderQuantity { get; set; }

        [Display(Name = "Customer Name")]
        public String CustomerName { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Order Subtotal")]
        public Decimal OrderSubtotal { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Order Average Cost")]
        public Decimal OrderAverageCost { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        [Display(Name = "Order Profit Margin")]
        public Decimal OrderProfitMargin { get; set; }

    }


}
