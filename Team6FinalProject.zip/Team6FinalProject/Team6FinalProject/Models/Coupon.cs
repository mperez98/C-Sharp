﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    public class Coupon
    {
        public Int32 CouponID { get; set; }
        // new added

        [Display(Name = "Coupon Code")]
        [Range(1, 20, ErrorMessage = "Coupon Code must be length 1-20")]
        public string CouponCode { get; set; }

        [Display(Name = "Percentage Off Total Order (%)")]
        public decimal PercentageOff { get; set; }

        [Display(Name = "Free Shipping when Customers Spend Above $")]
        public decimal ShippingWhen { get; set; }

        public string Description { get; set; }

        public Boolean IsDisabled { get; set; }

        //Navigational
        public List<Order> Orders { get; set; }

    }

}
