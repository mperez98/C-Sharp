﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Team6FinalProject.Models
{
    public class Book
    {

        [Display(Name = "Publication Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime PublicationDate { get; set; }

        public Int32 BookID { get; set; }
        public Int32 BookNumber { get; set; }

        [Display(Name = "Title: ")]
        public String Title { get; set; }

        [Display(Name = "Author")]
        public String Author { get; set; }

        [Display(Name = "Genre")]
        public Genre Genre { get; set; }

        [Display(Name = "Description")]
        public String Description { get; set; }

        [Display(Name = "Book Price")]
        [Range(0, 1000000, ErrorMessage = "Book price must be greater than 0")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Price { get; set; }

        [Display(Name = "Book Cost")]
        [Range(0, 1000000, ErrorMessage = "Book cost must be greater than 0")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Cost { get; set; }

        [Range(0, 1000000, ErrorMessage = "Reorder point must be greater than or equal to 0")]
        public Decimal ReorderPoint { get; set; } //should be int

        [Display(Name = "Number of Copies: ")]
        [Range(0, 1000000, ErrorMessage = "Copies must be greater than 0 or equal to 0")]
        public Decimal Copies { get; set; } //should be int

        public Decimal TotalCost { get; set; }

        public Int32 TotalQuantitySold { get; set; }

        public Decimal ReorderDiff
        {
            get { return InventoryCount - ReorderPoint; }
        }

        [Display(Name = "Number of Pending Book Orders: ")]
        public Decimal UnreceivedOrderCount { get; set; }


        public Decimal InventoryCount 
        {
            get { return Copies + UnreceivedOrderCount; }
        }

        [Display(Name = "Date Last Ordered")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime LastOrdered { get; set; }

        [Display(Name = "Book Rating Average")]
        public Decimal RatingAverage { get; set; }

        public bool IsInStock 
        {
            get { return Copies > 0m; }
        }

        [Display(Name = "Number of Books that have Arrived:")]
        public Decimal RecievedOrderCount { get; set; }

        public Decimal FinalCount
        {
            get { return Copies + RecievedOrderCount; }
        }

        [Display(Name = "Book Average Cost")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal AverageCost { get; set; }

        [Display(Name = "Book Average Price")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal AveragePrice { get; set; }

        [Display(Name = "Book Average Profit Margin")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal AverageProfitMargin { get; set; }

        public List<Review> Reviews { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }
        public List<ProcurementDetail> Procurements { get; set; }

        public Boolean IsDicontinued { get; set; }

        public Book()
        {
            if (Reviews == null)
            {
                Reviews = new List<Review>();
            }
        }
    }

}
