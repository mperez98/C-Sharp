﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

namespace Team6FinalProject.Controllers
{
    public class CreditCardsController : Controller
    {
        private readonly AppDbContext _context;
        
        public enum CreditCardEnum { Visa, AmericanExpress,Discover,MasterCard }
        //needto add in views
        /*
          <div class="form-group">
        <label> Number of Stars:</label>
        <input name="NumberStars" class="form-control" />
        <label class="radio">@Html.RadioButton("NumStar", StarEnum.GreaterThan, true) Greater Than</label>
        <label class="radio">@Html.RadioButton("NumStar", StarEnum.LessThan)LessThan</label>
    </div>
    */

        public CreditCardsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: CreditCards
        public async Task<IActionResult> Index()
        {
            return View(await _context.CreditCards.ToListAsync());
        }

        // GET: CreditCards/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var creditCard = await _context.CreditCards
                .FirstOrDefaultAsync(m => m.CreditCardID == id);
            if (creditCard == null)
            {
                return NotFound();
            }

            return View(creditCard);
        }

        // GET: CreditCards/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CreditCards/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string Card, string CreditCardType)
        {
            // check if user already has 3 credit cards
            AppUser currUser = _context.AppUsers.Include(c => c.CreditCards).FirstOrDefault(c=>c.UserName == User.Identity.Name);//include statement

            int numCards = currUser.CreditCards.Count;

            List<CreditCard> ccs = currUser.CreditCards;

            if (numCards >= 3)
            {
                ViewBag.CreditCardTypeInvalid = "You already have three credit cards saved and cannot add anymore";
                return View("Create");
            }

            //validation for creditcard type, must be one of the following options
            List<string> validCreditCardTypes = new List<string> {"visa", "americanexpress", "discover", "mastercard"};
            CreditCardType = CreditCardType.Replace(" ", "");
            CreditCardType = CreditCardType.ToLower();
            if (!validCreditCardTypes.Contains(CreditCardType))
            {
                ViewBag.CreditCardTypeInvalid = "The type of credit card you entered is invalid, please enter either Visa, American Express, Discover, or MasterCard";
                return View("Create");
            }


            // validate that credit card number is only digits
            foreach (char x in Card)
            {
                String a = x.ToString();
                int number;
                bool success = Int32.TryParse(a, out number);
                if (success == false)
                {
                    ViewBag.CreditCardNumLength = "You must enter a 16 digit credit card number";
                    return View("Create");
                }
            }

            //validation to check if creditcard number is 16 digits
            if (Card.Length < 16 | Card.Length > 16)
            {
                ViewBag.CreditCardNumLength = "You must enter a 16 digit credit card number";
                return View("Create");
            }

            //associate creditcard with who is logged in
            Card = "XXXX-XXXX-XXXX-" + Card.Substring(12);
            CreditCard creditCard = new CreditCard();
            creditCard.AppUser = currUser;
            creditCard.Card = Card;
            creditCard.CreditCardType = CreditCardType;
            currUser.CreditCards.Add(creditCard);


            if (ModelState.IsValid)
            {
                _context.CreditCards.Add(creditCard);
                _context.AppUsers.Update(currUser);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", "Home");
            }

            return RedirectToAction("Index", "Home");


        }

        // GET: CreditCards/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var creditCard = await _context.CreditCards.FindAsync(id);
            if (creditCard == null)
            {
                return NotFound();
            }
            return View(creditCard);
        }

        // POST: CreditCards/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CreditCardID,CreditCard1,CreditCard2,CreditCard3,CreditCardType")] CreditCard creditCard)
        {
            if (id != creditCard.CreditCardID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(creditCard);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CreditCardExists(creditCard.CreditCardID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(creditCard);
        }

        // GET: CreditCards/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var creditCard = await _context.CreditCards
                .FirstOrDefaultAsync(m => m.CreditCardID == id);
            if (creditCard == null)
            {
                return NotFound();
            }

            return View(creditCard);
        }

        // POST: CreditCards/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var creditCard = await _context.CreditCards.FindAsync(id);
            _context.CreditCards.Remove(creditCard);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CreditCardExists(int id)
        {
            return _context.CreditCards.Any(e => e.CreditCardID == id);
        }
    }
}
