using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;
using Team6FinalProject.Utilites;

namespace Team6FinalProject.Controllers
{
    public class BooksController : Controller
    {
        private readonly AppDbContext _context;

        public BooksController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Books
        public async Task<IActionResult> Index()
        {

            return View(await _context.Books.ToListAsync());
        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .FirstOrDefaultAsync(m => m.BookID == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        public IActionResult Discontinue (int? id)
        {
            Book bk = _context.Books.Find(id);
            bk.IsDicontinued = true;
            _context.Books.Update(bk);
            _context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        // GET: Books/Create
        public IActionResult Create()
        {
            ViewBag.AllGenres = GetAllGenres();
            return View();
        }

        // POST: Books/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int SelectedGenre, [Bind("BookID,BookNumber,Title,Author,Price, Copies, Cost, Description, PublicationDate", "ReorderPoint")] Book bk)
        {
            if (ModelState.IsValid)
            {
                //Generate next SKU
                bk.BookNumber = GenerateBookNumber.GetNextBookNumber(_context);

                _context.Add(bk);
                _context.SaveChanges();

                //add connections to genre
                //first, find the book you just added
                Book dbBook = _context.Books.FirstOrDefault(c => c.BookNumber == bk.BookNumber);
                dbBook.Genre = _context.Genres.FirstOrDefault(g => g.GenreID == SelectedGenre);
                _context.SaveChanges();
                //loop through selected departments and add them
                /*foreach (int i in SelectedGenres)
                {
                    Genre dbSupp = await _context.Genres.Find(i);
                    ProductGenre ps = new ProductGenre();
                    ps.Product = dbProduct;
                    ps.Genre = dbSupp;
                    _context.ProductGenres.Add(ps);
                    _context.SaveChanges();
                }*/
                return RedirectToAction("Index", "Home");
            }
            //re-populate the viewbag
            return View(bk);
        }

        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book =  _context.Books.Include(b => b.Genre).FirstOrDefault(b => b.BookID == id);
            if (book == null)
            {
                return NotFound();
            }
            ViewBag.AllGenres = GetAllGenres(book);
            return View(book);
        }

        // POST: Books/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int SelectedGenre, [Bind("BookID,BookNumber,Title,Author,Price, Copies, Cost, Description, PublicationDate", "ReorderPoint")] Book book)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Book dbBook = _context.Books
                                          .Include(c => c.Genre)
                                          .FirstOrDefault(c => c.BookID == book.BookID);

                    dbBook.Price = book.Price;
                    dbBook.Title = book.Title;
                    dbBook.Description = book.Description;
                    dbBook.Author = book.Author;
                    dbBook.Copies = book.Copies;
                    dbBook.Cost = book.Cost;
                    dbBook.PublicationDate = book.PublicationDate;
                    dbBook.ReorderPoint = book.ReorderPoint;
                    dbBook.Genre = _context.Genres.FirstOrDefault(g => g.GenreID == SelectedGenre);

                    _context.Update(dbBook);
                    _context.SaveChanges();

                    //edit department/course relationships

                    //loop through selected departments and find ones that need to be removed
                    /*List<ProductSupplier> SupplsToRemove = new List<ProductSupplier>();
                    foreach (ProductSupplier pd in dbProduct.ProductSuppliers)
                    {
                        if (SelectedSuppliers.Contains(pd.Supplier.SupplierID) == false)
                        //list of selected depts does not include this departments id
                        {
                            SupplsToRemove.Add(pd);
                        }
                    }*/
                    //remove departments you found in list above - this has to be 2 separate steps because you can't 
                    //iterate over a list that you are removing items from
                    /*foreach (ProductSupplier pd in SupplsToRemove)
                    {
                        _context.ProductSuppliers.Remove(pd);
                        _context.SaveChanges();
                    }*/

                    //now add the departments that are new
                    /*foreach (int i in SelectedSuppliers)
                    {
                        if (dbProduct.ProductSuppliers.Any(c => c.Supplier.SupplierID == i) == false)
                        //this supplier has not yet been added
                        {
                            //create a new course department
                            ProductSupplier pd = new ProductSupplier();

                            //connect the new course department to the department and course
                            pd.Supplier = _context.Suppliers.Find(i);
                            pd.Product = dbProduct;

                            //update the database
                            _context.ProductSuppliers.Add(pd);
                            _context.SaveChanges();
                        }
                    }*/

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.BookID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Details", "Home", new { id = book.BookID });
            }
            ViewBag.AllGenres = GetAllGenres(book);
            return View(book);
        }

        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .FirstOrDefaultAsync(m => m.BookID == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books.FindAsync(id);
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.BookID == id);
        }

        private SelectList GetAllGenres()
        {
            List<Genre> allGenrs = _context.Genres.ToList();
            SelectList genreList = new SelectList(allGenrs, "GenreID", "GenreName"); // Maybe debug here
            return genreList;
        }

        //overload for editing suppliers
        private SelectList GetAllGenres(Book book)
        {
            //create a list of all the genres
            List<Genre> allGenrs = _context.Genres.ToList();

            //create a list for the supplier ids that this product already belongs to
            //List<int> currentGenrs = new List<int>();

            //loop through all the details to find the list of current suppliers
            //foreach (Book b in allGenrs)
            //{
                //currentG.Add(pd.Genre.GenreID);
            //}

            //create the multiselect with the overload for currently selected item
            SelectList supplList = new SelectList(allGenrs, "GenreID", "GenreName", book.Genre.GenreID);

            //return the list
            return supplList;
        }

        //[HttpPost]
        //public ActionResult EvaluateReview (Review review, decimal rating)
        //{

        //}

    }
}
