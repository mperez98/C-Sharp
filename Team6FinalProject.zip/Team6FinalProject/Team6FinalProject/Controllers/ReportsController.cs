﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Team6FinalProject.Controllers
{
    [Authorize(Roles = "Manager")]
    public class ReportsController : Controller
    {



        public enum ReportSort
        {
            MostRecent, ProfitMarginAsc, ProfitMarginDesc, PriceAsc,
            PriceDesc, MostPop, RevAsc, RevDesc, UserNameAsc, NumApproveAsc,
            NumApproveDesc, NumRejectAsc, NumRejectDesc
        }

        private readonly AppDbContext _context;
        private RoleManager<IdentityRole> _roleManager;
        private UserManager<AppUser> _userManager;

        public ReportsController(AppDbContext context, UserManager<AppUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> AllBooksSoldReport()
        {
            var query = from r in _context.OrderDetails
                        select r;

            var allbooks = query.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser).
                                Where(o => o.Order.IsPending == true).ToList();

            foreach (OrderDetail od in allbooks)
            {

                if (od.Book.AverageCost == 0m)
                {
                    od.Book.AverageCost = od.Book.Cost;
                    od.Book.AverageProfitMargin = od.Book.Price - od.Book.AverageCost;
                    _context.Books.Update(od.Book);
                }
            }
            _context.SaveChanges();

            return View("AllBooksSoldReport", allbooks);


        }

        public ActionResult AReportSearch()
        {
            return View();
        }

        public IActionResult DisplayBooksSort(ReportSort SelectedSort)
        {
            var query = from r in _context.OrderDetails.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser).
                                          Where(o => o.Order.IsPending == true)
                        select r;

            //Sort
            if (SelectedSort == ReportSort.MostRecent)
            { query = query.OrderByDescending(r => r.Book.LastOrdered); }

            if (SelectedSort == ReportSort.ProfitMarginAsc)
            { query = query.OrderBy(r => r.Book.AverageProfitMargin); }

            if (SelectedSort == ReportSort.ProfitMarginDesc)
            { query = query.OrderByDescending(r => r.Book.AverageProfitMargin); }

            if (SelectedSort == ReportSort.PriceAsc)
            { query = query.OrderBy(r => r.Book.Price); }

            if (SelectedSort == ReportSort.PriceDesc)
            { query = query.OrderByDescending(r => r.Book.Price); }

            if (SelectedSort == ReportSort.MostPop)
            { query = query.OrderBy(r => r.Quantity); }

            List<OrderDetail> SelectedBooks = new List<OrderDetail>();
            SelectedBooks = query.ToList();
            ViewBag.SelectedBooks = SelectedBooks.Count();
            ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " Records";
            return View("AllBooksSoldReport", SelectedBooks);

        }

        public async Task<IActionResult> AllOrdersReport()
        {
            var query = from r in _context.OrderDetails
                        select r;

            var allorders = query.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser)
                                .Where(o => o.Order.IsPending == true).ToList();

            List<OrderView> ords = new List<OrderView>();

            foreach (OrderDetail od in allorders)
            {
                OrderView ord = new OrderView();
                ord.OrderID = od.Order.OrderID;
                ord.OrderQuantity = od.Quantity;
                ord.CustomerName = od.Order.AppUser.FullName;
                ord.OrderSubtotal = ord.OrderSubtotal + od.ExtendedPrice;
                ord.OrderAverageCost = ord.OrderAverageCost + od.Book.AverageCost;
                ord.OrderProfitMargin = ord.OrderSubtotal - ord.OrderAverageCost;
                ords.Add(ord);
            }


            return View("AllOrdersReport", ords);
        }


        //public ActionResult BReportSearch()
        //{
        //    return View();
        //}


        ////check sort again with new data!
        //public IActionResult DisplayOrdersSort(ReportSort SelectedSort)
        //{
        //    var query = from r in _context.OrderDetails.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser).
        //                                  Where(o => o.Order.IsPending == true)
        //                select r;

        //    //Sort
        //    if (SelectedSort == ReportSort.MostRecent)
        //    { query = query.OrderByDescending(r => r.Book.LastOrdered); }

        //    if (SelectedSort == ReportSort.ProfitMarginAsc)
        //    { query = query.OrderBy(r => r.Book.AverageProfitMargin); }

        //    if (SelectedSort == ReportSort.ProfitMarginDesc)
        //    { query = query.OrderByDescending(r => r.Book.AverageProfitMargin); }

        //    if (SelectedSort == ReportSort.PriceAsc)
        //    { query = query.OrderBy(r => r.Order.OrderSubtotal); }

        //    if (SelectedSort == ReportSort.PriceDesc)
        //    { query = query.OrderByDescending(r => r.Order.OrderSubtotal); }

        //    List<OrderDetail> SelectedBooks = new List<OrderDetail>();
        //    SelectedBooks = query.ToList();
        //    ViewBag.SelectedBooks = SelectedBooks.Count();
        //    ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " Records";
        //    return View("AllOrdersReport", SelectedBooks);
        //}


        public async Task<IActionResult> AllCustomersReport()
        {
            List<AppUser> members = new List<AppUser>();
            List<AppUser> nonMembers = new List<AppUser>();
            foreach (AppUser user in _userManager.Users)
            {
                var list = await _userManager.IsInRoleAsync(user, "Customer") ? members : nonMembers;
                list.Add(user);
            }
            var query = from r in _context.OrderDetails
                        select r;

            var allorders = query.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser)
                                .Where(o => o.Order.IsPending == true).ToList();
            //List<OrderDetail> ods = new List<OrderDetail>();
            List<CustomerViewModel> custs = new List<CustomerViewModel>();

            Decimal CostOfOrder;


            foreach (AppUser au in members)
            {
                CustomerViewModel cust = new CustomerViewModel();
                cust.CustomerName = au.FullName;
                cust.CustomerEmail = au.Email;
                cust.CustomerQuantity = allorders.Where(r => r.Order.IsPending == true && r.Order.AppUser == au).Sum(r => r.Quantity);
                cust.CustomerRevenue = allorders.Where(r => r.Order.IsPending == true && r.Order.AppUser == au).Sum(r => r.Order.OrderSubtotal);
                cust.CustomerWAC = allorders.Where(r => r.Order.IsPending == true && r.Order.AppUser == au).Sum(r => r.Book.Cost);
                cust.CustomerProfitMargin = cust.CustomerRevenue - cust.CustomerWAC;
                custs.Add(cust);
            }


            return View("AllCustomersReport", custs);

        }

        //public async Task<IActionResult> CurrentInventoryReport()
        //{


        public async Task<IActionResult> CurrentInventoryReport()
        {
            var query = from r in _context.Books
                        select r;

            var allbooks = query.ToList();

            List<InventoryView> invs = new List<InventoryView>();

            foreach (Book bk in allbooks)
            {
                InventoryView inv = new InventoryView();
                inv.BookTitle = bk.Title;
                inv.NumBooks = bk.Copies;
                inv.BookAvgCost = bk.AverageCost;
                invs.Add(inv);
            }

            //need to add line at bottom of view to show current value of all inventory
            decimal decTotalInventoryValue = _context.OrderDetails.Sum(o => o.ExtendedPrice);

            ViewBag.Total = "Current Inventory value is $" + decTotalInventoryValue.ToString();
            return View("CurrentInventoryReport", invs);

            //decimal decTotalInventoryValue = _context.OrderDetails.Sum(o => o.ExtendedPrice);

            //ViewBag.Total = "Current Inventory value is " + decTotalInventoryValue.ToString()

        }


        public async Task<IActionResult> ReviewsReport()
        {

            List<AppUser> members = new List<AppUser>();
            List<AppUser> nonMembers = new List<AppUser>();
            foreach (AppUser user in _userManager.Users)
            {
                var list = await _userManager.IsInRoleAsync(user, "Customer") ? members : nonMembers;
                list.Add(user);
            }

            //List<OrderDetail> ods = new List<OrderDetail>();
            List<ReviewViewModel> revs = new List<ReviewViewModel>();

            foreach (AppUser au in nonMembers)
            {
                ReviewViewModel rev = new ReviewViewModel();
                rev.EmployeeUsername = au.UserName;
                rev.ReviewerName = au.FullName;
                rev.NumApproved = _context.Reviews.Where(r => r.IsApproved == true && r.Approver == au).Count();
                rev.NumRejected = _context.Reviews.Where(r => r.IsApproved == false && r.Approver == au).Count();
                revs.Add(rev);
            }
            return View("ReviewsReport", revs);


        }


        public async Task<IActionResult> TotalsReport()
        {
            var query = from r in _context.OrderDetails
                        select r;

            var allorders = query.Include(o => o.Book).Include(o => o.Order).ThenInclude(o => o.AppUser)
                                .Where(o => o.Order.IsPending == true).ToList();

            TotalViewModel tot = new TotalViewModel();

            tot.TotalRevenue = allorders.Where(r => r.Order.IsPending == true).Sum(r => r.Order.OrderSubtotal);
            //does this calc total cost for ALL books sold??
            tot.TotalCost = allorders.Where(r => r.Order.IsPending == true).Sum(r => r.Book.Cost);
            tot.TotalProfit = tot.TotalRevenue - tot.TotalCost;


            return View("TotalsReport", tot);

        }


    }
    
}
