﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Utilities;
using Team6FinalProject.Models;



namespace Team6FinalProject.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private SignInManager<AppUser> _signInManager;
        private UserManager<AppUser> _userManager;
        private PasswordValidator<AppUser> _passwordValidator;
        private AppDbContext _db;



        public AccountController(AppDbContext context, UserManager<AppUser> userManager, SignInManager<AppUser> signIn)
        {
            _db = context;
            _userManager = userManager;
            _signInManager = signIn;

            //user manager only has one password validator
            _passwordValidator = (PasswordValidator<AppUser>)userManager.PasswordValidators.FirstOrDefault();
        }


        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
           

            if (User.Identity.IsAuthenticated) //user has been redirected here from a page they're not authorized to see
            {
                return View("Error", new string[] { "Access Denied" });
            }
            _signInManager.SignOutAsync(); //this removes any old cookies hanging around
            ViewBag.ReturnUrl = returnUrl;


           
            _signInManager.SignOutAsync(); //this removes any old cookies hanging around
            ViewBag.ReturnUrl = returnUrl;

            return View();

            

            
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //String id = User.Identity.Name;
            // User is not logged in
            AppUser userAttempt = _db.Users.FirstOrDefault(u => u.UserName == model.Email);

            //User.IsDisabled == true is null 
            if (userAttempt == null)
            {
                return View("Error", new string[] { "This email does not exist" });
            }

            if (userAttempt.IsDisabled == true)
            {
                return View("Error", new string[] { "Access Denied - Your account is disabled." });
            }


            //Disabling user
            // String id = User.Identity.Name;
            //AppUser userAttempt = _db.Users.FirstOrDefault(u => u.UserName == id);

            // Disabling a User
            //if (LoginViewModel.IsDisabled == true)
            //{
            //   return View("Error", new string[] { "Access Denied" });

            //  }


            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true
            Microsoft.AspNetCore.Identity.SignInResult result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                return Redirect(returnUrl ?? "/");
            }
            else
            {
                ModelState.AddModelError("", "Invalid login attempt.");
                return View(model);
            }
        }


        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        //TO: This is the method where you create a new user
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                AppUser user = new AppUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    StreetAddress = model.StreetAddress,
                    City = model.City,
                    State = model.State,
                    ZipCode = model.ZipCode,
                    


                };
                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //DO: Add user to desired role - need to fix this 
                    //This will not work until you have seeded Identity OR added the "Customer" role 
                    //by navigating to the RoleAdmin controller and manually added the "Customer" role

                    await _userManager.AddToRoleAsync(user, "Customer");
                    string emailBody = "Hello!  " +user.FirstName+ "   You created an account!";
                    string emailSubject = "Welcome! New Account Creation";
                    EmailMessaging.SendEmail(user.Email, emailSubject, emailBody);


                    Microsoft.AspNetCore.Identity.SignInResult result2 = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, lockoutOnFailure: false);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View(model);
        }



        // GET: /Account/Register
        [AllowAnonymous] // Fix to Manager Tag
        public ActionResult RegisterEmployee()
        {
            return View();
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        //TO: This is the method where you create a new user
        public async Task<ActionResult> RegisterEmployee(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                AppUser user = new AppUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    StreetAddress = model.StreetAddress,
                    City = model.City,
                    State = model.State,
                    ZipCode = model.ZipCode,



                };
                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //DO: Add user to desired role - need to fix this 
                    //This will not work until you have seeded Identity OR added the "Customer" role 
                    //by navigating to the RoleAdmin controller and manually added the "Customer" role

                    await _userManager.AddToRoleAsync(user, "Employee");


                   // Microsoft.AspNetCore.Identity.SignInResult result2 = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, lockoutOnFailure: false);
                    return RedirectToAction("Index", "RoleAdmin");
                }
                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View(model);
        }

        // GET: /Account/Register
        [AllowAnonymous] // Fix to Manager Tag
        public ActionResult RegisterCustomer()
        {
            return View();
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        //TO: This is the method where you create a new user
        public async Task<ActionResult> RegisterCustomer(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                AppUser user = new AppUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    StreetAddress = model.StreetAddress,
                    City = model.City,
                    State = model.State,
                    ZipCode = model.ZipCode,



                };
                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //DO: Add user to desired role - need to fix this 
                    //This will not work until you have seeded Identity OR added the "Customer" role 
                    //by navigating to the RoleAdmin controller and manually added the "Customer" role

                    await _userManager.AddToRoleAsync(user, "Customer");

                    //Get the user 
                    string cd = User.Identity.Name;
                    AppUser user2 = _db.Users.FirstOrDefault(u => u.UserName == cd);

                 

                    //decDeliveryFee = Validation.CheckDeliveryFee(struserInputDeliveryFee);



                    // Microsoft.AspNetCore.Identity.SignInResult result2 = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, lockoutOnFailure: false);
                    return RedirectToAction("Index", "RoleAdmin");
                }
                else
                {
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            return View(model);
        }


        //GET: Account/Index
        public ActionResult Index()
        {
            IndexViewModel ivm = new IndexViewModel();

            //get user info
            String id = User.Identity.Name;
            AppUser user = _db.Users.FirstOrDefault(u => u.UserName == id);

            //populate the view model
            ivm.Email = user.Email;
            ivm.HasPassword = true;
            ivm.UserID = user.Id;
            ivm.UserName = user.UserName;
            ivm.FirstName = user.FirstName;
            ivm.LastName = user.LastName;
            ivm.StreetAddress = user.StreetAddress;
            ivm.City = user.City;
            ivm.ZipCode = user.ZipCode;
            ivm.State = user.State;
            ivm.PhoneNumber = user.PhoneNumber;
           




            return View(ivm);
        }


    

       


        // GET: /Account/ChangeAccountDetails

        public ActionResult ChangeAccountDetails(int? id)
        {
           
            
            string cd = User.Identity.Name;
            AppUser user = _db.Users.FirstOrDefault(u => u.UserName == cd);

            if (user == null)
            {
                return NotFound();
            }

            //don't pass in user, thenit is blank

            return View(user);
        }




        //Post: Access current user 
        [Authorize(Roles = "Customer")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangeAccountDetails([Bind("FirstName,LastName,Email,StreetAddress,City,State,ZipCode,PhoneNumber")]AppUser model)
        {
            if (!ModelState.IsValid)
            {

                var modelErrors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var modelError in modelState.Errors)
                    {
                        modelErrors.Add(modelError.ErrorMessage);
                    }
                    return View(model);
                }
            }
            // AppUser userLoggedIn = await _userManager.FindByNameAsync(User.Identity.Name);
            var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            AppUser userLoggedIn = _db.Users.FirstOrDefault(i => i.Id == userID);
            //AppUser userLoggedIn = _db.Users.FirstOrDefault(u => u.UserName == cd);
            //Microsoft.AspNetCore.Identity.IdentityResult result =await _userManager.ChangeEmailAsync(userLoggedIn, model.Email, model.Email);
            //Microsoft.AspNetCore.Identity.IdentityResult result2 = await _userManager.ChangePhoneNumberAsync(userLoggedIn, model.PhoneNumber, model.PhoneNumber);

            userLoggedIn.FirstName = model.FirstName;
            userLoggedIn.LastName = model.LastName;
            userLoggedIn.Email = model.Email;
            userLoggedIn.PhoneNumber = model.PhoneNumber;
            userLoggedIn.StreetAddress = model.StreetAddress;
            userLoggedIn.City = model.City;
            userLoggedIn.State = model.State;
            userLoggedIn.ZipCode = model.ZipCode;
            _db.Update(userLoggedIn);
            _db.SaveChanges();
            
        
                return RedirectToAction("Index");
         

        }

        // Change User Account Details 

        // GET: /Account/ChangeAccountDetails

        public async Task<ActionResult> ChangeUserDetails(string Id)
        {


            // AppUser user = await _userManager.FindByIdAsync(UserID);
            //AppUser user = await _userManager.FindByEmailAsync(Email);
            AppUser user = _db.Users.FirstOrDefault(i => i.Id == Id);

           TempData["UserID"] = Id;


            if (user == null)
            {
              return NotFound();
             }

            //don't pass in user, thenit is blank

            return View(user);
        }




        //Post: Access current user 
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangeUserDetails([Bind("FirstName,LastName,Email,StreetAddress,City,State,ZipCode,PhoneNumber")]AppUser model)
        {
            string UserID = (string)TempData["UserID"];
            if (!ModelState.IsValid)
            {

                var modelErrors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var modelError in modelState.Errors)
                    {
                        modelErrors.Add(modelError.ErrorMessage);
                    }
                    return View(model);
                }



            }
            // AppUser userLoggedIn = await _userManager.FindByNameAsync(User.Identity.Name);
            // var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);


            //AppUser userLoggedIn = _db.Users.FirstOrDefault(i => i.Id == userID );

            AppUser userLoggedIn = _db.AppUsers.Find(UserID);

            // userLoggedIn.Id = ?
            userLoggedIn.FirstName = model.FirstName;
            userLoggedIn.LastName = model.LastName;
            userLoggedIn.Email = model.Email;
            userLoggedIn.PhoneNumber = model.PhoneNumber;
            userLoggedIn.StreetAddress = model.StreetAddress;
            userLoggedIn.City = model.City;
            userLoggedIn.State = model.State;
            userLoggedIn.ZipCode = model.ZipCode;
            _db.Update(userLoggedIn);
            _db.SaveChanges();


            return RedirectToAction("Index","RoleAdmin");


        }







        // GET: /Account/ChangeAccountDetails
        [Authorize(Roles = "Manager,Employee")]
        public ActionResult ChangeEmployeeAccountDetails(int? id)
        {


            string cd = User.Identity.Name;
            AppUser user = _db.Users.FirstOrDefault(u => u.UserName == cd);

            if (user == null)
            {
                return NotFound();
            }

            //don't pass in user, thenit is blank

            return View(user);
        }



        [Authorize(Roles = "Manager, Employee")]
        //Post: Access current user 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangeEmployeeAccountDetails( AppUser user)
        {

            AppUser currUser = _db.AppUsers.FirstOrDefault(x => x.UserName == User.Identity.Name);

            user.FirstName = currUser.FirstName;
            user.LastName = currUser.LastName;
            user.Email = currUser.Email;

            if (!ModelState.IsValid)
            {


               var modelErrors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var modelError in modelState.Errors)
                    {
                        modelErrors.Add(modelError.ErrorMessage);
                    }
                    return View(user);
                }
            }
            // AppUser userLoggedIn = await _userManager.FindByNameAsync(User.Identity.Name);
            var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            AppUser userLoggedIn = _db.Users.FirstOrDefault(i => i.Id == userID);
            //AppUser userLoggedIn = _db.Users.FirstOrDefault(u => u.UserName == cd);
            //Microsoft.AspNetCore.Identity.IdentityResult result =await _userManager.ChangeEmailAsync(userLoggedIn, model.Email, model.Email);
            //Microsoft.AspNetCore.Identity.IdentityResult result2 = await _userManager.ChangePhoneNumberAsync(userLoggedIn, model.PhoneNumber, model.PhoneNumber);

            
            userLoggedIn.PhoneNumber = user.PhoneNumber;
            userLoggedIn.StreetAddress = user.StreetAddress;
            userLoggedIn.City = user.City;
            userLoggedIn.State = user.State;
            userLoggedIn.ZipCode = user.ZipCode;
            _db.Update(userLoggedIn);
            _db.SaveChanges();


            return RedirectToAction("Index");


        }

       



        












        //Logic for change password
        // GET: /Account/ChangePassword
        public ActionResult ChangePassword()
        {
            return View();
        }


        // POST: /Account/ChangePassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            AppUser userLoggedIn = await _userManager.FindByNameAsync(User.Identity.Name);
            var result = await _userManager.ChangePasswordAsync(userLoggedIn, model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(userLoggedIn, isPersistent: false);
                //Sending an email
                string emailBody = "Hello! You recently changed this password";
                string emailSubject = "Change Password";
                EmailMessaging.SendEmail(userLoggedIn.Email, emailSubject, emailBody);

                return RedirectToAction("Index", "Home");
            }
            AddErrors(result);
            return View(model);
        }

        //GET:/Account/AccessDenied
        public ActionResult AccessDenied(String ReturnURL)
        {
            return View("Error", new string[] { "Access is denied" });
        }

        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }


        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }
    }
}
