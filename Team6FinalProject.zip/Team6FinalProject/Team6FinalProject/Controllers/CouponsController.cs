using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

namespace Team6FinalProject.Controllers
{
    public class CouponsController : Controller
    {
        private readonly AppDbContext _context;

        public CouponsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Coupons
        public async Task<IActionResult> Index()
        {
            List<Coupon> coupons = _context.Coupons.ToList();

            return View("Index", coupons);
        }

        // GET: Coupons/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var coupon = await _context.Coupons
                .FirstOrDefaultAsync(m => m.CouponID == id);
            if (coupon == null)
            {
                return NotFound();
            }

            return View(coupon);
        }

        // GET: Coupons/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Coupons/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string CouponCode, decimal? PercentageOff, decimal? ShippingWhen)
        {

            if (CouponCode == null)
            {
                ViewBag.CouponCodeNull = "You must enter a coupon code.";
                return View("Create");
            }

            if (PercentageOff == null && ShippingWhen == null)
            {
                ViewBag.BothNull = "You must enter either a percentage OR free shipping.";
                return View("Create");
            }

            if (PercentageOff != null && ShippingWhen != null)
            {
                ViewBag.BothNotNull = "You can only enter either a percentage OR free shipping.";
                return View("Create");
            }

            if (PercentageOff == 0m)
            {
                ViewBag.BothNotNull = "You must enter a percentage greater than 0";
                return View("Create");
            }

            if (PercentageOff == null)
            {
                PercentageOff = 0m;
            }

            if (ShippingWhen == null)
            {
                ShippingWhen = 0m;
            }

            if (PercentageOff > 100m)
            {
                ViewBag.Message = "You cannot enter a percentage greater than 100%";
                return View("Create");
            }

            if (CouponCode.Length > 20)
            {
                ViewBag.Message = "You cannot enter a Coupon Code greater than 20 characters";
                return View("Create");
            }

            if (CouponCode.Length < 1)
            {
                ViewBag.Message = "You cannot enter a Coupon Code less than 1 character";
                return View("Create");
            }



            //create a new coupon
            Coupon coupon = new Coupon();

            coupon.CouponCode = CouponCode;
            coupon.PercentageOff = (decimal)PercentageOff;
            coupon.ShippingWhen = (decimal)ShippingWhen;



            if (ModelState.IsValid)
            {
                _context.Add(coupon);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View("Index");
        }

        public ActionResult Enable (int? id)
        {
            Coupon coup = _context.Coupons.Find(id);
            coup.IsDisabled = false;
            _context.Coupons.Update(coup);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public ActionResult Disable(int? id)
        {
            Coupon coup = _context.Coupons.Find(id);
            coup.IsDisabled = true;
            _context.Coupons.Update(coup);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // GET: Coupons/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var coupon = await _context.Coupons.FindAsync(id);
            if (coupon == null)
            {
                return NotFound();
            }
            return View(coupon);
        }

        // POST: Coupons/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CouponID,Description")] Coupon coupon)
        {
            if (id != coupon.CouponID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(coupon);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CouponExists(coupon.CouponID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(coupon);
        }

        // GET: Coupons/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var coupon = await _context.Coupons
                .FirstOrDefaultAsync(m => m.CouponID == id);
            if (coupon == null)
            {
                return NotFound();
            }

            return View(coupon);
        }

        // POST: Coupons/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var coupon = await _context.Coupons.FindAsync(id);
            _context.Coupons.Remove(coupon);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CouponExists(int id)
        {
            return _context.Coupons.Any(e => e.CouponID == id);
        }
    }
}
