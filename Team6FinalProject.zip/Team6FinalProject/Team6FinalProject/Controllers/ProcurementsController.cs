﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

namespace Team6FinalProject.Controllers
{
    public class ProcurementsController : Controller
    {
        private readonly AppDbContext _context;

        public ProcurementsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Procurements
        public async Task<IActionResult> Index()
        {

            List<Procurement> Procurements = new List<Procurement>();
            Procurements = _context.Procurements.Include(p => p.ProcurementDetails).ToList();

            return View(Procurements);

        }

        public async Task<IActionResult> Home()
        {
            return View();
        }

        // GET: Procurements/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find current reorder cart
            Procurement procurement = _context.Procurements
                .Include(o => o.ProcurementDetails).ThenInclude(o => o.Book)
                .FirstOrDefault(o => o.ProcurementID == id);

            if (procurement == null)
            {
                return NotFound();
            }

            return View(procurement);
        }


        // GET: Procurements/Create
        public IActionResult Create(int? id)
        {
            // Find current reorder cart
            Procurement proc = _context.Procurements.Include(o => o.ProcurementDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.IsPending == false && o.AppUser.UserName == User.Identity.Name);

            // If there is no cart, then create a new order/cart
            if (proc == null)
            {
                return RedirectToAction("CreatePost", new { idBk = id });
            }
            // Else: there is already a cart, so just add to it
            return RedirectToAction("AddToOrder", new { id = proc.ProcurementID, idBook = id });
        }

        public async Task<IActionResult> CreatePost([Bind("ProcurementID", "ProcurementDate")] int? idBk)
        {
            Procurement procurement = new Procurement();
            procurement.ProcurementDate = System.DateTime.Today;


            //add in code to associate an order with a specific user
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            procurement.AppUser = user;


            if (ModelState.IsValid)
            {
                _context.Add(procurement);
                await _context.SaveChangesAsync();
                return RedirectToAction("AddToOrder", new { id = procurement.ProcurementID, idBook = idBk });
            }
            return NotFound();
        }

        public IActionResult AddToOrder(int? id, int? idBook)
        {
            // Check if inputs are null
            if (id == null || idBook == null)
            {
                return View("Error", new string[] { "You must specify an order to add!" });
            }

            // Find procurement created in previous function
            //Order ord = _context.Orders.FirstOrDefault(o => o.OrderID == id);
            Procurement proc = _context.Procurements.Include(p => p.ProcurementDetails).FirstOrDefault(o => o.ProcurementID == id);

            // Check if order exists in database
            if (proc == null)
            {
                return View("Error", new string[] { "Order not found!" });
            }

            // Create order detail to be associated with ord
            ProcurementDetail pd = new ProcurementDetail() { Procurement = proc };
            //ord.OrderDetails.Add(od);

            /*ViewBag.Message = quantityError;
            // Display Book title
            //Book bk = _context.Books.Find(idBook);
            if (quantityError == 1m)
            {
                Book book = _context.Books.Find(idBook);
                int stock = (int)book.Copies;
                String strCopies = stock.ToString();
                ViewBag.Message = "Sorry! We only have " + strCopies + " copies currently in stock.";
            }*/
            Book book = _context.Books.Find(idBook);
            pd.Book = book;
            pd.ProcurementBookCost = pd.Book.Cost;
            TempData["Book"] = idBook;
            return View("AddToOrder", pd);
        }

        [HttpPost]
        public IActionResult AddToOrder(ProcurementDetail pd)
        {
            int? idBook = (int?)TempData["Book"];

            // Associate the selected book with the order detail
            Book book = _context.Books.Find(idBook);

            pd.Book = book;
            Procurement proc = _context.Procurements.Find(pd.Procurement.ProcurementID);

            pd.Procurement = proc;

            // Update Book's cost
            book.Cost = pd.ProcurementBookCost;

            //pd.Quantity = pd.CopiesToOrder;

            pd.ProcurementExtendedBookCost = pd.Quantity * pd.ProcurementBookCost; // Quantity only changed in cart so in OrderDetails/Edit

            AppUser currUser = _context.AppUsers.FirstOrDefault(x => x.UserName == User.Identity.Name);

            //update procurement
            //pd.Procurement.ProcurementDate = DateTime.Today;
            //pd.Procurement.AppUser = currUser;
            //pd.Procurement.IsPending = true;
            //pd.Procurement.IsReceived = false;

            if (ModelState.IsValid)
            {
                _context.ProcurementDetails.Add(pd);
                _context.SaveChanges();
                return RedirectToAction("Details", new { id = pd.Procurement.ProcurementID });
            }
            Book bk = _context.Books.Find(idBook);

            TempData["Book"] = idBook;
            return View("AddToOrder", pd);
        }

        // POST: Procurements/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        /*[HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProcurementID,ProcurementOrderer,ProcurementDate")] Procurement procurement)
        {
        
            procurement.ProcurementDate = System.DateTime.Today;
            //var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            //AppUser currentUser = _context.Users.FirstOrDefault(x => x.Id == userID);
            //procurement.Customer = currentUser;

            if (ModelState.IsValid)
            {
                _context.Add(procurement);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(procurement);
        }*/

        // Function to finalize order and update database
        public async Task<IActionResult> FinalReorder(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Procurement procurement = await _context.Procurements.Include(r => r.ProcurementDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.ProcurementID == id);

            // Update properties to finalize order process
            List<ProcurementDetail> pds = procurement.ProcurementDetails; //list of procurement details

            Book orderedBook;

            foreach (ProcurementDetail procdet in pds)
            {
                orderedBook = procdet.Book;
                orderedBook.TotalQuantitySold = procdet.Quantity + orderedBook.TotalQuantitySold;
                orderedBook.TotalCost = orderedBook.TotalCost + procdet.ProcurementExtendedBookCost;

                if (orderedBook.AverageCost == 0)
                {
                    orderedBook.AverageCost = orderedBook.Cost;
                }
                else
                {
                    orderedBook.AverageCost = orderedBook.TotalCost / orderedBook.TotalQuantitySold;
                }

                _context.Books.Update(orderedBook);
                _context.SaveChanges();

            }

            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);

            procurement.AppUser = user;
            procurement.ProcurementDate = DateTime.Today;
            procurement.IsPending = true;


            if (ModelState.IsValid)
            {

                _context.Procurements.Update(procurement);
                await _context.SaveChangesAsync();
                return View("ReorderConfirm");

            }



            return View("Index");


        }

        //Automatic Reorder
        public async Task<IActionResult> AutomaticCreate()
        {

            //Create Procurmenet
            Procurement proc = new Procurement();
            proc.ProcurementDate = System.DateTime.Today;


            //add in code to associate an order with a specific user
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            proc.AppUser = user;


            //add proc to the db
            if (ModelState.IsValid)
            {
                _context.Add(proc);
                await _context.SaveChangesAsync();
            }


            //find list of books that are below reorder difference
            var query = from r in _context.Books
                        select r;

            var book = query.ToList();


            List<Book> SelectedBooks = _context.Books.Include(r => r.Genre).Include(c => c.Procurements).ThenInclude(c => c.Procurement).Where(o => o.ReorderDiff < 0).ToList();


            List<ProcurementDetail> pdsList = new List<ProcurementDetail>();

            //create procurement details for each book 

            foreach (Book bk in SelectedBooks)
            {
                ProcurementDetail pd = new ProcurementDetail();
                pd.Procurement = proc;
                pd.Book = bk;
                pd.Book.UnreceivedOrderCount = 5;
                pd.Quantity = 5;
                pd.ProcurementBookCost = bk.Cost;
                pdsList.Add(pd);
                _context.Add(pd);
                await _context.SaveChangesAsync();

            }

            ViewBag.TotalBooks = _context.Books.Count();
            ViewBag.SelectedBooks = SelectedBooks.Count();
            ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " out of " + ViewBag.TotalBooks + " Books";
            return View("AutomaticReorder", proc);
        }


        public async Task<IActionResult> UpdatedList(Procurement proc)
        {


            //add in code to associate an order with a specific user
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            proc.AppUser = user;

            Procurement p = _context.Procurements.Include(o => o.ProcurementDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.ProcurementID == proc.ProcurementID);

            //add proc to the db
            if (ModelState.IsValid)
            {
                _context.Update(p);
                await _context.SaveChangesAsync();
            }

            //create a list of books form proc details
            List<Book> SelectedBooks = new List<Book>();

            foreach (ProcurementDetail pd in p.ProcurementDetails)
            {
                SelectedBooks.Add(pd.Book);
            }

            ViewBag.TotalBooks = _context.Books.Count();
            ViewBag.SelectedBooks = SelectedBooks.Count();
            ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " out of " + ViewBag.TotalBooks + " Books";
            return View("AutomaticReorder", p);
        }


        public IActionResult ManualCreate()
        {

            var query = from r in _context.Books
                        select r;

            var book = query.ToList();

            return View("~/Views/Home/Index.cshtml", book);
        }



        public IActionResult DetailedSearch()
        {

            var query = from r in _context.Books
                        select r;

            var book = query.ToList();

            return RedirectToAction("DetailedSearch", "Home", book);
        }




        // GET: Procurements/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var procurement = await _context.Procurements.FindAsync(id);
            if (procurement == null)
            {
                return NotFound();
            }
            return View(procurement);
        }



        // POST: Procurements/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProcurementID,ProcurementOrderer,ProcurementDate,ProcurementOrderTotal")] Procurement procurement)
        {

            if (id != procurement.ProcurementID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {

                    _context.Update(procurement);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProcurementExists(procurement.ProcurementID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(procurement);
        }

        // GET: Procurements/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var procurement = await _context.Procurements
                .FirstOrDefaultAsync(m => m.ProcurementID == id);
            if (procurement == null)
            {
                return NotFound();
            }

            return View(procurement);
        }

        // POST: Procurements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var procurement = await _context.Procurements.FindAsync(id);
            _context.Procurements.Remove(procurement);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public RedirectToActionResult DetailsFromNav()
        {
            Procurement procurement = _context.Procurements.Include(r => r.ProcurementDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.IsPending == false && o.AppUser.UserName == User.Identity.Name); // add customerid == identy user
            if (procurement == null)
            {
                return RedirectToAction("ShowEmptyCart");
            }

            return RedirectToAction("Details", new { id = procurement.ProcurementID });
        }

        public ViewResult ShowEmptyCart()
        {
            return View("EmptyReorderCart");
        }

        private bool ProcurementExists(int id)
        {
            return _context.Procurements.Any(e => e.ProcurementID == id);
        }

        //automatically reorder all the books that are below the reorder point 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AutomaticReorder()
        {


            return View("Index");

        }



        public async Task<IActionResult> BooksCheckIn()
        {

            List<ProcurementDetail> pds = new List<ProcurementDetail>();

            List<Procurement> p = _context.Procurements.Include(c => c.AppUser).Include(c => c.ProcurementDetails).ThenInclude(c => c.Book).
                                          Where(c => c.IsPending == true).ToList();


            foreach (Procurement procurement in p)
            {
                foreach (ProcurementDetail pd in procurement.ProcurementDetails)
                {
                    if (pd.IsReceived == false)
                    {
                        pds.Add(pd);
                    }
                }

            }



            return View("BooksCheckIn", pds);


        }


        public async Task<IActionResult> BooksArrived(int? id)
        {


            ProcurementDetail pd = new ProcurementDetail();
            pd = (ProcurementDetail)_context.ProcurementDetails.Include(c => c.Book).FirstOrDefault(c => c.ProcurementDetailID == id);


            Int32 bookid = pd.Book.BookID;

            Book bk = (Book)_context.Books.Where(c => c.BookID == bookid).FirstOrDefault();


            TempData["Book"] = bookid;
            return View("BooksArrived", bk);

           


        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BooksArrived(string RecievedOrderCount)
        {
            decimal OrderCount;

            int id = (int)TempData["Book"];

            Book bk = _context.Books.FirstOrDefault(c => c.BookID == id);

            try
            {
                OrderCount = Convert.ToDecimal(RecievedOrderCount);

            }

            catch
            {
                ViewBag.Message = "You must enter a number for Number of Copies Recieved";
                return View("BooksCheckIn");
            }


            if (bk.UnreceivedOrderCount < OrderCount)
            {
                ViewBag.Message = "Supplier Accidently Sent more Copies than Ordered, Copies will be Set to number Ordered, and rest will be returned!";
                bk.UnreceivedOrderCount = 0m;
                OrderCount = bk.UnreceivedOrderCount;
                bk.Copies = bk.Copies + OrderCount;

                List<ProcurementDetail> PdNonRecievedList = _context.ProcurementDetails.Include(c => c.Book).Where(c => c.IsReceived == false).ToList();

                foreach (ProcurementDetail pd in PdNonRecievedList)
                {
                    if (pd.Book.BookID == id)
                    {
                        pd.IsReceived = true;
                        _context.Books.Update(bk);
                        _context.ProcurementDetails.Update(pd);
                        _context.SaveChanges();
                    }
                }

                _context.Books.Update(bk);
                _context.SaveChanges();

            }

            if (bk.UnreceivedOrderCount == OrderCount)
            {
                bk.UnreceivedOrderCount = 0m;
                bk.Copies = bk.Copies + OrderCount;
                // bk.RecievedOrderCount = OrderCount;
                List<ProcurementDetail> PdNonRecievedList = _context.ProcurementDetails.Include(c => c.Book).Where(c => c.IsReceived == false).ToList();

                foreach (ProcurementDetail pd in PdNonRecievedList)
                {
                    if (pd.Book.BookID == id)
                    {
                        pd.IsReceived = true;
                        _context.Books.Update(bk);
                        _context.ProcurementDetails.Update(pd);
                        _context.SaveChanges();
                    }


                }

                _context.Books.Update(bk);
                _context.SaveChanges();

            }

            if (bk.UnreceivedOrderCount > OrderCount)
            {

                bk.UnreceivedOrderCount = bk.UnreceivedOrderCount - OrderCount;
                bk.Copies = bk.Copies + OrderCount;
                _context.Books.Update(bk);
                _context.SaveChanges();


            }



            //bk.Copies = bk.Copies + OrderCount;


            //_context.Books.Update(bk);
            //_context.SaveChanges();



            List<ProcurementDetail> pds = new List<ProcurementDetail>();

            List<Procurement> p = _context.Procurements.Include(c => c.AppUser).Include(c => c.ProcurementDetails).ThenInclude(c => c.Book).
                                          Where(c => c.IsPending == true).ToList();

            foreach (Procurement procurement in p)
            {
                foreach (ProcurementDetail pd in procurement.ProcurementDetails)
                {
                    if (pd.IsReceived == false)
                    {
                        pds.Add(pd);
                    }
                }

            }

            return View("BooksCheckIn", pds);

        }





    }
}

        





