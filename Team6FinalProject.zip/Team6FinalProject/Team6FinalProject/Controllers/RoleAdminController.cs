﻿//TO: Change this using statement to match your project
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

//TO: Update these using statements to match your project
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

//TO: Change this namespace to match your project
namespace Team6FinalProject.Controllers
{
    //DO: Uncomment this line once you have roles working correctly
    [Authorize(Roles = "Manager,Employee")]
    public class RoleAdminController : Controller
    {
        private AppDbContext _db;
        private UserManager<AppUser> _userManager;
        private RoleManager<IdentityRole> _roleManager;





        public RoleAdminController(AppDbContext context, UserManager<AppUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _db = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }


        // GET: /RoleAdmin/
        public async Task<ActionResult> Index()
        {
            List<RoleEditModel> roles = new List<RoleEditModel>();

            foreach (IdentityRole role in _roleManager.Roles)
            {
                List<AppUser> members = new List<AppUser>();
                List<AppUser> nonMembers = new List<AppUser>();

                foreach (AppUser user in _userManager.Users)
                {
                    var list = await _userManager.IsInRoleAsync(user, role.Name) ? members : nonMembers;
                    list.Add(user);
                }
                RoleEditModel re = new RoleEditModel();
                re.Role = role;
                re.Members = members;
                re.NonMembers = nonMembers;
                roles.Add(re);
            }
            return View(roles);
        }


        // Create

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Create([Required] string name)
        {
            if (ModelState.IsValid)
            {
                IdentityResult result = await _roleManager.CreateAsync(new IdentityRole(name));

                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    AddErrorsFromResult(result);
                }
            }

            //if code gets this far, we need to show an error
            return View("Index");
        }


        [Authorize(Roles = "Manager")]
        public ActionResult RegisterEmployee()
        {
            return View();
        }

        
        
        //DisableUser
        public async Task<ActionResult> DisableUser(string Id)
        {
            AppUser user = _db.Users.FirstOrDefault(i => i.Id == Id);
            TempData["UserID"] = Id;


            if (user == null)
            {
                return NotFound();
            }

            //don't pass in user, thenit is blank

            return View(user);
        }

        //Post 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DisableUser(AppUser model)
        {
            string UserID = (string)TempData["UserID"];
            if (!ModelState.IsValid)
            {

                var modelErrors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var modelError in modelState.Errors)
                    {
                        modelErrors.Add(modelError.ErrorMessage);
                    }
                    return View(model);
                }




            }
            AppUser userLoggedIn = _db.AppUsers.Find(UserID);

            userLoggedIn.IsDisabled = true;

            _db.Update(userLoggedIn);
            _db.SaveChanges();


            return RedirectToAction("Index", "RoleAdmin");
        }




            //Enable Users


            //DisableUser
            public async Task<ActionResult> EnableUser(string Id)
            {
                AppUser user = _db.Users.FirstOrDefault(i => i.Id == Id);
                TempData["UserID"] = Id;


                if (user == null)
                {
                    return NotFound();
                }

                //don't pass in user, thenit is blank

                return View(user);
            }

        //Post 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> EnableUser(AppUser model)
        {
            string UserID = (string)TempData["UserID"];
            if (!ModelState.IsValid)
            {

                var modelErrors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var modelError in modelState.Errors)
                    {
                        modelErrors.Add(modelError.ErrorMessage);
                    }
                    return View(model);
                }




            }
            AppUser userLoggedIn = _db.AppUsers.Find(UserID);

            userLoggedIn.IsDisabled = false;

            _db.Update(userLoggedIn);
            _db.SaveChanges();


            return RedirectToAction("Index", "RoleAdmin");















        }











        // GET: /RoleAdmin/

        //Getting Undisabeld Users to disable  
        public async Task<ActionResult> DisableCustomer([Required] string name)

        {
            DisableAccount da = new DisableAccount();


            foreach (AppUser user in _userManager.Users)
            {

                bool customers = await _userManager.IsInRoleAsync(user, "Customer");
                if (customers == true)
                {
                    if (user.IsDisabled == true)
                    {
                        da.EnabledCustomer.Add(user);
                        Console.WriteLine(da);

                        continue;
                    }
                    da.EnabledCustomer.Add(user);

                }
            }
            return RedirectToAction("DisableCustomer", da);


        }




        public async Task<ActionResult> GetAllCustomers()
        {
            List<ChangeAccountDetailsModel> cadms = new List<ChangeAccountDetailsModel>();
            foreach (IdentityRole role in _roleManager.Roles)
            {
                List<AppUser> members = new List<AppUser>();
                List<AppUser> nonMembers = new List<AppUser>();

                foreach (AppUser user in _userManager.Users)
                {
                    var list = await _userManager.IsInRoleAsync(user, "Customer") ? members : nonMembers;
                    list.Add(user);

                }
                foreach (AppUser au in members)
                {


                    ChangeAccountDetailsModel cadm = new ChangeAccountDetailsModel();

                    cadm.UserID = au.Id;
                    cadm.FirstName = au.FirstName;
                    cadm.LastName = au.LastName;
                    cadm.Email = au.Email;
                    cadm.PhoneNumber = au.PhoneNumber;
                    cadm.StreetAddress = au.StreetAddress;
                    cadm.City = au.City;
                    cadm.State = au.State;
                    cadm.ZipCode = au.ZipCode;



                    cadms.Add(cadm);
                }

            }
            return View("GetAllCustomers", cadms);
        }

        [Authorize(Roles = "Manager")]
        public async Task<ActionResult> GetAllEmployees()
        {
            List<ChangeAccountDetailsModel> ecadms = new List<ChangeAccountDetailsModel>();
            foreach (IdentityRole role in _roleManager.Roles)
            {
                List<AppUser> members = new List<AppUser>();
                List<AppUser> nonMembers = new List<AppUser>();

                foreach (AppUser user in _userManager.Users)
                {
                    var list = await _userManager.IsInRoleAsync(user, "Employee") ? members : nonMembers;
                    list.Add(user);

                }
                foreach (AppUser au in members)
                {


                    ChangeAccountDetailsModel ecadm = new ChangeAccountDetailsModel();

                    ecadm.UserID = au.Id;
                    ecadm.FirstName = au.FirstName;
                    ecadm.LastName = au.LastName;
                    ecadm.Email = au.Email;
                    ecadm.PhoneNumber = au.PhoneNumber;
                    ecadm.StreetAddress = au.StreetAddress;
                    ecadm.City = au.City;
                    ecadm.State = au.State;
                    ecadm.ZipCode = au.ZipCode;



                    ecadms.Add(ecadm);
                }

            }
            return View("GetAllEmployees", ecadms);
        }



        [Authorize(Roles = "Manager")]
        public async Task<ActionResult> GetAllManagers()
        {
            List<ChangeAccountDetailsModel> cadms = new List<ChangeAccountDetailsModel>();
            foreach (IdentityRole role in _roleManager.Roles)
            {
                List<AppUser> members = new List<AppUser>();
                List<AppUser> nonMembers = new List<AppUser>();

                foreach (AppUser user in _userManager.Users)
                {
                    var list = await _userManager.IsInRoleAsync(user, "Manager") ? members : nonMembers;
                    list.Add(user);

                }
                foreach (AppUser au in members)
                {


                    ChangeAccountDetailsModel cadm = new ChangeAccountDetailsModel();

                    cadm.UserID = au.Id;
                    cadm.FirstName = au.FirstName;
                    cadm.LastName = au.LastName;
                    cadm.Email = au.Email;
                    cadm.PhoneNumber = au.PhoneNumber;
                    cadm.StreetAddress = au.StreetAddress;
                    cadm.City = au.City;
                    cadm.State = au.State;
                    cadm.ZipCode = au.ZipCode;



                    cadms.Add(cadm);
                }

            }
            return View("GetAllManagers", cadms);
        }















        /*

    public async Task<ActionResult> DisableEmployee()
    {
        DisableAccount da = new DisableAccount();

        //Get employee from App Users


        foreach (AppUser user in _userManager.Users)
        {
            var managers = await _userManager.IsInRoleAsync(user, "Manager");
            da.Managers.Add(user);

            // Ignore disabled users 
            if (user.IsDisabled == true)
            {
                continue;
            }
            da.EnabledCustomer.Add(user);

        }
        return View(da);
    }








    //Disabling a User Access

    public async Task<ActionResult> EnableUser()
    {
        DisableAccount da = new DisableAccount();


        foreach (AppUser user in _userManager.Users)
        {
            // Ignore enabled users
            if (user.IsDisabled == false)
            {
                continue;
            }
          //  DisabledCustomer.Add(user);
        }
        return View(); // Disabled Customer
    }



    public async Task<ActionResult> EnableEmployee()
    {
        DisableAccount da = new DisableAccount();


        foreach (AppUser user in _userManager.Users)
        {
            // Ignore enabled users
            if (user.IsDisabled == false)
            {
                continue;
            }
            //DisabledEmployee.Add(user);
        }
        return View(); // Disabled Employee
    }












    /*
            [HttpPost]
            public async Task<ActionResult> DisableUser([Required] string name)

            {
                if (ModelState.IsValid)
                {

                    List<AppUser> NonDisabledUsers = 

                    if (result.Succeeded)
                    {
                        return RedirectToAction("Index");
        }
                    else
                    {
                        AddErrorsFromResult(result);
    }
     return View("Index");
            }
                }
                */

        //if code gets this far, we need to show an error






        [Authorize(Roles = "Manager")]
        [HttpPost]
        public async Task<ActionResult> RegisterEmployee([Required] string name)
        {
            if (ModelState.IsValid)
            {
                IdentityResult result = await _roleManager.CreateAsync(new IdentityRole(name));

                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    AddErrorsFromResult(result);
                }
            }

            //if code gets this far, we need to show an error
            return View("Index");
        }


        [Authorize(Roles = "Manager,Employee")]
        public ActionResult RegisterCustomer()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> RegisterCustomer([Required] string name)
        {
            if (ModelState.IsValid)
            {
                IdentityResult result = await _roleManager.CreateAsync(new IdentityRole(name));

                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    AddErrorsFromResult(result);
                }
            }

            //if code gets this far, we need to show an error
            return View("Index");
        }




        public async Task<ActionResult> Edit(string id)
        {
            IdentityRole role = await _roleManager.FindByIdAsync(id);
            List<AppUser> members = new List<AppUser>();
            List<AppUser> nonMembers = new List<AppUser>();
            foreach (AppUser user in _userManager.Users)
            {
                var list = await _userManager.IsInRoleAsync(user, role.Name) ? members : nonMembers;
                list.Add(user);
            }
            return View(new RoleEditModel { Role = role, Members = members, NonMembers = nonMembers });
        }

        [HttpPost]
        public async Task<ActionResult> Edit(RoleModificationModel model)
        {
            IdentityResult result;
            if (ModelState.IsValid)
            {
                foreach (string userId in model.IdsToAdd ?? new string[] { })
                {
                    AppUser user = await _userManager.FindByIdAsync(userId);
                    result = await _userManager.AddToRoleAsync(user, model.RoleName);
                    if (!result.Succeeded)
                    {
                        return View("Error", result.Errors);
                    }
                }

                foreach (string userId in model.IdsToDelete ?? new string[] { })
                {
                    AppUser user = await _userManager.FindByIdAsync(userId);
                    result = await _userManager.RemoveFromRoleAsync(user, model.RoleName);
                    if (!result.Succeeded)
                    {
                        return View("Error", result.Errors);
                    }
                }

                foreach (string userId in model.IdsToDisable ?? new string[] { })
                {
                    AppUser user = await _userManager.FindByIdAsync(userId);

                    user.IsDisabled = true;


                }



                foreach (string userId in model.IdsToEnable ?? new string[] { })
                {
                    AppUser user = await _userManager.FindByIdAsync(userId);
                    user.IsDisabled = false;


                }
                return RedirectToAction("Index");


            }
            return View("Error", new string[] { "Role Not Found" });
        }




        private void AddErrorsFromResult(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
        }




    }
}