using System; using System.Collections.Generic; using System.Linq; using System.Security.Claims;
using System.Threading.Tasks; using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.Rendering; using Microsoft.EntityFrameworkCore; using Team6FinalProject.DAL; using Team6FinalProject.Models;  namespace Team6FinalProject.Controllers {     public class ReviewsController : Controller     {         private readonly AppDbContext _context;          public ReviewsController(AppDbContext context)         {             _context = context;         }          // GET: Reviews         public async Task<IActionResult> Index()         {
            return View(await _context.Reviews.Include(o => o.Book).ToListAsync());          }



        // GET: Reviews
        [Authorize(Roles = "Manager, Employee")]
        public async Task<IActionResult> ViewPendingReviews()         {              var query = from r in _context.Reviews                         select r;              var review = query.Include(o => o.Book).Where(r => r.IsPending == true).ToList();              return View("PendingReviews", review);         }

        // GET: Reviews
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> ViewAllReviews()         {              var query = from r in _context.Reviews                         select r;              var review = query.Include(o => o.Book).Include(o => o.Approver).Include(o => o.Author).ToList();              return View("ManagerReviews", review);         }


        // GET: Reviews/Details/5
        public async Task<IActionResult> Details(int? id)         {              Review review = _context.Reviews.FirstOrDefault(o => o.ReviewID == id);              return View(review);         }

        // GET: Reviews/Create
        [Authorize]         public IActionResult Create(int? id)         {             Book bk = _context.Books.Find(id);
            TempData["Book"] = bk.BookID;              Review rv = _context.Reviews.Include(o => o.Book).                                 FirstOrDefault(o => o.ReviewID == id);              //no review exists              if (rv == null)             {                 return View("CreatePost", rv);             }             // Else: there is already a review, need to review it             return RedirectToAction("Index", new { id = rv.ReviewID, idBook = id });          }

   
        // POST: Reviews/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]         [Authorize]
        public async Task<IActionResult> CreatePost([Bind("ReviewID,ReviewDate,Rating,IsApproved,IsPending,WrittenReview")] Review review)
        {

        
            review.ReviewDate = System.DateTime.Today;
            var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);             AppUser currentUser = _context.Users.FirstOrDefault(x => x.Id == userID);             review.Author = currentUser;             review.WrittenReview = review.WrittenReview;             review.Rating = review.Rating;             review.IsApproved = false;             review.IsPending = true;               int? idBook = (int?)TempData["Book"];             Book bk = _context.Books.                          FirstOrDefault(o => o.BookID == idBook);              review.Book = bk; 

            if (ModelState.IsValid)
            {
                _context.Add(review);
                await _context.SaveChangesAsync();
                //return RedirectToAction(nameof(Index));
                return RedirectToAction("Details", new { id = review.ReviewID });
                //return RedirectToAction("EvaluateReview", new { id = review.ReviewID, idBook = idBk });
            }
            return RedirectToAction("Index", new { id = review.ReviewID });
        }

         [Authorize(Roles = "Manager, Employee")]
        public ActionResult ApproveReview(int? id, Review review)
        {

            // Check if inputs are null              if (id == null)             {                 return View("Error", new string[] { "You must specify a book to review!" });             }              Review dbrev = _context.Reviews.Include(o => o.Book).FirstOrDefault(o => o.ReviewID == id);              // Check if review exists in database             if (dbrev == null)             {                 return View("Error", new string[] { "Review not found!" });             }              var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);             AppUser currentUser = _context.Users.FirstOrDefault(x => x.Id == userID);             dbrev.Approver = currentUser;             dbrev.IsPending = false;             dbrev.IsApproved = true;              //list all approvedreviews for this book             Book reviewedBook;             reviewedBook = dbrev.Book;             List<Review> ApprovedReviews = _context.Reviews.Where(c => c.IsApproved == true && c.Book.BookID == reviewedBook.BookID).ToList();


            int NumReviewCount = ApprovedReviews.Count();                          if (reviewedBook.RatingAverage == 0)             {                 reviewedBook.RatingAverage = dbrev.Rating;             }                 else             {                 reviewedBook.RatingAverage = ((reviewedBook.RatingAverage * NumReviewCount) + dbrev.Rating) / (NumReviewCount + 1);             }              _context.Reviews.Update(dbrev);             _context.Books.Update(reviewedBook);              _context.SaveChanges();              return View("ApproveReview", dbrev);


        }           [Authorize(Roles = "Manager, Employee")]         public ActionResult RejectReview(int? id, Review review)         {             // Check if inputs are null             if (id == null)             {                 return View("Error", new string[] { "You must specify a book to review!" });             }              Review dbrev = _context.Reviews.Include(o => o.Book).FirstOrDefault(o => o.ReviewID == id);              // Check if review exists in database             if (dbrev == null)             {                 return View("Error", new string[] { "Review not found!" });             }              var userID = this.User.FindFirstValue(ClaimTypes.NameIdentifier);             AppUser currentUser = _context.Users.FirstOrDefault(x => x.Id == userID);             dbrev.Approver = currentUser;             dbrev.IsPending = false;             dbrev.IsApproved = false;              _context.Reviews.Update(dbrev);             _context.SaveChanges();              return View("RejectReview", dbrev);          }



        // GET: Reviews/Edit/5
        [Authorize(Roles = "Manager, Employee")]
        public async Task<IActionResult> Edit(int? id)         {             if (id == null)             {                 return NotFound();             }              var review = await _context.Reviews.FindAsync(id);             if (review == null)             {                 return NotFound();             }             return View(review);         }          // POST: Reviews/Edit/5         // To protect from overposting attacks, please enable the specific properties you want to bind to, for          // more details see http://go.microsoft.com/fwlink/?LinkId=317598.         [HttpPost]         [ValidateAntiForgeryToken]         [Authorize(Roles = "Manager, Employee")]         public async Task<IActionResult> Edit(int id, [Bind("ReviewID,Rating,IsApproved,WrittenReview")] Review review)         {             if (id != review.ReviewID)             {                 return NotFound();             }


            if (ModelState.IsValid)             {                  review.IsPending = true;                 try                 {                     _context.Update(review);                     await _context.SaveChangesAsync();                 }                 catch (DbUpdateConcurrencyException)                 {                     if (!ReviewExists(review.ReviewID))                     {                         return NotFound();                     }                     else                     {                         throw;                     }                 }                 return RedirectToAction(nameof(Index));             }             return View(review);         }

        // GET: Reviews/Delete/5
        [Authorize(Roles = "Manager, Employee")]         public async Task<IActionResult> Delete(int? id)         {             if (id == null)             {                 return NotFound();             }              var review = await _context.Reviews                 .FirstOrDefaultAsync(m => m.ReviewID == id);             if (review == null)             {                 return NotFound();             }              return View(review);         }          // POST: Reviews/Delete/5         [HttpPost, ActionName("Delete")]         [ValidateAntiForgeryToken]
        [Authorize(Roles = "Manager, Employee")]         public async Task<IActionResult> DeleteConfirmed(int id)         {             var review = await _context.Reviews.FindAsync(id);             _context.Reviews.Remove(review);             await _context.SaveChangesAsync();             return RedirectToAction(nameof(Index));         }          private bool ReviewExists(int id)         {             return _context.Reviews.Any(e => e.ReviewID == id);         }           //public ActionResult CheckIfBookBought          //{         //}          //public ActionResult CheckIfUserReviewExists         //{         //}          } }
