using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

namespace Team6FinalProject.Controllers
{
    [Authorize]
    public class OrderDetailsController : Controller
    {
        private readonly AppDbContext _context;

        public OrderDetailsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: OrderDetails
        public async Task<IActionResult> Index()
        {
            return View(await _context.OrderDetails.ToListAsync());
        }

        // GET: OrderDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderDetail = await _context.OrderDetails
                .FirstOrDefaultAsync(m => m.OrderDetailID == id);
            if (orderDetail == null)
            {
                return NotFound();
            }

            return View(orderDetail);
        }

        // GET: OrderDetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: OrderDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OrderDetailID,Quantity,PricePaid")] OrderDetail orderDetail)
        {
            if (ModelState.IsValid)
            {
                _context.Add(orderDetail);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(orderDetail);
        }

        // GET: OrderDetails/Edit/5
        public async Task<IActionResult> Edit(int? id, decimal? quantityError)
        {
            if (id == null)
            {
                return NotFound();
            }

            var orderDetail = await _context.OrderDetails.Include(o => o.Book).FirstOrDefaultAsync(o => o.OrderDetailID == id);
            if (orderDetail == null)
            {
                return NotFound();
            }

            if (quantityError == 1m)
            {
                Book book = orderDetail.Book;
                int stock = (int)book.Copies;
                String strCopies = stock.ToString();
                ViewBag.Message = "Sorry! We only have " + strCopies + " copies currently in stock.";
            }
            return View(orderDetail);
        }

        // POST: OrderDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(OrderDetail orderDetail)
        {
            //Find the related registration detail in the database
            OrderDetail DbOrdDet = _context.OrderDetails
                                        .Include(r => r.Order)
                                           .Include(r => r.Book)
                                        .FirstOrDefault(r => r.OrderDetailID ==
                                                            orderDetail.OrderDetailID);

            // Don't allow quantity greater than copies in stock
            if (orderDetail.Quantity > DbOrdDet.Book.Copies)
            {
                decimal Error = 1m;
                return RedirectToAction("Edit", new { id = DbOrdDet.OrderDetailID, quantityError = Error });
            }


            //update the related fields
            DbOrdDet.Quantity = orderDetail.Quantity;
            //DbOrdDet.ProductPrice = orderDetail.ProductPrice;
            DbOrdDet.ExtendedPrice = DbOrdDet.PricePaid * DbOrdDet.Quantity;

            //update the database
            if (ModelState.IsValid)
            {
                _context.OrderDetails.Update(DbOrdDet);
                _context.SaveChanges();
                //return to the order details
                return RedirectToAction("Details", "Orders", new { id = DbOrdDet.Order.OrderID });
            }
            return View("Edit", DbOrdDet);

        }


        // GET: OrderDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var orderDetail = await _context.OrderDetails
                .FirstOrDefaultAsync(m => m.OrderDetailID == id);
            if (orderDetail == null)
            {
                return NotFound();
            }


            return View(orderDetail);
        }






        // POST: OrderDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            //var orderDetail = await _context.OrderDetails.FindAsync(id);

            var orderDetail = await _context.OrderDetails.Include(o => o.Order)
                .FirstOrDefaultAsync(m => m.OrderDetailID == id);

            int id2 = orderDetail.Order.OrderID;


            _context.OrderDetails.Remove(orderDetail);
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", "Orders", new { id = id2 });
        }


        private bool OrderDetailExists(int id)
        {
            return _context.OrderDetails.Any(e => e.OrderDetailID == id);
        }
    }
}