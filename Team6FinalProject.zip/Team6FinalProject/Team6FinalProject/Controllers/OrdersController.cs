﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Team6FinalProject.Models;
using Team6FinalProject.DAL;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Team6FinalProject.Controllers;
using Team6FinalProject.Utilities;
using Microsoft.AspNetCore.Authorization;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860
namespace Team6FinalProject.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly AppDbContext _context;

        public OrdersController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            List<Order> Orders = new List<Order>();
            Orders = _context.Orders.Include(o => o.OrderDetails).Where(o => o.AppUser.UserName == User.Identity.Name).ToList();
            return View(Orders);


        }

        // GET: Orders/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Order order = await _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.OrderID == id);

            if (order == null)
            {
                return NotFound();
            }

            // Create Lists to store book titles for viewbag messages
            List<String> BooksOutOfStock = new List<String>(); List<String> BooksDiscont = new List<String>();

            // Get the current cart's orderdetails
            var cartDetails = order.OrderDetails.ToList();

            // Loop through the order details in the cart and check if book price has changed, book is out of stock
            // and if book has been discontinued
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            foreach (OrderDetail od in cartDetails)
            {
                // find the given orderdetail's book
                int bkId = od.Book.BookID;
                Book book = _context.Books.FirstOrDefault(b => b.BookID == bkId);

                // 1. Check if the book has been discontinued
                if (book.IsDicontinued == true)
                {
                    BooksDiscont.Add(book.Title);
                    string emailBody = book.Title + "was discontinued and removed from your cart.";
                    string emailSubject = "Book in your cart was discontinued";
                    EmailMessaging.SendEmail(user.Email, emailSubject, emailBody);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 2. Check if book has gone out of stock
                else if (book.Copies <= 0) // Change to IsInStock after checkout is finished
                {
                    BooksOutOfStock.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 3. Check if book's price has changed
                else if (book.Price != od.PricePaid)
                {
                    od.PricePaid = book.Price;
                    _context.OrderDetails.Update(od);
                    _context.SaveChanges();
                }
            }
            // Strings to become ViewBag messages
            String Message1 = "";
            String Message2 = "";

            // If a book in the cart has gone out of stock
            if (BooksOutOfStock.Any())
            {
                if (BooksOutOfStock.Count() > 1) // Multiple books went out of stock
                {
                    for (int x = 0; x < BooksOutOfStock.Count(); x++)
                    {
                        if (x == BooksOutOfStock.Count() - 1)
                        {
                            Message1 = Message1 + BooksOutOfStock[x]; // If last book in list don't add comma
                        }
                        else
                        {
                            Message1 = Message1 + BooksOutOfStock[x] + ", ";// Not last book in list so add comma
                        }
                    }
                    Message1 = Message1 + " are no longer in stock and were removed from your cart";
                }
                else // Only one book went out of stock
                {
                    Message1 = BooksOutOfStock[0] + " is no longer in stock and was removed from your cart";
                }
            }

            // If a book in the cart has been discontinued
            if (BooksDiscont.Count() > 0)
            {
                if (BooksDiscont.Count() > 1) // Multiple books were discontinued
                {
                    for (int x = 0; x < BooksDiscont.Count(); x++)
                    {
                        if (x == BooksDiscont.Count() - 1)
                        {
                            Message2 = Message2 + BooksDiscont[x];
                        }
                        else
                        {
                            Message2 = Message2 + BooksDiscont[x] + ", ";
                        }
                    }
                    Message2 = Message2 + " are no longer being sold and were removed from your cart";
                }
                else // Only one book was discontinued
                {
                    Message1 = BooksDiscont[0] + " is no longer being sold and was removed from your cart";
                }
            }

            CalculateShipping(order.OrderID);

            ViewBag.Message1 = Message1;
            ViewBag.Message2 = Message2;
            return View(order);
        }

        //GET Orders/Create
        public IActionResult Create(int? id)
        {
            // Check if book is in stock
            Book bk = _context.Books.Find(id);

            if (bk.IsDicontinued == true)
            {
                return View("Discontinued");
            }

            if (bk.Copies <= 0) //maybe change to IsInStock == false when we update that column
            {
                return View("OutOfStock");
            }
            // Find current cart
            Order ord = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.IsPending == false && o.AppUser.UserName == User.Identity.Name); // Add to query, o=>o.Order.AppUser.CustomerID == current customer

            // If there is no cart, then create a new order/cart
            if (ord == null)
            {
                return RedirectToAction("CreatePost", new { idBk = id });
            }
            // Else: there is already a cart, so just add to it
            TempData["order"] = ord.OrderID;
            return RedirectToAction("AddToOrder", new { id = ord.OrderID, idBook = id });

        }
        // POST Orders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePost([Bind("OrderID", "OrderDate")] int? idBk)
        {
            Order order = new Order();
            order.OrderDate = System.DateTime.Today;


            //add in code to associate an order with a specific user
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            order.AppUser = user;
            Book book = _context.Books.Find(idBk);
            Order ord = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.IsPending == false && o.AppUser.UserName == User.Identity.Name);

            if (ModelState.IsValid)
            {
                _context.Add(order);
                await _context.SaveChangesAsync();
                return RedirectToAction("AddToOrder", new { id = order.OrderID, idBook = idBk });
            }
            return NotFound();
        }

        public IActionResult AddToOrder(int? id, int? idBook, decimal? quantityError)
        {
            Book bk = _context.Books.Find(idBook);
            int? orderID = (int?)TempData["order"];
            Order order = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o =>o.Book).FirstOrDefault(o => o.OrderID == id);
            List<Book> bks = new List<Book>();
            foreach (OrderDetail ode in order.OrderDetails)
            {
                bks.Add(ode.Book);
            }
            if (bks.Contains(bk))
            {
                ViewBag.Message = "Sorry! That book is already in your cart.";
                TempData["error"] = "Sorry! That book is already in your cart.";
                return RedirectToAction("Details", "Home", new {id = idBook});
            }
            // Check if inputs are null
            if (id == null || idBook == null)
            {
                return View("Error", new string[] { "You must specify an order to add!" });
            }

            // Find order created in previous function
            //Order ord = _context.Orders.FirstOrDefault(o => o.OrderID == id);
            Order ord = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.OrderID == id);

            // Check if order exists in database
            if (ord == null)
            {
                return View("Error", new string[] { "Order not found!" });
            }
            
            // Create order detail to be associated with ord
            OrderDetail od = new OrderDetail() { Order = ord };
            //ord.OrderDetails.Add(od);

            ViewBag.Message = quantityError;
            // Display Book title
            //Book bk = _context.Books.Find(idBook);
            if (quantityError == 1m)
            {
                Book book = _context.Books.Find(idBook);
                int stock = (int)book.Copies;
                String strCopies = stock.ToString();
                ViewBag.Message = "Sorry! We only have " + strCopies + " copies currently in stock.";
            }
            TempData["Book"] = idBook;
            return View("AddToOrder", od);
        }

        [HttpPost]
        public IActionResult AddToOrder(OrderDetail od)
        {
            int? idBook = (int?)TempData["Book"];
            // Associate the selected book with the order detail
            Book book = _context.Books.Find(idBook);

            od.Book = book;

            Order ord = _context.Orders.Find(od.Order.OrderID);

            od.Order = ord;

            // Don't allow quantity greater than copies in stock
            if (od.Quantity > od.Book.Copies)
            {
                decimal Error = 1m;
                return RedirectToAction("AddToOrder", new { id = ord.OrderID, idBook = book.BookID, quantityError = Error });
            }
            List<Book> bks = new List<Book>();
            foreach (OrderDetail ode in ord.OrderDetails)
            {
                bks.Add(ode.Book);
            }

            if (bks.Contains(od.Book))
            {
                ViewBag.Message = "Sorry! That book is already in your cart.";
                return RedirectToAction("Details", ord.OrderID);
            }

            // Give book the proper price
            od.PricePaid = od.Book.Price;

            od.ExtendedPrice = od.Quantity * od.Book.Price; // Quantity only changed in cart so in OrderDetails/Edit
            //!!!!!!

            if (ModelState.IsValid)
            {
                _context.OrderDetails.Add(od);
                _context.SaveChanges();
                return RedirectToAction("Details", new { id = od.Order.OrderID });
            }
            Book bk = _context.Books.Find(idBook);
            //ViewBag.Message = "Do you want to add " + bk.Title + " by " + bk.Author + " to your cart?";
            TempData["Book"] = idBook;
            return View("AddToOrder", od);
        }

        public void CalculateShipping(int? id)         {             Order ord = _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefault(r => r.OrderID == id);              decimal numberOfOrders = ord.OrderDetails.Count;              decimal totalQuantity = 0;

            if (numberOfOrders == 0)
            {
                ord.Shipping = 0.0m;
                return;
            }              if (numberOfOrders > 0)             {                 foreach (OrderDetail od in ord.OrderDetails)                 {                     totalQuantity = od.Quantity + totalQuantity;                 }             }              decimal quantityWoFirst = totalQuantity - 1;              decimal ShippingPrice = 3.5m + (1.50m * quantityWoFirst);              ord.Shipping = ShippingPrice;
            _context.SaveChangesAsync();         } 


        // GET: Orders/Edit
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Order order = await _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.OrderID == id);

            if (order == null)
            {
                return NotFound();
            }

            // Create Lists to store book titles for viewbag messages
            List<String> BooksOutOfStock = new List<String>(); List<String> BooksDiscont = new List<String>();

            // Get the current cart's orderdetails
            var cartDetails = order.OrderDetails.ToList();

            // Loop through the order details in the cart and check if book price has changed, book is out of stock
            // and if book has been discontinued
            foreach (OrderDetail od in cartDetails)
            {
                // find the given orderdetail's book
                int bkId = od.Book.BookID;
                Book book = _context.Books.FirstOrDefault(b => b.BookID == bkId);

                // 1. Check if the book has been discontinued
                if (book == null)
                {
                    BooksDiscont.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 2. Check if book has gone out of stock
                else if (book.Copies <= 0) // Change to IsInStock after checkout is finished
                {
                    BooksOutOfStock.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 3. Check if book's price has changed
                else if (book.Price != od.PricePaid)
                {
                    od.PricePaid = book.Price;
                    _context.OrderDetails.Update(od);
                    _context.SaveChanges();
                }
            }
            // Strings to become ViewBag messages
            String Message1 = "";
            String Message2 = "";

            // If a book in the cart has gone out of stock
            if (BooksOutOfStock.Any())
            {
                if (BooksOutOfStock.Count() > 1) // Multiple books went out of stock
                {
                    for (int x = 0; x < BooksOutOfStock.Count(); x++)
                    {
                        if (x == BooksOutOfStock.Count() - 1)
                        {
                            Message1 = Message1 + BooksOutOfStock[x]; // If last book in list don't add comma
                        }
                        else
                        {
                            Message1 = Message1 + BooksOutOfStock[x] + ", ";// Not last book in list so add comma
                        }
                    }
                    Message1 = Message1 + " are no longer in stock and were removed from your cart";
                }
                else // Only one book went out of stock
                {
                    Message1 = BooksOutOfStock[0] + " is no longer in stock and was removed from your cart";
                }
            }

            // If a book in the cart has been discontinued
            if (BooksDiscont.Any())
            {
                if (BooksDiscont.Count() > 1) // Multiple books were discontinued
                {
                    for (int x = 0; x < BooksDiscont.Count(); x++)
                    {
                        if (x == BooksDiscont.Count() - 1)
                        {
                            Message2 = Message2 + BooksDiscont[x];
                        }
                        else
                        {
                            Message2 = Message2 + BooksDiscont[x] + ", ";
                        }
                    }
                    Message2 = Message2 + " are no longer being sold and were removed from your cart";
                }
                else // Only one book was discontinued
                {
                    Message1 = BooksOutOfStock[0] + " is no longer being sold and was removed from your cart";
                }
            }

            ViewBag.Message1 = Message1;
            ViewBag.Message2 = Message2;
            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Order order)
        {
            //Find the related registration in the database
            Order DbOrd = _context.Orders.Find(order.OrderID);

            //Update the database
            _context.Orders.Update(DbOrd);

            //Save changes
            _context.SaveChanges();

            //Go back to index
            return RedirectToAction(nameof(Index));
        }

        public IActionResult RemoveFromOrder(int? id)
        {
            if (id == null)
            {
                return View("Error", new string[] { "You need to specify an order id" });
            }

            Order ord = _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefault(r => r.OrderID == id);

            if (ord == null || ord.OrderDetails.Count == 0)//registration is not found
            {
                return RedirectToAction("Details", new { id = id });
            }

            //pass the list of order details to the view
            return View(ord.OrderDetails);
        }

        public RedirectToActionResult DetailsFromNav ()
        {
            Order order = _context.Orders.Include(r => r.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.IsPending == false && o.AppUser.UserName == User.Identity.Name); // add customerid == identy user
            if (order == null)
            {
              return RedirectToAction("ShowEmptyCart");
            }

            return RedirectToAction("Details", new {id = order.OrderID});
        }

        public ViewResult ShowEmptyCart ()
        {
            return View("EmptyCart");
        }

    }
}