﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;
using Microsoft.AspNetCore.Identity;
using Team6FinalProject.Utilities;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Team6FinalProject.Controllers
{
    public class CheckoutsController : Controller
    {

        private readonly AppDbContext _context;

        public CheckoutsController(AppDbContext context)
        {
            _context = context;
        }


        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        // GET: get user information needed for checkout 
        public async Task<IActionResult> GetCreditCardCouponInfoAsync(int? id)
        {

            //present order summary with updated prices 
            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Order order = await _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.OrderID == id);

            if (order == null)
            {
                return NotFound();
            }

            // Create Lists to store book titles for viewbag messages
            List<String> BooksOutOfStock = new List<String>(); List<String> BooksDiscont = new List<String>();

            // Get the current cart's orderdetails
            var cartDetails = order.OrderDetails.ToList();

            // Loop through the order details in the cart and check if book price has changed, book is out of stock
            // and if book has been discontinued
            foreach (OrderDetail od in cartDetails)
            {
                // find the given orderdetail's book
                int bkId = od.Book.BookID;
                Book book = _context.Books.FirstOrDefault(b => b.BookID == bkId);

                // 1. Check if the book has been discontinued
                if (book == null)
                {
                    BooksDiscont.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 2. Check if book has gone out of stock
                else if (book.Copies <= 0) // Change to IsInStock after checkout is finished
                {
                    BooksOutOfStock.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 3. Check if book's price has changed
                else if (book.Price != od.PricePaid)
                {
                    od.PricePaid = book.Price;
                    _context.OrderDetails.Update(od);
                    _context.SaveChanges();
                }
            }
            // Strings to become ViewBag messages
            String Message1 = "";
            String Message2 = "";

            // If a book in the cart has gone out of stock
            if (BooksOutOfStock.Any())
            {
                if (BooksOutOfStock.Count() > 1) // Multiple books went out of stock
                {
                    for (int x = 0; x < BooksOutOfStock.Count(); x++)
                    {
                        if (x == BooksOutOfStock.Count() - 1)
                        {
                            Message1 = Message1 + BooksOutOfStock[x]; // If last book in list don't add comma
                        }
                        else
                        {
                            Message1 = Message1 + BooksOutOfStock[x] + ", ";// Not last book in list so add comma
                        }
                    }
                    Message1 = Message1 + " are no longer in stock and were removed from your cart";
                }
                else // Only one book went out of stock
                {
                    Message1 = BooksOutOfStock[0] + " is no longer in stock and was removed from your cart";
                }
            }

            // If a book in the cart has been discontinued
            if (BooksDiscont.Count() > 0)
            {
                if (BooksDiscont.Count() > 1) // Multiple books were discontinued
                {
                    for (int x = 0; x < BooksDiscont.Count(); x++)
                    {
                        if (x == BooksDiscont.Count() - 1)
                        {
                            Message2 = Message2 + BooksDiscont[x];
                        }
                        else
                        {
                            Message2 = Message2 + BooksDiscont[x] + ", ";
                        }
                    }
                    Message2 = Message2 + " are no longer being sold and were removed from your cart";
                }
                else // Only one book was discontinued
                {
                    Message1 = BooksOutOfStock[0] + " is no longer being sold and was removed from your cart";
                }
            }

            CalculateShipping(order.OrderID);

            //present list of credit cards to choose
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);


            ViewBag.AllCreditCards = GetCreditCards(user);

            ViewBag.Message1 = Message1;
            ViewBag.Message2 = Message2;

            TempData["Order"] = id;

            return View("Details", order);

        }

        private SelectList GetCreditCards(AppUser user)
        {

            List<CreditCard> userCreditCards = new List<CreditCard>();

            userCreditCards = _context.CreditCards.Where(u => u.AppUser.UserName == User.Identity.Name).ToList();

            //foreach (CreditCard cc in userCreditCards)
            //{
            //    String ccOut = "XXXX-XXXX-XXXX-" + cc.Card.Substring(12);
            //    cc.Card = ccOut;
            //}

            //create the multiselect with the overload for currently selected items
            SelectList cardList = new SelectList(userCreditCards, "CreditCardID", "Card");

            if (cardList == null)
            {
                cardList = new SelectList(Enumerable.Empty<SelectListItem>());
            }

            return cardList;
        }


        // POST: get user information needed for checkout 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GetCreditCardCouponInfoAsync(string UserCouponCode, int? SelectedCreditCard)
        {
            int? ordId = (int?)TempData["Order"];
            // Find current cart(order) and user
            Order ord = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(o => o.OrderID == ordId);
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
            // Check if they are using a card first
            if (SelectedCreditCard == null)
            {
                ViewBag.Message3 = "You must use a Credit Card to purchase your order";
                ViewBag.AllCreditCards = GetCreditCards(user);
                return View("Details", ord);
            }

            CreditCard currCC = _context.CreditCards.FirstOrDefault(c => c.CreditCardID == SelectedCreditCard);
            ord.CreditCardUsed = currCC;

            // Check if a coupon was entered
            if (UserCouponCode == null)
            {
                ord.AfterCouponOrderTotal = ord.OrderTotal;
                await _context.SaveChangesAsync();
                return View("OrderConfirmed", ord);
                // Return redirect to action to last place order function
            }
            //COUPON VALIDATION
            //check if Coupon entered is a valid coupon that a manager has created 

            // check if enabled coupon
            Coupon coup = _context.Coupons.FirstOrDefault(c => c.CouponCode == UserCouponCode);
            if (coup.IsDisabled == true)
            {
                TempData["Order"] = ordId;
                ViewBag.Message3 = "Sorry the Coupon Code that you entered is no longer valid.";
                ViewBag.AllCreditCards = GetCreditCards(user);
                return View("Details", ord);
            }

            int isCouponInList = 0;

            List<Coupon> CouponList = _context.Coupons.ToList();

            foreach (Coupon coupon in CouponList)
            {
                if (UserCouponCode == coupon.CouponCode)
                {
                    //Coupon is valid
                    isCouponInList = 1;
                }

            }


            //check if Coupon entered hasn't been used by the same user
            //AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);


            int userUsedCode = 0;

            //Coupon is a valid coupon
            if (isCouponInList == 1)
            {
                Coupon coupon = _context.Coupons.Include(c => c.Orders).FirstOrDefault(c => c.CouponCode == UserCouponCode);
                List<Order> CouponOrders = coupon.Orders;


                //has the same user used that code
                foreach (Order orders in CouponOrders)
                {
                    if (user == orders.AppUser)
                    {
                        userUsedCode = 1;
                    }
                }

            }

            //coupon does not exsist
            else
            {
                TempData["Order"] = ordId;
                ViewBag.Message3 = "Sorry the Coupon Code that you entered does not exsist.";
                ViewBag.AllCreditCards = GetCreditCards(user);
                return View("Details", ord);
            }

            //coupon code has already been used by customer
            if (userUsedCode == 1)
            {
                TempData["Order"] = ordId;
                ViewBag.Message3 = "Sorry you cannot apply a code you have already used.";
                ViewBag.AllCreditCards = GetCreditCards(user);
                return View("Details", ord);
            }

            // Find the coupon to be applied
            Coupon couponToApply = _context.Coupons.Include(c => c.Orders).ThenInclude(o => o.OrderDetails).FirstOrDefault(c => c.CouponCode == UserCouponCode);
            // Find Order
            //Order  = _context.Orders.Include(o => o.OrderDetails).ThenInclude(o => o.Book).FirstOrDefault(c => c.AppUser.UserName == User.Identity.Name && c.IsPending == false);
            // ** DEBUG HERE - Maybe delete order temp and just use ord from above***
            // Apply the coupon to the order


            List<OrderDetail> OrdDetList = ord.OrderDetails.ToList();


            //TO DO: Coupon should be applied to OrderDetails not order 
            if (couponToApply.PercentageOff != 0.0m && couponToApply.ShippingWhen == 0.0m) // Is a percentage off coupon
            {
                // Convert Percentage
                Decimal percentage = (100m - couponToApply.PercentageOff) / 100m;

                foreach (OrderDetail ordDet in OrdDetList)
                {
                    ordDet.PricePaid = ordDet.Book.Price * percentage;
                    ordDet.ExtendedPrice = ordDet.PricePaid * ordDet.Quantity;
                    _context.OrderDetails.Update(ordDet);
                    _context.SaveChanges();
                }

                // Find order total
                decimal currentTotal = ord.OrderTotal;
                // Calculate new total after coupon applied
                ord.AfterCouponOrderTotal = currentTotal;
                ord.Coupon = couponToApply;
                ViewBag.Message1 = "Congrats, you got " + couponToApply.PercentageOff.ToString() + "% off your order total!";

            }
            else if (couponToApply.PercentageOff == 0.0m && couponToApply.ShippingWhen != 0.0m) // Is a free shipping coupon
            {
                if (ord.OrderSubtotal > couponToApply.ShippingWhen)
                {
                    ord.Shipping = 0.0m;
                    ord.Coupon = couponToApply;
                    ord.AfterCouponOrderTotal = ord.OrderTotal;
                    ViewBag.Message1 = "Congrats, you got free shipping on your order!";
                }
                else 
                {
                    ord.AfterCouponOrderTotal = ord.OrderTotal;
                    ViewBag.Message1 = "Sorry, the coupon you used requires a subtotal of $" + couponToApply.ShippingWhen.ToString();
                }
            }
            await _context.SaveChangesAsync();

            return View("OrderConfirmed", ord);
        }

        // Function to finalize order and update database
        public async Task<IActionResult> FinalOrder(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Order order = await _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.OrderID == id);

            // Update properties to finalize order process
            List<OrderDetail> ods = order.OrderDetails; //list of order details

            Book orderedBook;

            string emailString = "";

            foreach (OrderDetail orddet in ods)
            {
                orderedBook = orddet.Book;

                List<Book> boughtbooks = new List<Book>();

                List<Order> CompletedOrders = _context.Orders.Where(c => c.IsPending == true).ToList(); //list of all completed orders

                orddet.Book.Copies = orddet.Book.Copies - orddet.Quantity;
                emailString = emailString + orddet.Book.Title + " ";

                foreach (Order completedOrd in CompletedOrders)
                {
                    List<OrderDetail> OrderDetailsCompleted = completedOrd.OrderDetails;
                    foreach (OrderDetail orddetCompleted in OrderDetailsCompleted)
                    {
                        Book bookInQuestion = orddetCompleted.Book;

                        if (bookInQuestion.BookID == orderedBook.BookID)
                        {
                            boughtbooks.Add(bookInQuestion); //if a book in the completed orders is the same book as the ordered book then we add it to the list
                            //orderedBook.Copies = orderedBook.Copies - orddetCompleted.Quantity;
                        }
                    }

                }




                int numBoughtBooks = boughtbooks.Count();

                if (orderedBook.AveragePrice == 0)
                {
                    orderedBook.AveragePrice = orderedBook.Price;
                }
                else
                {
                    orderedBook.AveragePrice = ((orderedBook.AveragePrice * numBoughtBooks) + orderedBook.Price) / (numBoughtBooks + 1);
                }
                //if (orderedBook.AverageCost == 0)
                //{
                //    orderedBook.AverageCost = orderedBook.Cost;
                //}
                //else
                //{
                //    orderedBook.AverageCost = ((orderedBook.AverageCost * numBoughtBooks) + orderedBook.Cost) / (numBoughtBooks + 1);
                //}

                //TO DO: copies not calculating correctly!! 
                orderedBook.AverageProfitMargin = orderedBook.Price - orderedBook.AverageCost;
                //orderedBook.Copies = orderedBook.Copies-1m;

                _context.Books.Update(orderedBook);
                await _context.SaveChangesAsync();



            }
            AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);

            order.AppUser = user;
            order.OrderDate = DateTime.Today;
            //order.CreditCardUsed = cardUsed;
            order.IsPending = true;


            emailString = emailString + "Total: " + order.AfterCouponOrderTotal.ToString();

            if (ModelState.IsValid)
            {
                _context.Orders.Update(order);
                await _context.SaveChangesAsync();
                string emailBody = "Thank you for your order with Bevo's Books! Your Order: " + emailString;
                string emailSubject = "Your Order with Bevo's Books";
                EmailMessaging.SendEmail(user.Email, emailSubject, emailBody);
                List<Book> recommendations = BookRecommender(order);
                return View("FinalOrderPlace", recommendations);
            }



            return View("Index");


        }





        /*CreditCard cardUsed = _context.CreditCards.Find(SelectedCreditCard);


        //update db
        var order1 = _context.Orders.Where(c => c.AppUser.UserName == User.Identity.Name && c.IsPending == false).ToList();;
        Order order = order1[0];


        //create a list of order details from the order


        List<OrderDetail> ods = order.OrderDetails; //list of order details

        Book orderedBook;

        foreach (OrderDetail orddet in ods)
        {
            orderedBook = orddet.Book;

            List<Book> boughtbooks = new List<Book>();

            List<Order> CompletedOrders = _context.Orders.Where(c => c.IsPending == true).ToList(); //list of all completed orders

            foreach (Order completedOrd in CompletedOrders)
            {
                List<OrderDetail> OrderDetailsCompleted = completedOrd.OrderDetails;
                foreach (OrderDetail orddetCompleted in OrderDetailsCompleted)
                {
                    Book bookInQuestion = orddetCompleted.Book;

                    if (bookInQuestion.BookID == orderedBook.BookID)
                    {
                        boughtbooks.Add(bookInQuestion); //if a book in the completed orders is the same book as the ordered book then we add it to the list
                    }
                }

            }


            int numBoughtBooks = boughtbooks.Count();

            if (orderedBook.AveragePrice == 0)
            {
                orderedBook.AveragePrice = orderedBook.Price;
            }
            else
            {
                orderedBook.AveragePrice = ((orderedBook.AveragePrice * numBoughtBooks) + orderedBook.Price) / (numBoughtBooks + 1);
            }

            _context.Books.Update(orderedBook);
            await _context.SaveChangesAsync();


        }

        order.AppUser = user;
        order.OrderDate = DateTime.Today;
        order.CreditCardUsed = cardUsed;
        order.IsPending = true;




        if (ModelState.IsValid)
        {
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
            return RedirectToAction("OrderConfirmed", "CheckOuts", order.OrderID);
        }



        return View("Index");

    }*/


        public void CalculateShipping(int? id)
        {
            Order ord = _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefault(r => r.OrderID == id);

            decimal numberOfOrders = ord.OrderDetails.Count;

            decimal totalQuantity = 0;

            if (numberOfOrders > 0)
            {
                foreach (OrderDetail od in ord.OrderDetails)
                {
                    totalQuantity = od.Quantity + totalQuantity;
                }
            }

            decimal quantityWoFirst = totalQuantity - 1;

            decimal ShippingPrice = 3.5m + (1.50m * quantityWoFirst);

            ord.Shipping = ShippingPrice;
        }



        public List<Book> BookRecommender(Order order)
        {
            try
            {
                // Access the Order's OrderDetails and choose the first OrderDetail(Book)
                OrderDetail od = order.OrderDetails[0];

                // Access the Book of that Order Detail
                Book bk = od.Book;

                // Create initial list of books user has already ordered
                AppUser user = _context.Users.FirstOrDefault(u => u.UserName == User.Identity.Name);
                var orders = _context.Orders.Where(o => o.AppUser == user && o.IsPending == true).Include(o => o.OrderDetails).ThenInclude(o => o.Book).ThenInclude(o => o.Genre).ToList();
                List<OrderDetail> pastOds = new List<OrderDetail>();
                foreach (Order ord in orders)
                {
                    foreach (OrderDetail ordDet in ord.OrderDetails)
                    {
                        pastOds.Add(ordDet);
                    }
                }
                List<Book> pastBooksOld = new List<Book>();

                foreach (OrderDetail ordDet in pastOds)
                {
                    pastBooksOld.Add(ordDet.Book);
                }
                List<Book> pastBooks = new List<Book>();
                foreach (Book book in _context.Books.Include(b => b.Genre))
                {
                    if (book.IsDicontinued == true)
                    {
                        continue;
                    }
                    if (!pastBooksOld.Contains(book))
                    {
                        pastBooks.Add(book);
                    }
                }
                // Initialize list of books recommend
                // Should only recommend THREE books
                List<Book> bookRecs = new List<Book>();

                // Query to test whether author of the book has another book of same genre as book from order
                var booksAG = pastBooks.Where(b => b.BookID != bk.BookID && b.Author == bk.Author && b.Genre == bk.Genre).ToList();
                int reviewCheck = 0;
                if (booksAG.Count() != 0)
                {
                    foreach (Book bookAG in booksAG)
                    {
                        if (bookAG.Reviews.Count() == 0)
                        {
                            reviewCheck++;
                        }
                    }
                    // If no reviews for the books, then add first book by same author and in same genre
                    if (reviewCheck == booksAG.Count())
                    {
                        bookRecs.Add(booksAG[0]);
                    }
                    else
                    {
                        // Add highest rated book by same author and in same genre
                        Book highestRated = new Book();
                        highestRated.RatingAverage = 0.0m;
                        foreach (Book book in booksAG)
                        {
                            if (book.RatingAverage > highestRated.RatingAverage)
                            {
                                highestRated = book;
                            }
                        }
                        bookRecs.Add(highestRated);
                    }
                }

                // Check if there was another book with same author and genre and was added to bookRecs in previous code block,
                if (bookRecs.Any())// bookRecs has 1 book and needs 2 more
                {
                    // List of books not ordered by current customer and same genre as book from cart
                    var booksGenre = pastBooks.Where(b => b.Genre == bk.Genre && b != bookRecs[0]).ToList();

                    // If there are no other books in the same genre
                    if (booksGenre.Count() == 0) // **maybe need .count==0, debug here**
                    {
                        // Recommend two highest rated books overall that customer has not ordered yet
                        Book highest = new Book(); Book highest2 = new Book();
                        highest.RatingAverage = 0.0m; highest2.RatingAverage = 0.0m;
                        foreach (Book book in pastBooks)
                        {
                            if (book.RatingAverage > highest.RatingAverage)
                            {
                                highest2 = highest; highest = book;
                            }
                        }
                        bookRecs.Add(highest); bookRecs.Add(highest2);
                    }
                    // Handle case where there is only one other book in same genre
                    else if (booksGenre.Count() == 1)
                    {
                        // Add the one book in same genre
                        bookRecs.Add(booksGenre[0]);
                        // Recommend the highest rated book overall that customer has not ordered yet to fill last book
                        Book highest = new Book();
                        highest.RatingAverage = 0.0m;
                        foreach (Book book in pastBooks)
                        {
                            if (book.RatingAverage > highest.RatingAverage)
                            {
                                highest = book;
                            }
                        }
                        bookRecs.Add(highest);
                    }
                    // Case where there is more than one book in same genre
                    else
                    {
                        // Find books in same genre that have rating above 4.0 and have been reviewed
                        var more = booksGenre.Where(b => b.Reviews.Count() != 0 & b.RatingAverage >= 4.0m).ToList();

                        // If there are books in same genre rated above 4.0
                        if (more.Count() != 0)
                        {
                            // Sort these books by rating in descending order
                            var booksSortRating = more.OrderByDescending(x => x.RatingAverage).ToList();

                            if (booksSortRating.Count() == 1) // Only one book with same genre and rated above 4.0
                            {
                                bookRecs.Add(booksSortRating[0]); // Add this book
                            }
                            else // More than one book with same genre and rated above 4.0
                            {
                                // Need to recommend two books to fill in remaining spots
                                Book addThis1 = booksSortRating[0]; // May have to cast to Book
                                bookRecs.Add(booksSortRating[0]);
                                Book addThis2 = booksSortRating.FirstOrDefault(x => x.Author != addThis1.Author);
                                // If there is another book in same genre with different author then add it
                                // If there is not, then spot will be filled in next code block
                                if (addThis2 != null)
                                {
                                    bookRecs.Add(addThis2);
                                }
                            }

                        }
                        // Check if bookRecs list if full to fill in remaining spots 
                        if (bookRecs.Count() < 3)
                        {
                            // First fill in remaining spots with books of same genre with rating lower than 4.0
                            var lastMore = booksGenre.Where(x => x.RatingAverage < 4.0m && x.Reviews.Count > 0).ToList();
                            if (lastMore.Count() != 0)
                            {
                                int i = 0;
                                while (i <= lastMore.Count() - 1 && bookRecs.Count() < 3)
                                {
                                    bookRecs.Add(lastMore[i]); // May have to cast
                                    i++;
                                }
                            }
                            // Fill in leftover spots with books in same genre that have no rating
                            if (bookRecs.Count() < 3)
                            {
                                var lastMore2 = booksGenre.Where(x => x.Reviews.Count() == 0).ToList();
                                if (lastMore2.Count() != 0)
                                {
                                    lastMore2 = lastMore2.ToList();
                                    int i = 0;
                                    while (i <= lastMore2.Count() - 1 && bookRecs.Count() < 3)
                                    {
                                        bookRecs.Add(lastMore2[i]); // may have to cast
                                        i++;
                                    }
                                }
                            }
                            // Lastly, any spots left will be filled with highest rated books overall
                            if (bookRecs.Count() < 3)
                            {
                                var highBooks = pastBooks;
                                if (highBooks != null)
                                {
                                    highBooks = highBooks.OrderByDescending(b => b.RatingAverage).ToList();
                                    int i = 0;
                                    while (i <= highBooks.Count() - 1 && bookRecs.Count() < 3)
                                    {
                                        if (!bookRecs.Contains((Book)highBooks[i]))
                                        {
                                            bookRecs.Add((Book)highBooks[i]);
                                        }
                                    }
                                }
                            }

                        }

                    }
                }
                // There was not another book with same author and genre
                else // bookRecs has 0 books and needs 3 more
                {
                    // List of books not ordered by current customer and same genre as book from cart
                    var booksGenre = pastBooks.Where(b => b.Genre.GenreID == bk.Genre.GenreID && b.BookID != bk.BookID).ToList();

                    // If there are no other books in the same genre
                    if (booksGenre.Count() == 0) // **maybe need .count==0, debug here**
                    {
                        // Recommend three highest rated books overall that customer has not ordered yet
                        Book highest = new Book(); Book highest2 = new Book(); Book highest3 = new Book();
                        highest.RatingAverage = 0.0m; highest2.RatingAverage = 0.0m; highest3.RatingAverage = 0.0m;
                        foreach (Book book in pastBooks)
                        {
                            if (book.RatingAverage > highest.RatingAverage)
                            {
                                highest3 = highest2; highest2 = highest; highest = book;
                            }
                        }
                        bookRecs.Add(highest);
                        // Make sure the other two books were updated in loop
                        if (highest2.Title != null)
                        {
                            bookRecs.Add(highest2);
                        }
                        if (highest3.Title != null)
                        {
                            bookRecs.Add(highest3);
                        }
                    }
                    // Handle case where there is only one other book in same genre
                    else if (booksGenre.Count() == 1)
                    {
                        // Add the one book in same genre
                        bookRecs.Add(booksGenre[0]);
                        // Recommend the highest rated book overall that customer has not ordered yet to fill last book
                        Book highest = new Book();
                        highest.RatingAverage = 0.0m;
                        foreach (Book book in pastBooks)
                        {
                            if (book.RatingAverage > highest.RatingAverage)
                            {
                                highest = book;
                            }
                        }
                        bookRecs.Add(highest);
                    }
                    // Case where there is more than one book in same genre
                    else
                    {
                        // Find books in same genre that have rating above 4.0 and have been reviewed
                        var more = booksGenre.Where(b => b.Reviews.Count() != 0 & b.RatingAverage >= 4.0m).ToList();

                        // If there are books in same genre rated above 4.0
                        if (more.Count() != 0)
                        {
                            // Sort these books by rating in descending order
                            var booksSortRating = more.OrderByDescending(x => x.RatingAverage).ToList();

                            if (booksSortRating.Count() == 1) // Only one book with same genre and rated above 4.0
                            {
                                bookRecs.Add(booksSortRating[0]); // Add this book
                            }
                            else // More than one book with same genre and rated above 4.0
                            {
                                // Need to recommend three books to fill in remaining spots
                                Book addThis1 = booksSortRating[0]; // May have to cast to Book
                                bookRecs.Add(booksSortRating[0]);
                                Book addThis2 = booksSortRating.FirstOrDefault(x => x.Author != addThis1.Author);
                                // If there is another book in same genre with different author then add it
                                // If there is not, then spot will be filled in next code block
                                if (addThis2 != null)
                                {
                                    bookRecs.Add(addThis2);
                                }
                                Book addThis3 = booksSortRating.FirstOrDefault(x => x.Author != addThis1.Author && x.Author != addThis2.Author);
                                // If there is another book in same genre with different author then add it
                                // If there is not, then spot will be filled in next code block
                                if (addThis3 != null)
                                {
                                    bookRecs.Add(addThis3);
                                }
                            }

                        }
                        // Check if bookRecs list if full to fill in remaining spots 
                        if (bookRecs.Count() < 3)
                        {
                            // First fill in remaining spots with books of same genre with rating lower than 4.0
                            var lastMore = booksGenre.Where(x => x.RatingAverage < 4.0m && x.Reviews.Count > 0).ToList();
                            if (lastMore.Count() != 0)
                            {
                                //lastMore = lastMore.ToList();
                                int i = 0;
                                while (i <= lastMore.Count() - 1 && bookRecs.Count() < 3)
                                {
                                    bookRecs.Add(lastMore[i]); // may have to cast
                                    i++;
                                }
                            }
                            // Fill in leftover spots with books in same genre that have no rating
                            if (bookRecs.Count() < 3)
                            {
                                var lastMore2 = booksGenre.Where(x => x.Reviews.Count() == 0).ToList();
                                if (lastMore2.Count() != 0)
                                {
                                    lastMore2 = lastMore2.ToList();
                                    int i = 0;
                                    while (i <= lastMore2.Count() - 1 && bookRecs.Count() < 3)
                                    {
                                        bookRecs.Add(lastMore2[i]); // may have to cast
                                        i++;
                                    }
                                }
                            }
                            // Lastly, any spots left will be filled with highest rated books overall
                            if (bookRecs.Count() < 3)
                            {
                                var highBooks = pastBooks;
                                if (highBooks != null)
                                {
                                    highBooks = highBooks.OrderByDescending(b => b.RatingAverage).ToList();
                                    int i = 0;
                                    while (i <= highBooks.Count() - 1 && bookRecs.Count() < 3)
                                    {
                                        if (!bookRecs.Contains((Book)highBooks[i]))
                                        {
                                            bookRecs.Add((Book)highBooks[i]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return bookRecs;
            }

            catch
            {
                List<Book> errorBooks = new List<Book>();
                return errorBooks;
            }
        }

        //GET function once the order is confirmed
        public async Task<IActionResult> OrderConfirmed(int? id)
        {

            if (id == null)
            {
                return NotFound();
            }

            // Find current cart
            Order order = await _context.Orders.Include(r => r.OrderDetails).ThenInclude(r => r.Book).FirstOrDefaultAsync(m => m.OrderID == id);

            if (order == null)
            {
                return NotFound();
            }

            // Create Lists to store book titles for viewbag messages
            List<String> BooksOutOfStock = new List<String>(); List<String> BooksDiscont = new List<String>();

            // Get the current cart's orderdetails
            var cartDetails = order.OrderDetails.ToList();

            // Loop through the order details in the cart and check if book price has changed, book is out of stock
            // and if book has been discontinued
            foreach (OrderDetail od in cartDetails)
            {
                // find the given orderdetail's book
                int bkId = od.Book.BookID;
                Book book = _context.Books.FirstOrDefault(b => b.BookID == bkId);

                // 1. Check if the book has been discontinued
                if (book == null)
                {
                    BooksDiscont.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 2. Check if book has gone out of stock
                else if (book.Copies <= 0) // Change to IsInStock after checkout is finished
                {
                    BooksOutOfStock.Add(book.Title);
                    _context.OrderDetails.Remove(od);
                    _context.SaveChanges();
                }

                // 3. Check if book's price has changed
                else if (book.Price != od.PricePaid)
                {
                    od.PricePaid = book.Price;
                    _context.OrderDetails.Update(od);
                    _context.SaveChanges();
                }
            }
            // Strings to become ViewBag messages
            String Message1 = "";
            String Message2 = "";

            // If a book in the cart has gone out of stock
            if (BooksOutOfStock.Any())
            {
                if (BooksOutOfStock.Count() > 1) // Multiple books went out of stock
                {
                    for (int x = 0; x < BooksOutOfStock.Count(); x++)
                    {
                        if (x == BooksOutOfStock.Count() - 1)
                        {
                            Message1 = Message1 + BooksOutOfStock[x]; // If last book in list don't add comma
                        }
                        else
                        {
                            Message1 = Message1 + BooksOutOfStock[x] + ", ";// Not last book in list so add comma
                        }
                    }
                    Message1 = Message1 + " are no longer in stock and were removed from your cart";
                }
                else // Only one book went out of stock
                {
                    Message1 = BooksOutOfStock[0] + " is no longer in stock and was removed from your cart";
                }
            }

            // If a book in the cart has been discontinued
            if (BooksDiscont.Count() > 0)
            {
                if (BooksDiscont.Count() > 1) // Multiple books were discontinued
                {
                    for (int x = 0; x < BooksDiscont.Count(); x++)
                    {
                        if (x == BooksDiscont.Count() - 1)
                        {
                            Message2 = Message2 + BooksDiscont[x];
                        }
                        else
                        {
                            Message2 = Message2 + BooksDiscont[x] + ", ";
                        }
                    }
                    Message2 = Message2 + " are no longer being sold and were removed from your cart";
                }
                else // Only one book was discontinued
                {
                    Message1 = BooksOutOfStock[0] + " is no longer being sold and was removed from your cart";
                }
            }

            CalculateShipping(order.OrderID);

            ViewBag.Message1 = Message1;
            ViewBag.Message2 = Message2;


            return View("OrderConfirmed");
        }
    }

}
