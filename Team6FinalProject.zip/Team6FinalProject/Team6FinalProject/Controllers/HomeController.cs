﻿
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Team6FinalProject.Controllers

{

    public enum SortOptions {AuthorDesc, AuthorAsc, TitleDesc, TitleAsc, MostPop, Newest, Oldest, HighRate}
    public enum FilterOptions {InStock, AllBooks}


    public class HomeController : Controller
    {
        private AppDbContext _db;

        public HomeController(AppDbContext context)
        {
            _db = context;
        }


        public ActionResult ActualHome()
        {
            List<Coupon> coupons = _db.Coupons.Where(c => c.IsDisabled == false).ToList();

            return View("ActualHome", coupons);
        }
        // GET
        
        public ActionResult Index()
        {
            _db.Books.Include(r => r.Genre).ToList();
            List<Book> SelectedBooks = new List<Book>();

            var query = from r in _db.Books
                        select r;
            SelectedBooks = query.Include(r => r.Genre).ToList();
            ViewBag.SelectedBooks = SelectedBooks.Count();
            ViewBag.TotalBooks = _db.Books.Count();
            ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " out of " + ViewBag.TotalBooks + " Books";
            return View("Index", SelectedBooks);

        }

        public ActionResult DetailedSearch()

        {
            ViewBag.AllGenres = GetAllGenres();
            return View();

        }


        public IActionResult Details(int? id)
        {
            if (id == null) //Book id not specified
            {
                return View("Error", new String[] { "Book ID not specified - which book do you want to view?" });
            }


            //how to limit which reviews are shown 
            Book repo = _db.Books.Include(r => r.Genre).Include(r => r.Reviews).FirstOrDefault(r => r.BookID == id);

            if (repo == null) //Book does not exist in database
            {
                return View("Error", new String[] { "Book not found in database" });
            }

            //if code gets this far, all is well
            string error = (string)TempData["error"];
            ViewBag.Message = error;
            return View(repo);

        }

        //GET
        public IActionResult DisplaySearchResults(String SearchBookTitle, String SearchBookAuthor, String SearchBookNumber, 
                                                  int SelectedGenre, SortOptions SelectedSort, FilterOptions SelectedFilter)
        {
            var query = from r in _db.Books.Include(o => o.OrderDetails) select r;

     
            //SearchBookTitle 
            if (SearchBookTitle == null || SearchBookTitle == "")
            {

            }
            else
            {
                query = query.Where(r => r.Title.Contains(SearchBookTitle));
            }

            //BookAuthor

            if (SearchBookAuthor == null || SearchBookAuthor == "")
            {

            }
            else
            {
                query = query.Where(r => r.Author.Contains(SearchBookAuthor));
            }

            //BookNumber

            if (SearchBookNumber != null && SearchBookNumber != "")
            {


                Int32 intBookNum;

                try
                {
                    intBookNum = Convert.ToInt32(SearchBookNumber);

                }

                catch
                {
                    ViewBag.Message = "You must enter a number to use search on BookNumber";
                    ViewBag.AllGenres = GetAllGenres();
                    return View("DetailedSearch");
                }
                if (intBookNum <= 780991)
                {
                    ViewBag.Message = "Please enter a unique number that is greater or equal to 780991";
                    ViewBag.AllGenres = GetAllGenres();
                    return View("DetailedSearch");
                }
                else
                {
                    query = query.Where(r => r.BookNumber == intBookNum);
                }

            }


            //Book Genre 
            if (SelectedGenre == 0)
            {

            }
            else
            {
                Genre GenreToDisplay = _db.Genres.Find(SelectedGenre);
                query = query.Where(r => r.Genre.GenreID == SelectedGenre);
            }

            //Sort
            if (SelectedSort == SortOptions.TitleDesc)
            {query = query.OrderByDescending(r => r.Title);}

            if (SelectedSort == SortOptions.TitleAsc)
            {query = query.OrderBy(r => r.Title);}

            if (SelectedSort == SortOptions.AuthorDesc)
            {query = query.OrderByDescending(r => r.Author);}

            if (SelectedSort == SortOptions.AuthorAsc)
            {query = query.OrderBy(r => r.Author);}

            if (SelectedSort == SortOptions.Newest)
            { query = query.OrderByDescending(r => r.PublicationDate); }

            if (SelectedSort == SortOptions.Oldest)
            { query = query.OrderBy(r => r.PublicationDate); }

            if (SelectedSort == SortOptions.HighRate)
            { query = query.OrderByDescending(r => r.RatingAverage); }

            if (SelectedSort == SortOptions.MostPop) //CHECK!! after we have orders in
            { query = query.OrderByDescending(r => r.OrderDetails.Sum(o => o.Quantity)); }


            //Filter 
            if (SelectedFilter == FilterOptions.InStock)
            { query = query.Where(r => r.IsInStock == true); }


            List<Book> SelectedBooks = new List<Book> ();
            SelectedBooks = query.Include(r => r.Genre).ToList();
            ViewBag.TotalBooks = _db.Books.Count();
            ViewBag.SelectedBooks = SelectedBooks.Count();
            ViewBag.Message = "Showing " + ViewBag.SelectedBooks + " out of " + ViewBag.TotalBooks + " Books";
            return View("Index", SelectedBooks);


            }

       /*
        public IActionResult Details(int? id)
        {
            if (id == null) //Repo id not specified
            {
                return View("Error", new String[] { "Book ID not specified - which repo do you want to view?" });
            }

            Book book = _db.Books.Include(r => r.Language).FirstOrDefault(r => r.BookID == id);

            if (repo == null) //Repo does not exist in database
            {
                return View("Error", new String[] { "Repository not found in database" });
            }

    */ 

            public SelectList GetAllGenres()
            {
                List<Genre> Genres = _db.Genres.ToList();
                Genre SelectNone = new Genre() { GenreID = 0, GenreName = "All Genres" };
                Genres.Add(SelectNone);

                SelectList AllGenres = new SelectList(Genres.OrderBy(g => g.GenreID), "GenreID", "GenreName");

                return AllGenres;
            }


            //public SelectList GetAllSorts()
            //{

            //List<string> Sorts = new List<string>();
            //Sorts.Add("Author Ascending");
            //Sorts.Add("Author Descending");
            //Sorts.Add("Title Ascending");
            //Sorts.Add("Title Descending");
            //Sorts.Add("Most Popular");
            //Sorts.Add("Newest First");
            //Sorts.Add("Oldest First");
            //Sorts.Add("Highest Rated");

            //SelectList AllSorts = new SelectList(Sorts);

            //return AllSorts;

            //}



    }
    }

