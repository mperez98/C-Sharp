﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Team6FinalProject.DAL;

namespace Team6FinalProject.Utilites
{
    public class GenerateBookNumber
    {


            public static Int32 GetNextBookNumber(AppDbContext db)
            {


                Int32 intMaxBookNumber; //the current maximum course number
                Int32 intNextBookNumber; //the course number for the next class

                if (db.Books.Count() == 0) //there are no courses in the database yet
                {
                    intMaxBookNumber = 789300; //Order Number start at 10001
                }
                else
                {
                    intMaxBookNumber = db.Books.Max(c => c.BookNumber); //this is the highest number in the database right now
                }

                //add one to the current max to find the next one
                intNextBookNumber = intMaxBookNumber + 1;

                //return the value
                return intNextBookNumber;
            }

        }
    }





