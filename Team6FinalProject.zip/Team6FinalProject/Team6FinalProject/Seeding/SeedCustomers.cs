﻿using Team6FinalProject.Models;
using Team6FinalProject.DAL;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Team6FinalProject.Seeding
{
    public static class SeedCustomers
    {
        public static void SeedAllCustomers(AppDbContext db)
        {
           

            Int32 intCustomersAdded = 0;
            String AppUserPhoneNumber = "Begin"; //helps to keep track of error on repos
            List<AppUser> AppUsers = new List<AppUser>();

            try
            {
                AppUser b1 = new AppUser();
               
                b1.Password = "bookworm";
                b1.LastName = "Baker";
                b1.FirstName = "Christopher";
                b1.MiddleInitial = "L.";
                b1.Birthday = "18225";
                b1.StreetAddress = "1898 Schurz Alley";
                b1.City = "Austin";
                b1.State = "TX";
                b1.ZipCode = "78705";
                b1.Email = "cbaker@example.com";
                b1.PhoneNumber = "5725458641";
                AppUsers.Add(b1);

                AppUser b2 = new AppUser();
                
                b2.Password = "potato";
                b2.LastName = "Banks";
                b2.FirstName = "Michelle";
                b2.MiddleInitial = "";
                b2.Birthday = "22977";
                b2.StreetAddress = "97 Elmside Pass";
                b2.City = "Austin";
                b2.State = "TX";
                b2.ZipCode = "78712";
                b2.Email = "banker@longhorn.net";
                b2.PhoneNumber = "9867048435";
                AppUsers.Add(b2);

                AppUser b3 = new AppUser();
               
                b3.Password = "painting";
                b3.LastName = "Broccolo";
                b3.FirstName = "Franco";
                b3.MiddleInitial = "V";
                b3.Birthday = "33888";
                b3.StreetAddress = "88 Crowley Circle";
                b3.City = "Austin";
                b3.State = "TX";
                b3.ZipCode = "78786";
               
                b3.Email = "franco@example.com";
                b3.PhoneNumber = "6836109514";
                AppUsers.Add(b3);

                AppUser b4 = new AppUser();
              
                b4.Password = "texas1";
                b4.LastName = "Chang";
                b4.FirstName = "Wendy";
                b4.MiddleInitial = "L";
                b4.Birthday = "35566";
                b4.StreetAddress = "56560 Sage Junction";
                b4.City = "Eagle Pass";
                b4.State = "TX";
                b4.ZipCode = "78852";
            
                b4.Email = "wchang@example.com";
                b4.PhoneNumber = "7070911071";
                AppUsers.Add(b4);

                AppUser b5 = new AppUser();
                
                b5.Password = "Anchorage";
                b5.LastName = "Chou";
                b5.FirstName = "Lim";
                b5.MiddleInitial = "";
                b5.Birthday = "25664";
                b5.StreetAddress = "60 Lunder Point";
                b5.City = "Austin";
                b5.State = "TX";
                b5.ZipCode = "78729";
              
                b5.Email = "limchou@gogle.com";
                b5.PhoneNumber = "1488907687";
                AppUsers.Add(b5);

                AppUser b6 = new AppUser();
              
                b6.Password = "aggies";
                b6.LastName = "Dixon";
                b6.FirstName = "Shan";
                b6.MiddleInitial = "D";
                b6.Birthday = "30693";
                b6.StreetAddress = "9448 Pleasure Avenue";
                b6.City = "Georgetown";
                b6.State = "TX";
                b6.ZipCode = "78628";
              
                b6.Email = "shdixon@aoll.com";
                b6.PhoneNumber = "6899701824";
                AppUsers.Add(b6);

                AppUser b7 = new AppUser();
              
                b7.Password = "hampton1";
                b7.LastName = "Evans";
                b7.FirstName = "Jim Bob";
                b7.MiddleInitial = "";
                b7.Birthday = "21802";
                b7.StreetAddress = "51 Emmet Parkway";
                b7.City = "Austin";
                b7.State = "TX";
                b7.ZipCode = "78705";
               
                b7.Email = "j.b.evans@aheca.org";
                b7.PhoneNumber = "9986825917";
                AppUsers.Add(b7);

                AppUser b8 = new AppUser();
              
                b8.Password = "longhorns";
                b8.LastName = "Feeley";
                b8.FirstName = "Lou Ann";
                b8.MiddleInitial = "K";
                b8.Birthday = "36903";
                b8.StreetAddress = "65 Darwin Crossing";
                b8.City = "Austin";
                b8.State = "TX";
                b8.ZipCode = "78704";
            
                b8.Email = "feeley@penguin.org";
                b8.PhoneNumber = "3464121966";
                AppUsers.Add(b8);

                AppUser b9 = new AppUser();
              
                b9.Password = "mustangs";
                b9.LastName = "Freeley";
                b9.FirstName = "Tesa";
                b9.MiddleInitial = "P";
                b9.Birthday = "33273";
                b9.StreetAddress = "7352 Loftsgordon Court";
                b9.City = "College Station";
                b9.State = "TX";
                b9.ZipCode = "77840";
              
                b9.Email = "tfreeley@minnetonka.ci.us";
                b9.PhoneNumber = "6581357270";
                AppUsers.Add(b9);

                AppUser b10 = new AppUser();
              
                b10.Password = "onetime";
                b10.LastName = "Garcia";
                b10.FirstName = "Margaret";
                b10.MiddleInitial = "L";
                b10.Birthday = "33513";
                b10.StreetAddress = "7 International Road";
                b10.City = "Austin";
                b10.State = "TX";
                b10.ZipCode = "78756";
             
                b10.Email = "mgarcia@gogle.com";
                b10.PhoneNumber = "3767347949";
                AppUsers.Add(b10);

                AppUser b11 = new AppUser();
              
                b11.Password = "pepperoni";
                b11.LastName = "Haley";
                b11.FirstName = "Charles";
                b11.MiddleInitial = "E";
                b11.Birthday = "27220";
                b11.StreetAddress = "8 Warrior Trail";
                b11.City = "Austin";
                b11.State = "TX";
                b11.ZipCode = "78746";
               
                b11.Email = "chaley@thug.com";
                b11.PhoneNumber = "2198604221";
                AppUsers.Add(b11);

                AppUser b12 = new AppUser();
               
                b12.Password = "raiders";
                b12.LastName = "Hampton";
                b12.FirstName = "Jeffrey";
                b12.MiddleInitial = "T.";
                b12.Birthday = "38056";
                b12.StreetAddress = "9107 Lighthouse Bay Road";
                b12.City = "Austin";
                b12.State = "TX";
                b12.ZipCode = "78756";
            
                b12.Email = "jeffh@sonic.com";
                b12.PhoneNumber = "1222185888";
                AppUsers.Add(b12);

                AppUser b13 = new AppUser();
                
                b13.Password = "jhearn22";
                b13.LastName = "Hearn";
                b13.FirstName = "John";
                b13.MiddleInitial = "B";
                b13.Birthday = "18480";
                b13.StreetAddress = "59784 Pierstorff Center";
                b13.City = "Liberty";
                b13.State = "TX";
                b13.ZipCode = "77575";
              
                b13.Email = "wjhearniii@umich.org";
                b13.PhoneNumber = "5123071976";
                AppUsers.Add(b13);

                AppUser b14 = new AppUser();
                
                b14.Password = "hickhickup";
                b14.LastName = "Hicks";
                b14.FirstName = "Anthony";
                b14.MiddleInitial = "J";
                b14.Birthday = "38329";
                b14.StreetAddress = "932 Monica Way";
                b14.City = "San Antonio";
                b14.State = "TX";
                b14.ZipCode = "78203";
              
                b14.Email = "ahick@yaho.com";
                b14.PhoneNumber = "1211949601";
                AppUsers.Add(b14);

                AppUser b15 = new AppUser();
              
                b15.Password = "ingram2015";
                b15.LastName = "Ingram";
                b15.FirstName = "Brad";
                b15.MiddleInitial = "S.";
                b15.Birthday = "37139";
                b15.StreetAddress = "4 Lukken Court";
                b15.City = "New Braunfels";
                b15.State = "TX";
                b15.ZipCode = "78132";
                
                b15.Email = "ingram@jack.com";
                b15.PhoneNumber = "1372121569";
                AppUsers.Add(b15);

                AppUser b16 = new AppUser();
               
                b16.Password = "toddy25";
                b16.LastName = "Jacobs";
                b16.FirstName = "Todd";
                b16.MiddleInitial = "L.";
                b16.Birthday = "36180";
                b16.StreetAddress = "7 Susan Junction";
                b16.City = "New York";
                b16.State = "NY";
                b16.ZipCode = "10101";
              
                b16.Email = "toddj@yourmom.com";
                b16.PhoneNumber = "8543163836";
                AppUsers.Add(b16);

                AppUser b17 = new AppUser();
              
                b17.Password = "something";
                b17.LastName = "Lawrence";
                b17.FirstName = "Victoria";
                b17.MiddleInitial = "M.";
                b17.Birthday = "36630";
                b17.StreetAddress = "669 Oak Junction";
                b17.City = "Lockhart";
                b17.State = "TX";
                b17.ZipCode = "78644";
             
                b17.Email = "thequeen@aska.net";
                b17.PhoneNumber = "3214163359";
                AppUsers.Add(b17);

                AppUser b18 = new AppUser();
                
                b18.Password = "Password1";
                b18.LastName = "Lineback";
                b18.FirstName = "Erik";
                b18.MiddleInitial = "W";
                b18.Birthday = "37957";
                b18.StreetAddress = "099 Luster Point";
                b18.City = "Kingwood";
                b18.State = "TX";
                b18.ZipCode = "77325";
              
                b18.Email = "linebacker@gogle.com";
                b18.PhoneNumber = "2505265350";
                AppUsers.Add(b18);

                AppUser b19 = new AppUser();
                
                b19.Password = "aclfest2017";
                b19.LastName = "Lowe";
                b19.FirstName = "Ernest";
                b19.MiddleInitial = "S";
                b19.Birthday = "28466";
                b19.StreetAddress = "35473 Hansons Hill";
                b19.City = "Beverly Hills";
                b19.State = "CA";
                b19.ZipCode = "90210";
              
                b19.Email = "elowe@netscare.net";
                b19.PhoneNumber = "4070619503";
                AppUsers.Add(b19);

                AppUser b20 = new AppUser();
              
                b20.Password = "nothinggood";
                b20.LastName = "Luce";
                b20.FirstName = "Chuck";
                b20.MiddleInitial = "B";
                b20.Birthday = "17973";
                b20.StreetAddress = "4 Emmet Junction";
                b20.City = "Navasota";
                b20.State = "TX";
                b20.ZipCode = "77868";
              
                b20.Email = "cluce@gogle.com";
                b20.PhoneNumber = "7358436110";
                AppUsers.Add(b20);

                AppUser b21 = new AppUser();
             
                b21.Password = "whatever";
                b21.LastName = "MacLeod";
                b21.FirstName = "Jennifer";
                b21.MiddleInitial = "D.";
                b21.Birthday = "17219";
                b21.StreetAddress = "3 Orin Road";
                b21.City = "Austin";
                b21.State = "TX";
                b21.ZipCode = "78712";
               
                b21.Email = "mackcloud@george.com";
                b21.PhoneNumber = "7240178229";
                AppUsers.Add(b21);

                AppUser b22 = new AppUser();
                
                b22.Password = "snowsnow";
                b22.LastName = "Markham";
                b22.FirstName = "Elizabeth";
                b22.MiddleInitial = "P.";
                b22.Birthday = "26378";
                b22.StreetAddress = "8171 Commercial Crossing";
                b22.City = "Austin";
                b22.State = "TX";
                b22.ZipCode = "78712";
               
                b22.Email = "cmartin@beets.com";
                b22.PhoneNumber = "2495200223";
                AppUsers.Add(b22);

                AppUser b23 = new AppUser();
                
                b23.Password = "whocares";
                b23.LastName = "Martin";
                b23.FirstName = "Clarence";
                b23.MiddleInitial = "A";
                b23.Birthday = "33804";
                b23.StreetAddress = "96 Anthes Place";
                b23.City = "Schenectady";
                b23.State = "NY";
                b23.ZipCode = "12345";
          
                b23.Email = "clarence@yoho.com";
                b23.PhoneNumber = "4086179161";
                AppUsers.Add(b23);

                AppUser b24 = new AppUser();
                
                b24.Password = "xcellent";
                b24.LastName = "Martinez";
                b24.FirstName = "Gregory";
                b24.MiddleInitial = "R.";
                b24.Birthday = "17315";
                b24.StreetAddress = "10 Northridge Plaza";
                b24.City = "Austin";
                b24.State = "TX";
                b24.ZipCode = "78717";
            
                b24.Email = "gregmartinez@drdre.com";
                b24.PhoneNumber = "9371927523";
                AppUsers.Add(b24);

                AppUser b25 = new AppUser();
               
                b25.Password = "mydogspot";
                b25.LastName = "Miller";
                b25.FirstName = "Charles";
                b25.MiddleInitial = "R.";
                b25.Birthday = "33161";
                b25.StreetAddress = "87683 Schmedeman Circle";
                b25.City = "Austin";
                b25.State = "TX";
                b25.ZipCode = "78727";
              
                b25.Email = "cmiller@bob.com";
                b25.PhoneNumber = "5954063857";
                AppUsers.Add(b25);

                AppUser b26 = new AppUser();
               
                b26.Password = "spotmydog";
                b26.LastName = "Nelson";
                b26.FirstName = "Kelly";
                b26.MiddleInitial = "T";
                b26.Birthday = "26127";
                b26.StreetAddress = "3244 Ludington Court";
                b26.City = "Beaumont";
                b26.State = "TX";
                b26.ZipCode = "77720";
             
                b26.Email = "knelson@aoll.com";
                b26.PhoneNumber = "8929209512";
                AppUsers.Add(b26);

                AppUser b27 = new AppUser();
              
                b27.Password = "joejoejoe";
                b27.LastName = "Nguyen";
                b27.FirstName = "Joe";
                b27.MiddleInitial = "C";
                b27.Birthday = "30758";
                b27.StreetAddress = "4780 Talisman Court";
                b27.City = "San Marcos";
                b27.State = "TX";
                b27.ZipCode = "78667";
               
                b27.Email = "joewin@xfactor.com";
                b27.PhoneNumber = "9226301774";
                AppUsers.Add(b27);

                AppUser b28 = new AppUser();
              
                b28.Password = "billyboy";
                b28.LastName = "O'Reilly";
                b28.FirstName = "Bill";
                b28.MiddleInitial = "T";
                b28.Birthday = "21739";
                b28.StreetAddress = "4154 Delladonna Plaza";
                b28.City = "Bergheim";
                b28.State = "TX";
                b28.ZipCode = "78004";
           
                b28.Email = "orielly@foxnews.cnn";
                b28.PhoneNumber = "2537646912";
                AppUsers.Add(b28);

                AppUser b29 = new AppUser();
              
                b29.Password = "radgirl";
                b29.LastName = "Radkovich";
                b29.FirstName = "Anka";
                b29.MiddleInitial = "L";
                b29.Birthday = "24246";
                b29.StreetAddress = "72361 Bayside Drive";
                b29.City = "Austin";
                b29.State = "TX";
                b29.ZipCode = "78789";
             
                b29.Email = "ankaisrad@gogle.com";
                b29.PhoneNumber = "2182889379";
                AppUsers.Add(b29);

                AppUser b30 = new AppUser();
               
                b30.Password = "meganr34";
                b30.LastName = "Rhodes";
                b30.FirstName = "Megan";
                b30.MiddleInitial = "C.";
                b30.Birthday = "23813";
                b30.StreetAddress = "76875 Hoffman Point";
                b30.City = "Orlando";
                b30.State = "FL";
                b30.ZipCode = "32830";
              
                b30.Email = "megrhodes@freserve.co.uk";
                b30.PhoneNumber = "9532396075";
                AppUsers.Add(b30);

                AppUser b31 = new AppUser();
                
                b31.Password = "ricearoni";
                b31.LastName = "Rice";
                b31.FirstName = "Eryn";
                b31.MiddleInitial = "M.";
                b31.Birthday = "27512";
                b31.StreetAddress = "048 Elmside Park";
                b31.City = "South Padre Island";
                b31.State = "TX";
                b31.ZipCode = "78597";
               
                b31.Email = "erynrice@aoll.com";
                b31.PhoneNumber = "7303815953";
                AppUsers.Add(b31);

                AppUser b32 = new AppUser();
               
                b32.Password = "alaskaboy";
                b32.LastName = "Rodriguez";
                b32.FirstName = "Jorge";
                b32.MiddleInitial = "";
                b32.Birthday = "19701";
                b32.StreetAddress = "01 Browning Pass";
                b32.City = "Austin";
                b32.State = "TX";
                b32.ZipCode = "78744";
              
                b32.Email = "jorge@noclue.com";
                b32.PhoneNumber = "3677322422";
                AppUsers.Add(b32);

                AppUser b33 = new AppUser();
                
                b33.Password = "bunnyhop";
                b33.LastName = "Rogers";
                b33.FirstName = "Allen";
                b33.MiddleInitial = "B.";
                b33.Birthday = "26776";
                b33.StreetAddress = "844 Anderson Alley";
                b33.City = "Canyon Lake";
                b33.State = "TX";
                b33.ZipCode = "78133";
               
                b33.Email = "mrrogers@lovelyday.com";
                b33.PhoneNumber = "3911705385";
                AppUsers.Add(b33);

                AppUser b34 = new AppUser();
             
                b34.Password = "dustydusty";
                b34.LastName = "Saint-Jean";
                b34.FirstName = "Olivier";
                b34.MiddleInitial = "M";
                b34.Birthday = "34749";
                b34.StreetAddress = "1891 Docker Point";
                b34.City = "Austin";
                b34.State = "TX";
                b34.ZipCode = "78779";
                
                b34.Email = "stjean@athome.com";
                b34.PhoneNumber = "7351610920";
                AppUsers.Add(b34);

                AppUser b35 = new AppUser();
          
                b35.Password = "jrod2017";
                b35.LastName = "Saunders";
                b35.FirstName = "Sarah";
                b35.MiddleInitial = "J.";
                b35.Birthday = "28540";
                b35.StreetAddress = "1469 Upham Road";
                b35.City = "Austin";
                b35.State = "TX";
                b35.ZipCode = "78720";
                
                b35.Email = "saunders@pen.com";
                b35.PhoneNumber = "5269661692";
                AppUsers.Add(b35);

                AppUser b36 = new AppUser();
              
                b36.Password = "martin1234";
                b36.LastName = "Sewell";
                b36.FirstName = "William";
                b36.MiddleInitial = "T.";
                b36.Birthday = "38344";
                b36.StreetAddress = "1672 Oak Valley Circle";
                b36.City = "Austin";
                b36.State = "TX";
                b36.ZipCode = "78705";
            
                b36.Email = "willsheff@email.com";
                b36.PhoneNumber = "1875727246";
                AppUsers.Add(b36);

                AppUser b37 = new AppUser();
           
                b37.Password = "penguin12";
                b37.LastName = "Sheffield";
                b37.FirstName = "Martin";
                b37.MiddleInitial = "J.";
                b37.Birthday = "22044";
                b37.StreetAddress = "816 Kennedy Place";
                b37.City = "Round Rock";
                b37.State = "TX";
                b37.ZipCode = "78680";
               
                b37.Email = "sheffiled@gogle.com";
                b37.PhoneNumber = "1394323615";
                AppUsers.Add(b37);

                AppUser b38 = new AppUser();
           
                b38.Password = "rogerthat";
                b38.LastName = "Smith";
                b38.FirstName = "John";
                b38.MiddleInitial = "A";
                b38.Birthday = "20265";
                b38.StreetAddress = "0745 Golf Road";
                b38.City = "Austin";
                b38.State = "TX";
                b38.ZipCode = "78760";
             
                b38.Email = "johnsmith187@aoll.com";
                b38.PhoneNumber = "6645937874";
                AppUsers.Add(b38);

                AppUser b39 = new AppUser();
                
                b39.Password = "smitty444";
                b39.LastName = "Stroud";
                b39.FirstName = "Dustin";
                b39.MiddleInitial = "P";
                b39.Birthday = "24679";
                b39.StreetAddress = "505 Dexter Plaza";
                b39.City = "Sweet Home";
                b39.State = "TX";
                b39.ZipCode = "77987";
               
                b39.Email = "dustroud@mail.com";
                b39.PhoneNumber = "6470254680";
                AppUsers.Add(b39);

                AppUser b40 = new AppUser();
                
                b40.Password = "stewball";
                b40.LastName = "Stuart";
                b40.FirstName = "Eric";
                b40.MiddleInitial = "D.";
                b40.Birthday = "17505";
                b40.StreetAddress = "585 Claremont Drive";
                b40.City = "Corpus Christi";
                b40.State = "TX";
                b40.ZipCode = "78412";
              
                b40.Email = "estuart@anchor.net";
                b40.PhoneNumber = "7701621022";
                AppUsers.Add(b40);

                AppUser b41 = new AppUser();
              
                b41.Password = "slowwind";
                b41.LastName = "Stump";
                b41.FirstName = "Peter";
                b41.MiddleInitial = "L";
                b41.Birthday = "27220";
                b41.StreetAddress = "89035 Welch Circle";
                b41.City = "Pflugerville";
                b41.State = "TX";
                b41.ZipCode = "78660";
            
                b41.Email = "peterstump@noclue.com";
                b41.PhoneNumber = "2181960061";
                AppUsers.Add(b41);

                AppUser b42 = new AppUser();
                
                b42.Password = "tanner5454";
                b42.LastName = "Tanner";
                b42.FirstName = "Jeremy";
                b42.MiddleInitial = "S.";
                b42.Birthday = "16082";
                b42.StreetAddress = "4 Stang Trail";
                b42.City = "Austin";
                b42.State = "TX";
                b42.ZipCode = "78702";
               
                b42.Email = "jtanner@mustang.net";
                b42.PhoneNumber = "9908469499";
                AppUsers.Add(b42);

                AppUser b43 = new AppUser();
                
                b43.Password = "allyrally";
                b43.LastName = "Taylor";
                b43.FirstName = "Allison";
                b43.MiddleInitial = "R.";
                b43.Birthday = "33191";
                b43.StreetAddress = "726 Twin Pines Avenue";
                b43.City = "Austin";
                b43.State = "TX";
                b43.ZipCode = "78713";
              
                b43.Email = "taylordjay@aoll.com";
                b43.PhoneNumber = "7011918647";
                AppUsers.Add(b43);

                AppUser b44 = new AppUser();
             
                b44.Password = "taylorbaylor";
                b44.LastName = "Taylor";
                b44.FirstName = "Rachel";
                b44.MiddleInitial = "K.";
                b44.Birthday = "27777";
                b44.StreetAddress = "06605 Sugar Drive";
                b44.City = "Austin";
                b44.State = "TX";
                b44.ZipCode = "78712";
               
                b44.Email = "rtaylor@gogle.com";
                b44.PhoneNumber = "8937910053";
                AppUsers.Add(b44);

                AppUser b45 = new AppUser();
               
                b45.Password = "teeoff22";
                b45.LastName = "Tee";
                b45.FirstName = "Frank";
                b45.MiddleInitial = "J";
                b45.Birthday = "36044";
                b45.StreetAddress = "3567 Dawn Plaza";
                b45.City = "Austin";
                b45.State = "TX";
                b45.ZipCode = "78786";
              
                b45.Email = "teefrank@noclue.com";
                b45.PhoneNumber = "6394568913";
                AppUsers.Add(b45);

                AppUser b46 = new AppUser();
              
                b46.Password = "tucksack1";
                b46.LastName = "Tucker";
                b46.FirstName = "Clent";
                b46.MiddleInitial = "J";
                b46.Birthday = "15762";
                b46.StreetAddress = "704 Northland Alley";
                b46.City = "San Antonio";
                b46.State = "TX";
                b46.ZipCode = "78279";
               
                b46.Email = "ctucker@alphabet.co.uk";
                b46.PhoneNumber = "2676838676";
                AppUsers.Add(b46);

                AppUser b47 = new AppUser();
                
                b47.Password = "meow88";
                b47.LastName = "Velasco";
                b47.FirstName = "Allen";
                b47.MiddleInitial = "G";
                b47.Birthday = "31300";
                b47.StreetAddress = "72 Harbort Point";
                b47.City = "Navasota";
                b47.State = "TX";
                b47.ZipCode = "77868";
              
                b47.Email = "avelasco@yoho.com";
                b47.PhoneNumber = "3452909754";
                AppUsers.Add(b47);

                AppUser b48 = new AppUser();
                
                b48.Password = "vinovino";
                b48.LastName = "Vino";
                b48.FirstName = "Janet";
                b48.MiddleInitial = "E";
                b48.Birthday = "31085";
                b48.StreetAddress = "1 Oak Valley Place";
                b48.City = "Boston";
                b48.State = "MA";
                b48.ZipCode = "02114";
              
                b48.Email = "vinovino@grapes.com";
                b48.PhoneNumber = "8567089194";
                AppUsers.Add(b48);

                AppUser b49 = new AppUser();
               
                b49.Password = "gowest";
                b49.LastName = "West";
                b49.FirstName = "Jake";
                b49.MiddleInitial = "T";
                b49.Birthday = "27768";
                b49.StreetAddress = "48743 Banding Parkway";
                b49.City = "Marble Falls";
                b49.State = "TX";
                b49.ZipCode = "78654";
               
                b49.Email = "westj@pioneer.net";
                b49.PhoneNumber = "6260784394";
                AppUsers.Add(b49);

                AppUser b50 = new AppUser();
               
                b50.Password = "louielouie";
                b50.LastName = "Winthorpe";
                b50.FirstName = "Louis";
                b50.MiddleInitial = "L";
                b50.Birthday = "19468";
                b50.StreetAddress = "96850 Summit Crossing";
                b50.City = "Austin";
                b50.State = "TX";
                b50.ZipCode = "78730";
            
                b50.Email = "winner@hootmail.com";
                b50.PhoneNumber = "3733971174";
                AppUsers.Add(b50);

                AppUser b51 = new AppUser();
               
                b51.Password = "woodyman1";
                b51.LastName = "Wood";
                b51.FirstName = "Reagan";
                b51.MiddleInitial = "B.";
                b51.Birthday = "37618";
                b51.StreetAddress = "18354 Bluejay Street";
                b51.City = "Austin";
                b51.State = "TX";
                b51.ZipCode = "78712";
               
                b51.Email = "rwood@voyager.net";
                b51.PhoneNumber = "8433359800";
                AppUsers.Add(b51);

                //loop through repos
                foreach (AppUser aAppUser in AppUsers)
                {
                    //set name of repo to help debug
                    AppUserPhoneNumber = aAppUser.PhoneNumber;

                    //see if repo exists in database
                    AppUser dbAppUser = db.AppUsers.FirstOrDefault(r => r.PhoneNumber == aAppUser.PhoneNumber);

                    if (dbAppUser == null) //Customer does not exist in database
                    {
                        db.AppUsers.Add(aAppUser);
                        db.SaveChanges();
                        intCustomersAdded += 1;
                    }
                    else
                    {
                        
                        dbAppUser.Password = aAppUser.Password;
                        dbAppUser.LastName = aAppUser.LastName;
                        dbAppUser.FirstName = aAppUser.FirstName;
                        dbAppUser.MiddleInitial = aAppUser.MiddleInitial;
                        dbAppUser.Birthday = aAppUser.Birthday;
                        dbAppUser.StreetAddress = aAppUser.StreetAddress;
                        dbAppUser.City = aAppUser.City;
                        dbAppUser.State = aAppUser.State;
                        dbAppUser.ZipCode = aAppUser.ZipCode;
                     
                        dbAppUser.Email = aAppUser.Email;
                        dbAppUser.PhoneNumber = aAppUser.PhoneNumber;
                        db.Update(dbAppUser);
                        db.SaveChanges();
                    }
                }
            }
            catch
            {
                String msg = "Customers added:" + intCustomersAdded + "; Error on " + AppUserPhoneNumber;
                throw new InvalidOperationException(msg);
            }
        }
    }
}
