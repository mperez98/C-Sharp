﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

//TODO: Make these using statements match your project
using Team6FinalProject.DAL;
using Team6FinalProject.Models;

//TODO: Change this namespace to match your project
namespace Team6FinalProject.Seeding
{
    //add identity data
    public static class SeedIdentity
    {
        public static async Task AddAdmin(IServiceProvider serviceProvider)
        {
            AppDbContext _db = serviceProvider.GetRequiredService<AppDbContext>();
            UserManager<AppUser> _userManager = serviceProvider.GetRequiredService<UserManager<AppUser>>();
            RoleManager<IdentityRole> _roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            // Add the roles 
            //if role doesn't exist, add it
            if (await _roleManager.RoleExistsAsync("Manager") == false)
            {
                await _roleManager.CreateAsync(new IdentityRole("Manager"));
            }

            if (await _roleManager.RoleExistsAsync("Employee") == false)
            {
                await _roleManager.CreateAsync(new IdentityRole("Employee"));
            }

            if (await _roleManager.RoleExistsAsync("Customer") == false)
            {
                await _roleManager.CreateAsync(new IdentityRole("Customer"));
            }

            String LastAdded = "Begin";
            Int32 Count = 0;

            try
            {

                //check to see if the manager has been added
                AppUser m1 = _db.Users.FirstOrDefault(u => u.Email == "c.baker@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (m1 == null)
                {
                    m1 = new AppUser();
                    m1.UserName = "c.baker@bevosbooks.com";
                    m1.LastName = "Baker";
                    m1.FirstName = "Christopher";
                    m1.MiddleInitial = "E";
                    m1.StreetAddress = "1245 Lake Libris Dr.";
                    m1.City = "Cedar Park";
                    m1.State = "TX";
                    m1.ZipCode = "78613";
                    m1.PhoneNumber = "3395325649";
                    m1.Email = "c.baker@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(m1, "dewey4");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    m1 = _db.Users.FirstOrDefault(u => u.UserName == "c.baker@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(m1, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(m1, "Manager");
                }
                LastAdded = m1.Email;
                _db.SaveChanges();

                //check to see if the manager has been added
                AppUser m2 = _db.Users.FirstOrDefault(u => u.Email == "e.rice@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (m2 == null)
                {
                    m2 = new AppUser();
                    m2.UserName = "e.rice@bevosbooks.com";
                    m2.LastName = "Rice";
                    m2.FirstName = "Eryn";
                    m2.MiddleInitial = "M";
                    m2.StreetAddress = "3405 Rio Grande";
                    m2.City = "Austin";
                    m2.State = "TX";
                    m2.ZipCode = "78746";
                    m2.PhoneNumber = "270660503";
                    m2.Email = "e.rice@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(m2, "arched");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    
                    _db.SaveChanges();
                    m2 = _db.Users.FirstOrDefault(u => u.UserName == "e.rice@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(m2, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(m2, "Manager");
                }

                LastAdded = m2.Email;
                _db.SaveChanges();


                //check to see if the manager has been added
                AppUser m3 = _db.Users.FirstOrDefault(u => u.Email == "a.rogers@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (m3 == null)
                {

                    m3 = new AppUser();
                    m3.UserName = "a.rogers@bevosbooks.com";
                    m3.LastName = "Rogers";
                    m3.FirstName = "Allen";
                    m3.MiddleInitial = "H";
                    m3.StreetAddress = "4965 Oak Hill";
                    m3.City = "Austin";
                    m3.State = "TX";
                    m3.ZipCode = "78705";
                    m3.PhoneNumber = "4139645586";
                    m3.Email = "a.rogers@bevosbooks.com";


                    var result = await _userManager.CreateAsync(m3, "lottery");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    m3 = _db.Users.FirstOrDefault(u => u.UserName == "a.rogers@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(m3, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(m3, "Manager");
                }
                LastAdded = m3.Email;

                _db.SaveChanges();


                /////////////////////


                //check to see if the manager has been added
                AppUser m4 = _db.Users.FirstOrDefault(u => u.Email == "w.sewell@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (m4 == null)
                {

                    m4 = new AppUser();
                    m4.UserName = "w.sewell@bevosbooks.com";
                    m4.LastName = "Sewell";
                    m4.FirstName = "William";
                    m4.MiddleInitial = "G";

                    m4.StreetAddress = "2365 51st St.";
                    m4.City = "Austin";
                    m4.State = "TX";
                    m4.ZipCode = "78755";
                    m4.PhoneNumber = "744308314";
                    m4.Email = "w.sewell@bevosbooks.com";


                    var result = await _userManager.CreateAsync(m4, "offbeat");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    m4 = _db.Users.FirstOrDefault(u => u.UserName == "w.sewell@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(m4, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(m4, "Manager");
                }
                LastAdded = m4.Email;

                _db.SaveChanges();




                //check to see if the manager has been added
                AppUser m5 = _db.Users.FirstOrDefault(u => u.Email == "r.taylor@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (m5 == null)
                {

                    m5 = new AppUser();
                    m5.UserName = "r.taylor@bevosbooks.com";
                    m5.LastName = "Taylor";
                    m5.FirstName = "Rachel";
                    m5.MiddleInitial = "O";
                    m5.StreetAddress = "345 Longview Dr.";
                    m5.City = "Austin";
                    m5.State = "TX";
                    m5.ZipCode = "78746";
                    m5.PhoneNumber = "9071236087";
                    m5.Email = "r.taylor@bevosbooks.com";

                    var result = await _userManager.CreateAsync(m5, "landus");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    m4 = _db.Users.FirstOrDefault(u => u.UserName == "r.taylor@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(m5, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(m5, "Manager");
                }
                LastAdded = m5.Email;

                _db.SaveChanges();


                // Seeding Employees

                //check to see if the manager has been added
                AppUser e1 = _db.Users.FirstOrDefault(u => u.Email == "s.barnes@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e1 == null)
                {
                    e1 = new AppUser();
                    e1.UserName = "s.barnes@bevosbooks.com";
                    e1.LastName = "Barnes";
                    e1.FirstName = "Susan";
                    e1.MiddleInitial = "M";
                    // b1.Password = "smitty";


                    e1.StreetAddress = "888 S. Main";
                    e1.City = "Kyle";
                    e1.State = "TX";
                    e1.ZipCode = "78640";
                    e1.PhoneNumber = "9636389416";
                    e1.Email = "s.barnes@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e1, "smitty");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e1 = _db.Users.FirstOrDefault(u => u.UserName == "s.barnes@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e1, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e1, "Employee");
                }

                LastAdded = e1.Email;
                _db.SaveChanges();

                AppUser e2 = _db.Users.FirstOrDefault(u => u.Email == "h.garcia@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e2 == null)
                {
                    e2 = new AppUser();
                    e2.UserName = "h.garcia@bevosbooks.com";

                    e2.LastName = "Garcia";
                    e2.FirstName = "Hector";
                    e2.MiddleInitial = "W";
                    //   c3.Password = "squirrel";


                    e2.StreetAddress = "777 PBR Drive";
                    e2.City = "Austin";
                    e2.State = "TX";
                    e2.ZipCode = "78712";
                    e2.PhoneNumber = "4547135738";
                    e2.Email = "h.garcia@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e2, "squirrel");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e2 = _db.Users.FirstOrDefault(u => u.UserName == "h.garcia@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e2, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e2, "Employee");
                }
                LastAdded = e2.Email;

                _db.SaveChanges();

                AppUser e3 = _db.Users.FirstOrDefault(u => u.Email == "b.ingram@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e3 == null)
                {
                    e3 = new AppUser();
                    e3.UserName = "b.ingram@bevosbooks.com";
                    e3.LastName = "Ingram";
                    e3.FirstName = "Brad";
                    e3.MiddleInitial = "S";
                    // c4.Password = "changalang";


                    e3.StreetAddress = "6548 La Posada Ct.";
                    e3.City = "Austin";
                    e3.State = "TX";
                    e3.ZipCode = "78705";
                    e3.PhoneNumber = "5817343315";
                    e3.Email = "b.ingram@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e3, "changalang");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e3 = _db.Users.FirstOrDefault(u => u.UserName == "b.ingram@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e3, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e3, "Employee");
                }
                LastAdded = e3.Email;

                _db.SaveChanges();

                AppUser e4 = _db.Users.FirstOrDefault(u => u.Email == "j.jackson@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e4 == null)
                {
                    e4 = new AppUser();
                    e4.UserName = "j.jackson@bevosbooks.com";
                    e4.LastName = "Jackson";
                    e4.FirstName = "Jack";
                    e4.MiddleInitial = "J";
                    // c5.Password = "rhythm";


                    e4.StreetAddress = "222 Main";
                    e4.City = "Austin";
                    e4.State = "TX";
                    e4.ZipCode = "78760";
                    e4.PhoneNumber = "8241915317";
                    e4.Email = "j.jackson@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e4, "rhythm");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();

                    e4 = _db.Users.FirstOrDefault(u => u.UserName == "j.jackson@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e4, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e4, "Employee");
                }
                LastAdded = e4.Email;
                _db.SaveChanges();



                AppUser e5 = _db.Users.FirstOrDefault(u => u.Email == "t.jacobs@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e5 == null)
                {

                    e5 = new AppUser();
                    e5.UserName = "t.jacobs@bevosbooks.com";
                    e5.LastName = "Jacobs";
                    e5.FirstName = "Todd";
                    e5.MiddleInitial = "L";
                    //  c6.Password = "approval";


                    e5.StreetAddress = "4564 Elm St.";
                    e5.City = "Georgetown";
                    e5.State = "TX";
                    e5.ZipCode = "78628";
                    e5.PhoneNumber = "2477822475";
                    e5.Email = "t.jacobs@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e5, "approval");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e5 = _db.Users.FirstOrDefault(u => u.UserName == "t.jacobs@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e5, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e5, "Employee");
                }

                LastAdded = e5.Email;
                _db.SaveChanges();


                AppUser e6 = _db.Users.FirstOrDefault(u => u.Email == "l.jones@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e6 == null)
                {

                    e6 = new AppUser();
                    e6.UserName = "l.jones@bevosbooks.com";
                    e6.LastName = "Jones";
                    e6.FirstName = "Lester";
                    e6.MiddleInitial = "L";


                    e6.StreetAddress = "999 LeBlat";
                    e6.City = "Austin";
                    e6.State = "TX";
                    e6.ZipCode = "78747";
                    e6.PhoneNumber = "4764966462";
                    e6.Email = "l.jones@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e6, "society");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e6 = _db.Users.FirstOrDefault(u => u.UserName == "l.jones@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e6, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e6, "Employee");
                }

                LastAdded = e6.Email;
                _db.SaveChanges();


                AppUser e7 = _db.Users.FirstOrDefault(u => u.Email == "b.larson@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e7 == null)
                {


                    e7 = new AppUser();
                    e7.UserName = "b.larson@bevosbooks.com";

                    e7.LastName = "Larson";
                    e7.FirstName = "Bill";
                    e7.MiddleInitial = "B";



                    e7.StreetAddress = "1212 N. First Ave";
                    e7.City = "Round Rock";
                    e7.State = "TX";
                    e7.ZipCode = "78665";
                    e7.PhoneNumber = "3355258855";
                    e7.Email = "b.larson@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e7, "tanman");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e7 = _db.Users.FirstOrDefault(u => u.UserName == "b.larson@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e7, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e7, "Employee");
                }
                LastAdded = e7.Email;
                _db.SaveChanges();



                AppUser e8 = _db.Users.FirstOrDefault(u => u.Email == "v.lawrence@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e8 == null)
                {
                    e8 = new AppUser();
                    e8.UserName = "v.lawrence@bevosbooks.com";
                    e8.LastName = "Lawrence";
                    e8.FirstName = "Victoria";
                    e8.MiddleInitial = "Y";


                    e8.StreetAddress = "6639 Bookworm Ln.";
                    e8.City = "Austin";
                    e8.State = "TX";
                    e8.ZipCode = "78712";
                    e8.PhoneNumber = "7511273054";
                    e8.Email = "v.lawrence@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e8, "longhorns");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e8 = _db.Users.FirstOrDefault(u => u.UserName == "v.lawrence@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e8, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e8, "Employee");
                }
                LastAdded = e8.Email;
                _db.SaveChanges();

                AppUser e9 = _db.Users.FirstOrDefault(u => u.Email == "m.lopez@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e9 == null)
                {

                    e9 = new AppUser();
                    e9.UserName = "m.lopez@bevosbooks.com";
                    e9.LastName = "Lopez";
                    e9.FirstName = "Marshall";
                    e9.MiddleInitial = "T";



                    e9.StreetAddress = "90 SW North St";
                    e9.City = "Austin";
                    e9.State = "TX";
                    e9.ZipCode = "78729";
                    e9.PhoneNumber = "7477907070";
                    e9.Email = "m.lopez@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e9, "swansong");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e9 = _db.Users.FirstOrDefault(u => u.UserName == "m.lopez@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e9, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e9, "Employee");
                }
                LastAdded = e9.Email;
                _db.SaveChanges();



                AppUser e10 = _db.Users.FirstOrDefault(u => u.Email == "j.macleod@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e10 == null)
                {
                    e10 = new AppUser();
                    e10.UserName = "j.macleod@bevosbooks.com";
                    e10.LastName = "MacLeod";
                    e10.FirstName = "Jennifer";
                    e10.MiddleInitial = "D";



                    e10.StreetAddress = "2504 Far West Blvd.";
                    e10.City = "Austin";
                    e10.State = "TX";
                    e10.ZipCode = "78705";
                    e10.PhoneNumber = "2621216845";
                    e10.Email = "j.macleod@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e10, "fungus");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e10 = _db.Users.FirstOrDefault(u => u.UserName == "j.macleod@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e10, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e10, "Employee");
                }
                LastAdded = e10.Email;
                _db.SaveChanges();




                AppUser e11 = _db.Users.FirstOrDefault(u => u.Email == "e.markham@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e11 == null)
                {

                    e11 = new AppUser();
                    e11.UserName = "e.markham@bevosbooks.com";
                    e11.LastName = "Markham";
                    e11.FirstName = "Elizabeth";
                    e11.MiddleInitial = "K";


                    e11.StreetAddress = "7861 Chevy Chase";
                    e11.City = "Austin";
                    e11.State = "TX";
                    e11.ZipCode = "78785";
                    e11.PhoneNumber = "5028075807";
                    e11.Email = "e.markham@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e11, "median");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e11 = _db.Users.FirstOrDefault(u => u.UserName == "e.markham@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e11, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e11, "Employee");
                }
                LastAdded = e11.Email;
                _db.SaveChanges();


                AppUser e12 = _db.Users.FirstOrDefault(u => u.Email == "g.martinez@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e12 == null)
                {
                    e12 = new AppUser();
                    e12.UserName = "g.martinez@bevosbooks.com";
                    e12.LastName = "Martinez";
                    e12.FirstName = "Gregory";
                    e12.MiddleInitial = "R";



                    e12.StreetAddress = "8295 Sunset Blvd.";
                    e12.City = "Austin";
                    e12.State = "TX";
                    e12.ZipCode = "78712";
                    e12.PhoneNumber = "1994708542";
                    e12.Email = "g.martinez@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e12, "decorate");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e12 = _db.Users.FirstOrDefault(u => u.UserName == "g.martinez@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e12, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e12, "Employee");
                }
                LastAdded = e11.Email;
                _db.SaveChanges();


                AppUser e13 = _db.Users.FirstOrDefault(u => u.Email == "j.mason@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e13 == null)
                {
                    e13 = new AppUser();
                    e13.UserName = "j.mason@bevosbooks.com";
                    e13.LastName = "Mason";
                    e13.FirstName = "Jack";
                    e13.MiddleInitial = "L";



                    e13.StreetAddress = "444 45th St";
                    e13.City = "Austin";
                    e13.State = "TX";
                    e13.ZipCode = "78701";
                    e13.PhoneNumber = "1748136441";
                    e13.Email = "j.mason@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e13, "rankmary");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e13 = _db.Users.FirstOrDefault(u => u.UserName == "j.mason@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e13, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e13, "Employee");
                }
                LastAdded = e13.Email;
                _db.SaveChanges();

                AppUser e14 = _db.Users.FirstOrDefault(u => u.Email == "c.miller@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e14 == null)
                {
                    e14 = new AppUser();
                    e14.UserName = "c.miller@bevosbooks.com";
                    e14.LastName = "Miller";
                    e14.FirstName = "Charles";
                    e14.MiddleInitial = "R";



                    e14.StreetAddress = "8962 Main St.";
                    e14.City = "Austin";
                    e14.State = "TX";
                    e14.ZipCode = "78709";
                    e14.PhoneNumber = "8999319585";
                    e14.Email = "c.miller@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e14, "kindly");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e14 = _db.Users.FirstOrDefault(u => u.UserName == "c.miller@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e14, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e14, "Employee");
                }
                LastAdded = e14.Email;
                _db.SaveChanges();


                AppUser e15 = _db.Users.FirstOrDefault(u => u.Email == "m.nguyen@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e15 == null)
                {
                    e15 = new AppUser();
                    e15.UserName = "m.nguyen@bevosbooks.com";
                    e15.LastName = "Nguyen";
                    e15.FirstName = "Mary";
                    e15.MiddleInitial = "J";


                    e15.StreetAddress = "465 N. Bear Cub";
                    e15.City = "Austin";
                    e15.State = "TX";
                    e15.ZipCode = "78734";
                    e15.PhoneNumber = "8716746381";
                    e15.Email = "m.nguyen@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e15, "ricearoni");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e15 = _db.Users.FirstOrDefault(u => u.UserName == "m.nguyen@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e15, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e15, "Employee");
                }
                LastAdded = e15.Email;
                _db.SaveChanges();

                AppUser e16 = _db.Users.FirstOrDefault(u => u.Email == "s.rankin@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e16 == null)
                {
                    e16 = new AppUser();
                    e16.UserName = "s.rankin@bevosbooks.com";
                    e16.LastName = "Rankin";
                    e16.FirstName = "Suzie";
                    e16.MiddleInitial = "R";



                    e16.StreetAddress = "23 Dewey Road";
                    e16.City = "Austin";
                    e16.State = "TX";
                    e16.ZipCode = "78712";
                    e16.PhoneNumber = "5239029525";
                    e16.Email = "s.rankin@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e16, "walkamile");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e16 = _db.Users.FirstOrDefault(u => u.UserName == "s.rankin@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e16, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e16, "Employee");
                }
                LastAdded = e16.Email;
                _db.SaveChanges();



                AppUser e17 = _db.Users.FirstOrDefault(u => u.Email == "m.rhodes@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e17 == null)
                {
                    e17 = new AppUser();
                    e17.UserName = "m.rhodes@bevosbooks.com";
                    e17.LastName = "Rhodes";
                    e17.FirstName = "Megan";
                    e17.MiddleInitial = "C";



                    e17.StreetAddress = "4587 Enfield Rd.";
                    e17.City = "Austin";
                    e17.State = "TX";
                    e17.ZipCode = "78729";
                    e17.PhoneNumber = "1232139514";
                    e17.Email = "m.rhodes@bevosbooks.com";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e17, "ingram45");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e17 = _db.Users.FirstOrDefault(u => u.UserName == "m.rhodes@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e17, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e17, "Employee");
                }
                LastAdded = e17.Email;
                _db.SaveChanges();

                AppUser e18 = _db.Users.FirstOrDefault(u => u.Email == "s.saunders@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e18 == null)
                {
                    e18 = new AppUser();
                    e18.UserName = "s.saunders@bevosbooks.com";
                    e18.LastName = "Saunders";
                    e18.FirstName = "Sarah";
                    e18.MiddleInitial = "M";



                    e18.StreetAddress = "332 Avenue C";
                    e18.City = "Austin";
                    e18.State = "TX";
                    e18.ZipCode = "78733";
                    e18.PhoneNumber = "9036349587";
                    e18.Email = "s.saunders@bevosbooks.com";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e18, "nostalgic");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e18 = _db.Users.FirstOrDefault(u => u.UserName == "s.saunders@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e18, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e18, "Employee");
                }

                LastAdded = e18.Email;
                _db.SaveChanges();


                AppUser e19 = _db.Users.FirstOrDefault(u => u.Email == "m.sheffield@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e19 == null)
                {
                    e19 = new AppUser();
                    e19.UserName = "m.sheffield@bevosbooks.com";
                    e19.LastName = "Sheffield";
                    e19.FirstName = "Martin";
                    e19.MiddleInitial = "J";



                    e19.StreetAddress = "3886 Avenue A";
                    e19.City = "San Marcos";
                    e19.State = "TX";
                    e19.ZipCode = "78666";
                    e19.PhoneNumber = "9349192978";
                    e19.Email = "m.sheffield@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e19, "evanescent");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e19 = _db.Users.FirstOrDefault(u => u.UserName == "m.sheffield@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e19, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e19, "Employee");
                }
                LastAdded = e19.Email;

                _db.SaveChanges();




                AppUser e20 = _db.Users.FirstOrDefault(u => u.Email == "c.silva@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e20 == null)
                {
                    e20 = new AppUser();
                    e20.UserName = "c.silva@bevosbooks.com";
                    e20.LastName = "Silva";
                    e20.FirstName = "Cindy";
                    e20.MiddleInitial = "S";



                    e20.StreetAddress = "900 4th St";
                    e20.City = "Austin";
                    e20.State = "TX";
                    e20.ZipCode = "78758";
                    e20.PhoneNumber = "4874328170";
                    e20.Email = "c.silva@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e20, "stewboy");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e20 = _db.Users.FirstOrDefault(u => u.UserName == "c.silva@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e20, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e20, "Employee");
                }

                LastAdded = e20.Email;

                _db.SaveChanges();



                AppUser e21 = _db.Users.FirstOrDefault(u => u.Email == "e.stuart@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e21 == null)
                {

                    e21 = new AppUser();
                    e21.UserName = "e.stuart@bevosbooks.com";
                    e21.LastName = "Stuart";
                    e21.FirstName = "Eric";
                    e21.MiddleInitial = "F";



                    e21.StreetAddress = "5576 Toro Ring";
                    e21.City = "Austin";
                    e21.State = "TX";
                    e21.ZipCode = "78758";
                    e21.PhoneNumber = "1967846827";
                    e21.Email = "e.stuart@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e21, "instrument");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e21 = _db.Users.FirstOrDefault(u => u.UserName == "e.stuart@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e21, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e21, "Employee");
                }

                LastAdded = e21.Email;

                _db.SaveChanges();





                AppUser e22 = _db.Users.FirstOrDefault(u => u.Email == "j.tanner@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e22 == null)
                {
                    e22 = new AppUser();
                    e22.UserName = "j.tanner@bevosbooks.com";
                    e22.LastName = "Tanner";
                    e22.FirstName = "Jeremy";
                    e22.MiddleInitial = "S";


                    e22.StreetAddress = "4347 Almstead";
                    e22.City = "Austin";
                    e22.State = "TX";
                    e22.ZipCode = "78712";
                    e22.PhoneNumber = "5923026779";
                    e22.Email = "j.tanner@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e22, "hecktour");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e22 = _db.Users.FirstOrDefault(u => u.UserName == "j.tanner@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e22, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e22, "Employee");
                }
                LastAdded = e22.Email;
                _db.SaveChanges();




                AppUser e23 = _db.Users.FirstOrDefault(u => u.Email == "a.taylor@bevosbooks.com");

                //if manager hasn't been created, then add them
                if (e23 == null)
                {

                    e23 = new AppUser();
                    e23.UserName = "a.taylor@bevosbooks.com";
                    e23.LastName = "Taylor";
                    e23.FirstName = "Allison";
                    e23.MiddleInitial = "R";

                    e23.StreetAddress = "467 Nueces St.";
                    e23.City = "Austin";
                    e23.State = "TX";
                    e23.ZipCode = "78727";
                    e23.PhoneNumber = "7246195827";
                    e23.Email = "a.taylor@bevosbooks.com";




                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(e23, "countryrhodes");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    e23 = _db.Users.FirstOrDefault(u => u.UserName == "a.taylor@bevosbooks.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(e23, "Employee") == false)
                {
                    await _userManager.AddToRoleAsync(e23, "Employee");
                }
                LastAdded = e23.Email;

                _db.SaveChanges();



                //Customers

                AppUser c1 = _db.Users.FirstOrDefault(u => u.Email == "cbaker@example.com");

                //if manager hasn't been created, then add them
                if (c1 == null)
                {


                    c1 = new AppUser();
                    c1.UserName = "cbaker@example.com";
                    c1.LastName = "Baker";
                    c1.FirstName = "Christopher";
                    c1.MiddleInitial = "L.";
                    c1.Birthday = "18225";
                    c1.StreetAddress = "1898 Schurz Alley";
                    c1.City = "Austin";
                    c1.State = "TX";
                    c1.ZipCode = "78705";
                    c1.Email = "cbaker@example.com";
                    c1.PhoneNumber = "5725458641";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c1, "bookworm");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c1 = _db.Users.FirstOrDefault(u => u.UserName == "cbaker@example.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c1, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c1, "Customer");
                }
                LastAdded = c1.Email;
                _db.SaveChanges();




                AppUser c2 = _db.Users.FirstOrDefault(u => u.Email == "banker@longhorn.net");

                //if manager hasn't been created, then add them
                if (c2 == null)
                {

                    c2 = new AppUser();
                    c2.UserName = "banker@longhorn.net";
                    c2.LastName = "Banks";
                    c2.FirstName = "Michelle";
                    c2.MiddleInitial = "";
                    c2.Birthday = "22977";
                    c2.StreetAddress = "97 Elmside Pass";
                    c2.City = "Austin";
                    c2.State = "TX";
                    c2.ZipCode = "78712";
                    c2.Email = "banker@longhorn.net";
                    c2.PhoneNumber = "9867048435";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c2, "potato");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c2 = _db.Users.FirstOrDefault(u => u.UserName == "banker@longhorn.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c2, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c2, "Customer");
                }
                LastAdded = c2.Email;
                _db.SaveChanges();



                AppUser c3 = _db.Users.FirstOrDefault(u => u.Email == "franco@example.com");

                //if manager hasn't been created, then add them
                if (c3 == null)
                {

                    c3 = new AppUser();
                    c3.UserName = "franco@example.com";
                    c3.LastName = "Broccolo";
                    c3.FirstName = "Franco";
                    c3.MiddleInitial = "V";
                    c3.Birthday = "33888";
                    c3.StreetAddress = "88 Crowley Circle";
                    c3.City = "Austin";
                    c3.State = "TX";
                    c3.ZipCode = "78786";

                    c3.Email = "franco@example.com";
                    c3.PhoneNumber = "6836109514";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c3, "painting");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c3 = _db.Users.FirstOrDefault(u => u.UserName == "franco@example.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c3, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c3, "Customer");
                }

                LastAdded = c3.Email;

                _db.SaveChanges();



                AppUser c4 = _db.Users.FirstOrDefault(u => u.Email == "wchang@example.com");

                //if manager hasn't been created, then add them
                if (c4 == null)
                {


                    c4 = new AppUser();

                    c4.UserName = "wchang@example.com";
                    c4.LastName = "Chang";
                    c4.FirstName = "Wendy";
                    c4.MiddleInitial = "L";
                    c4.Birthday = "35566";
                    c4.StreetAddress = "56560 Sage Junction";
                    c4.City = "Eagle Pass";
                    c4.State = "TX";
                    c4.ZipCode = "78852";

                    c4.Email = "wchang@example.com";
                    c4.PhoneNumber = "7070911071";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c4, "texas1");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c4 = _db.Users.FirstOrDefault(u => u.UserName == "wchang@example.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c4, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c4, "Customer");
                }
                LastAdded = c4.Email;
                _db.SaveChanges();



                AppUser c5 = _db.Users.FirstOrDefault(u => u.Email == "limchou@gogle.com");

                //if manager hasn't been created, then add them
                if (c5 == null)
                {


                    c5 = new AppUser();

                    c5.UserName = "limchou@gogle.com";
                    c5.LastName = "Chou";
                    c5.FirstName = "Lim";
                    c5.MiddleInitial = "";
                    c5.Birthday = "25664";
                    c5.StreetAddress = "60 Lunder Point";
                    c5.City = "Austin";
                    c5.State = "TX";
                    c5.ZipCode = "78729";

                    c5.Email = "limchou@gogle.com";
                    c5.PhoneNumber = "1488907687";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c5, "Anchorage");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c5 = _db.Users.FirstOrDefault(u => u.UserName == "limchou@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c5, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c5, "Customer");
                }
                LastAdded = c5.Email;
                _db.SaveChanges();




                AppUser c6 = _db.Users.FirstOrDefault(u => u.Email == "shdixon@aoll.com");

                //if manager hasn't been created, then add them
                if (c6 == null)
                {

                    c6 = new AppUser();
                    c6.UserName = "shdixon@aoll.com";
                    c6.LastName = "Dixon";
                    c6.FirstName = "Shan";
                    c6.MiddleInitial = "D";
                    c6.Birthday = "30693";
                    c6.StreetAddress = "9448 Pleasure Avenue";
                    c6.City = "Georgetown";
                    c6.State = "TX";
                    c6.ZipCode = "78628";

                    c6.Email = "shdixon@aoll.com";
                    c6.PhoneNumber = "6899701824";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c6, "aggies");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c6 = _db.Users.FirstOrDefault(u => u.UserName == "shdixon@aoll.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c6, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c6, "Customer");
                }

                LastAdded = c6.Email;

                _db.SaveChanges();




                AppUser c7 = _db.Users.FirstOrDefault(u => u.Email == "j.b.evans@aheca.org");

                //if manager hasn't been created, then add them
                if (c7 == null)
                {

                    c7 = new AppUser();
                    c7.UserName = "j.b.evans@aheca.org";
                    c7.LastName = "Evans";
                    c7.FirstName = "Jim Bob";
                    c7.MiddleInitial = "";
                    c7.Birthday = "21802";
                    c7.StreetAddress = "51 Emmet Parkway";
                    c7.City = "Austin";
                    c7.State = "TX";
                    c7.ZipCode = "78705";

                    c7.Email = "j.b.evans@aheca.org";
                    c7.PhoneNumber = "9986825917";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c7, "hampton1");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c7 = _db.Users.FirstOrDefault(u => u.UserName == "j.b.evans@aheca.org");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c7, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c7, "Customer");
                }

                LastAdded = c7.Email;

                _db.SaveChanges();


                AppUser c8 = _db.Users.FirstOrDefault(u => u.Email == "feeley@penguin.org");

                //if manager hasn't been created, then add them
                if (c8 == null)
                {

                    c8 = new AppUser();
                    c8.UserName = "feeley@penguin.org";
                    c8.LastName = "Feeley";
                    c8.FirstName = "Lou Ann";
                    c8.MiddleInitial = "K";
                    c8.Birthday = "36903";
                    c8.StreetAddress = "65 Darwin Crossing";
                    c8.City = "Austin";
                    c8.State = "TX";
                    c8.ZipCode = "78704";

                    c8.Email = "feeley@penguin.org";
                    c8.PhoneNumber = "3464121966";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c8, "longhorns");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c8 = _db.Users.FirstOrDefault(u => u.UserName == "feeley@penguin.org");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c8, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c8, "Customer");
                }
                LastAdded = c8.Email;
                _db.SaveChanges();




                AppUser c9 = _db.Users.FirstOrDefault(u => u.Email == "tfreeley@minnetonka.ci.us");

                //if manager hasn't been created, then add them
                if (c9 == null)
                {
                    c9 = new AppUser();

                    c9.UserName = "tfreeley@minnetonka.ci.us";
                    c9.LastName = "Freeley";
                    c9.FirstName = "Tesa";
                    c9.MiddleInitial = "P";
                    c9.Birthday = "33273";
                    c9.StreetAddress = "7352 Loftsgordon Court";
                    c9.City = "College Station";
                    c9.State = "TX";
                    c9.ZipCode = "77840";

                    c9.Email = "tfreeley@minnetonka.ci.us";
                    c9.PhoneNumber = "6581357270";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c9, "mustangs");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c9 = _db.Users.FirstOrDefault(u => u.UserName == "tfreeley@minnetonka.ci.us");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c9, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c9, "Customer");
                }
                LastAdded = c9.Email;

                _db.SaveChanges();


                AppUser c10 = _db.Users.FirstOrDefault(u => u.Email == "mgarcia@gogle.com");

                //if manager hasn't been created, then add them
                if (c10 == null)
                {
                    c10 = new AppUser();
                    c10.UserName = "mgarcia@gogle.com";
                    c10.LastName = "Garcia";
                    c10.FirstName = "Margaret";
                    c10.MiddleInitial = "L";
                    c10.Birthday = "33513";
                    c10.StreetAddress = "7 International Road";
                    c10.City = "Austin";
                    c10.State = "TX";
                    c10.ZipCode = "78756";

                    c10.Email = "mgarcia@gogle.com";
                    c10.PhoneNumber = "3767347949";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c10, "onetime");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c10 = _db.Users.FirstOrDefault(u => u.UserName == "mgarcia@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c10, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c10, "Customer");
                }
                LastAdded = c10.Email;
                _db.SaveChanges();



                AppUser c11 = _db.Users.FirstOrDefault(u => u.Email == "chaley@thug.com");

                //if manager hasn't been created, then add them
                if (c11 == null)
                {
                    c11 = new AppUser();


                    c11.UserName = "chaley@thug.com";
                    c11.LastName = "Haley";
                    c11.FirstName = "Charles";
                    c11.MiddleInitial = "E";
                    c11.Birthday = "27220";
                    c11.StreetAddress = "8 Warrior Trail";
                    c11.City = "Austin";
                    c11.State = "TX";
                    c11.ZipCode = "78746";

                    c11.Email = "chaley@thug.com";
                    c11.PhoneNumber = "2198604221";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c11, "pepperoni");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c11 = _db.Users.FirstOrDefault(u => u.UserName == "chaley@thug.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c11, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c11, "Customer");
                }
                LastAdded = c11.Email;
                _db.SaveChanges();



                AppUser c12 = _db.Users.FirstOrDefault(u => u.Email == "jeffh@sonic.com");

                //if manager hasn't been created, then add them
                if (c12 == null)
                {
                    c12 = new AppUser();

                    c12.UserName = "jeffh@sonic.com";
                    c12.LastName = "Hampton";
                    c12.FirstName = "Jeffrey";
                    c12.MiddleInitial = "T.";
                    c12.Birthday = "38056";
                    c12.StreetAddress = "9107 Lighthouse Bay Road";
                    c12.City = "Austin";
                    c12.State = "TX";
                    c12.ZipCode = "78756";

                    c12.Email = "jeffh@sonic.com";
                    c12.PhoneNumber = "1222185888";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c12, "raiders");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c12 = _db.Users.FirstOrDefault(u => u.UserName == "jeffh@sonic.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c12, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c12, "Customer");
                }
                LastAdded = c12.Email;
                _db.SaveChanges();


                AppUser c13 = _db.Users.FirstOrDefault(u => u.Email == "wjhearniii@umich.org");

                //if manager hasn't been created, then add them
                if (c13 == null)
                {


                    c13 = new AppUser();
                    c13.UserName = "wjhearniii@umich.org";
                    c13.LastName = "Hearn";
                    c13.FirstName = "John";
                    c13.MiddleInitial = "B";
                    c13.Birthday = "18480";
                    c13.StreetAddress = "59784 Pierstorff Center";
                    c13.City = "Liberty";
                    c13.State = "TX";
                    c13.ZipCode = "77575";

                    c13.Email = "wjhearniii@umich.org";
                    c13.PhoneNumber = "5123071976";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c13, "jhearn22");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c13 = _db.Users.FirstOrDefault(u => u.UserName == "wjhearniii@umich.org");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c13, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c13, "Customer");
                }
                LastAdded = c13.Email;
                _db.SaveChanges();




                AppUser c14 = _db.Users.FirstOrDefault(u => u.Email == "ahick@yaho.com");

                //if manager hasn't been created, then add them
                if (c14 == null)
                {
                    c14 = new AppUser();
                    c14.UserName = "ahick@yaho.com";
                    c14.LastName = "Hicks";
                    c14.FirstName = "Anthony";
                    c14.MiddleInitial = "J";
                    c14.Birthday = "38329";
                    c14.StreetAddress = "932 Monica Way";
                    c14.City = "San Antonio";
                    c14.State = "TX";
                    c14.ZipCode = "78203";

                    c14.Email = "ahick@yaho.com";
                    c14.PhoneNumber = "1211949601";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c14, "hickhickup");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c14 = _db.Users.FirstOrDefault(u => u.UserName == "ahick@yaho.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c14, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c14, "Customer");
                }

                LastAdded = c14.Email;
                _db.SaveChanges();


                AppUser c15 = _db.Users.FirstOrDefault(u => u.Email == "ingram@jack.com");

                //if manager hasn't been created, then add them
                if (c15 == null)
                {

                    c15 = new AppUser();


                    c15.UserName = "ingram@jack.com";
                    c15.LastName = "Ingram";
                    c15.FirstName = "Brad";
                    c15.MiddleInitial = "S.";
                    c15.Birthday = "37139";
                    c15.StreetAddress = "4 Lukken Court";
                    c15.City = "New Braunfels";
                    c15.State = "TX";
                    c15.ZipCode = "78132";

                    c15.Email = "ingram@jack.com";
                    c15.PhoneNumber = "1372121569";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c15, "ingram2015");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c15 = _db.Users.FirstOrDefault(u => u.UserName == "ingram@jack.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c15, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c15, "Customer");
                }
                LastAdded = c15.Email;
                _db.SaveChanges();


                AppUser c16 = _db.Users.FirstOrDefault(u => u.Email == "toddj@yourmom.com");

                //if manager hasn't been created, then add them
                if (c16 == null)
                {

                    c16 = new AppUser();

                    c16.UserName = "toddj@yourmom.com";
                    c16.LastName = "Jacobs";
                    c16.FirstName = "Todd";
                    c16.MiddleInitial = "L.";
                    c16.Birthday = "36180";
                    c16.StreetAddress = "7 Susan Junction";
                    c16.City = "New York";
                    c16.State = "NY";
                    c16.ZipCode = "10101";

                    c16.Email = "toddj@yourmom.com";
                    c16.PhoneNumber = "8543163836";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c16, "toddc175");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c16 = _db.Users.FirstOrDefault(u => u.UserName == "toddj@yourmom.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c16, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c16, "Customer");
                }

                LastAdded = c16.Email;

                _db.SaveChanges();




                AppUser c17 = _db.Users.FirstOrDefault(u => u.Email == "thequeen@aska.net");

                //if manager hasn't been created, then add them
                if (c17 == null)
                {

                    c17 = new AppUser();

                    c17.UserName = "thequeen@aska.net";
                    c17.LastName = "Lawrence";
                    c17.FirstName = "Victoria";
                    c17.MiddleInitial = "M.";
                    c17.Birthday = "36630";
                    c17.StreetAddress = "669 Oak Junction";
                    c17.City = "Lockhart";
                    c17.State = "TX";
                    c17.ZipCode = "78644";

                    c17.Email = "thequeen@aska.net";
                    c17.PhoneNumber = "3214163359";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c17, "something");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c17 = _db.Users.FirstOrDefault(u => u.UserName == "thequeen@aska.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c17, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c17, "Customer");
                }
                LastAdded = c17.Email;

                _db.SaveChanges();



                AppUser c18 = _db.Users.FirstOrDefault(u => u.Email == "linebacker@gogle.com");

                //if manager hasn't been created, then add them
                if (c18 == null)
                {

                    c18 = new AppUser();


                    c18.UserName = "linebacker@gogle.com";
                    c18.LastName = "Lineback";
                    c18.FirstName = "Erik";
                    c18.MiddleInitial = "W";
                    c18.Birthday = "37957";
                    c18.StreetAddress = "099 Luster Point";
                    c18.City = "Kingwood";
                    c18.State = "TX";
                    c18.ZipCode = "77325";

                    c18.Email = "linebacker@gogle.com";
                    c18.PhoneNumber = "2505265350";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c18, "Password1");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c18 = _db.Users.FirstOrDefault(u => u.UserName == "linebacker@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c18, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c18, "Customer");
                }
                LastAdded = c18.Email;

                _db.SaveChanges();




                AppUser c19 = _db.Users.FirstOrDefault(u => u.Email == "elowe@netscare.net");

                //if manager hasn't been created, then add them
                if (c19 == null)
                {

                    c19 = new AppUser();


                    c19.UserName = "elowe@netscare.net";
                    c19.LastName = "Lowe";
                    c19.FirstName = "Ernest";
                    c19.MiddleInitial = "S";
                    c19.Birthday = "28466";
                    c19.StreetAddress = "35473 Hansons Hill";
                    c19.City = "Beverly Hills";
                    c19.State = "CA";
                    c19.ZipCode = "90210";

                    c19.Email = "elowe@netscare.net";
                    c19.PhoneNumber = "4070619503";

                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c19, "aclfest2017");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c19 = _db.Users.FirstOrDefault(u => u.UserName == "elowe@netscare.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c19, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c19, "Customer");
                }

                LastAdded = c19.Email;

                _db.SaveChanges();



                AppUser c20 = _db.Users.FirstOrDefault(u => u.Email == "cluce@gogle.com");

                //if manager hasn't been created, then add them
                if (c20 == null)
                {

                    c20 = new AppUser();


                    c20.UserName = "cluce@gogle.com";
                    c20.LastName = "Luce";
                    c20.FirstName = "Chuck";
                    c20.MiddleInitial = "B";
                    c20.Birthday = "17973";
                    c20.StreetAddress = "4 Emmet Junction";
                    c20.City = "Navasota";
                    c20.State = "TX";
                    c20.ZipCode = "77868";

                    c20.Email = "cluce@gogle.com";
                    c20.PhoneNumber = "7358436110";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c20, "nothinggood");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c20 = _db.Users.FirstOrDefault(u => u.UserName == "cluce@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c20, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c20, "Customer");
                }

                LastAdded = c20.Email;

                _db.SaveChanges();



                AppUser c21 = _db.Users.FirstOrDefault(u => u.Email == "mackcloud@george.com");

                //if manager hasn't been created, then add them
                if (c21 == null)
                {
                    c21 = new AppUser();
                    c21.UserName = "mackcloud@george.com";

                    c21.LastName = "MacLeod";
                    c21.FirstName = "Jennifer";
                    c21.MiddleInitial = "D.";
                    c21.Birthday = "17219";
                    c21.StreetAddress = "3 Orin Road";
                    c21.City = "Austin";
                    c21.State = "TX";
                    c21.ZipCode = "78712";

                    c21.Email = "mackcloud@george.com";
                    c21.PhoneNumber = "7240178229";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c21, "whatever");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c21 = _db.Users.FirstOrDefault(u => u.UserName == "mackcloud@george.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c21, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c21, "Customer");
                }

                LastAdded = c21.Email;
                _db.SaveChanges();



                AppUser c22 = _db.Users.FirstOrDefault(u => u.Email == "cmartin@beets.com");

                //if manager hasn't been created, then add them
                if (c22 == null)
                {

                    c22 = new AppUser();
                    c22.UserName = "cmartin@beets.com";
                    c22.LastName = "Markham";
                    c22.FirstName = "Elizabeth";
                    c22.MiddleInitial = "P.";
                    c22.Birthday = "26378";
                    c22.StreetAddress = "8171 Commercial Crossing";
                    c22.City = "Austin";
                    c22.State = "TX";
                    c22.ZipCode = "78712";

                    c22.Email = "cmartin@beets.com";
                    c22.PhoneNumber = "2495200223";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c22, "snowsnow");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c22 = _db.Users.FirstOrDefault(u => u.UserName == "cmartin@beets.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c22, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c22, "Customer");
                }
                LastAdded = c22.Email;
                _db.SaveChanges();





                AppUser c23 = _db.Users.FirstOrDefault(u => u.Email == "clarence@yoho.com");

                //if manager hasn't been created, then add them
                if (c23 == null)
                {

                    c23 = new AppUser();
                    c23.UserName = "clarence@yoho.com";
                    c23.LastName = "Martin";
                    c23.FirstName = "Clarence";
                    c23.MiddleInitial = "A";
                    c23.Birthday = "33804";
                    c23.StreetAddress = "96 Anthes Place";
                    c23.City = "Schenectady";
                    c23.State = "NY";
                    c23.ZipCode = "12345";

                    c23.Email = "clarence@yoho.com";
                    c23.PhoneNumber = "4086179161";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c23, "whocares");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c23 = _db.Users.FirstOrDefault(u => u.UserName == "clarence@yoho.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c23, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c23, "Customer");
                }
                LastAdded = c23.Email;
                _db.SaveChanges();



                AppUser c24 = _db.Users.FirstOrDefault(u => u.Email == "gregmartinez@drdre.com");

                //if manager hasn't been created, then add them
                if (c24 == null)
                {

                    c24 = new AppUser();
                    c24.UserName = "gregmartinez@drdre.com";
                    c24.LastName = "Martinez";
                    c24.FirstName = "Gregory";
                    c24.MiddleInitial = "R.";
                    c24.Birthday = "17315";
                    c24.StreetAddress = "10 Northridge Plaza";
                    c24.City = "Austin";
                    c24.State = "TX";
                    c24.ZipCode = "78717";

                    c24.Email = "gregmartinez@drdre.com";
                    c24.PhoneNumber = "9371927523";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c24, "xcellent");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c24 = _db.Users.FirstOrDefault(u => u.UserName == "gregmartinez@drdre.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c24, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c24, "Customer");
                }
                LastAdded = c24.Email;
                _db.SaveChanges();


                AppUser c25 = _db.Users.FirstOrDefault(u => u.Email == "cmiller@bob.com");

                //if manager hasn't been created, then add them
                if (c25 == null)
                {
                    c25 = new AppUser();


                    c25.UserName = "cmiller@bob.com";
                    c25.LastName = "Miller";
                    c25.FirstName = "Charles";
                    c25.MiddleInitial = "R.";
                    c25.Birthday = "33161";
                    c25.StreetAddress = "87683 Schmedeman Circle";
                    c25.City = "Austin";
                    c25.State = "TX";
                    c25.ZipCode = "78727";

                    c25.Email = "cmiller@bob.com";
                    c25.PhoneNumber = "5954063857";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c25, "mydogspot");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c25 = _db.Users.FirstOrDefault(u => u.UserName == "cmiller@bob.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c25, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c25, "Customer");
                }
                LastAdded = c25.Email;

                _db.SaveChanges();



                AppUser c26 = _db.Users.FirstOrDefault(u => u.Email == "knelson@aoll.com");

                //if manager hasn't been created, then add them
                if (c26 == null)
                {

                    c26 = new AppUser();

                    c26.UserName = "knelson@aoll.com";
                    c26.LastName = "Nelson";
                    c26.FirstName = "Kelly";
                    c26.MiddleInitial = "T";
                    c26.Birthday = "26127";
                    c26.StreetAddress = "3244 Ludington Court";
                    c26.City = "Beaumont";
                    c26.State = "TX";
                    c26.ZipCode = "77720";

                    c26.Email = "knelson@aoll.com";
                    c26.PhoneNumber = "8929209512";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c26, "spotmydog");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c26 = _db.Users.FirstOrDefault(u => u.UserName == "knelson@aoll.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c26, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c26, "Customer");
                }
                LastAdded = c26.Email;

                _db.SaveChanges();



                AppUser c27 = _db.Users.FirstOrDefault(u => u.Email == "joewin@xfactor.com");

                //if manager hasn't been created, then add them
                if (c27 == null)
                {
                    c27 = new AppUser();

                    c27.UserName = "joewin@xfactor.com";
                    c27.LastName = "Nguyen";
                    c27.FirstName = "Joe";
                    c27.MiddleInitial = "C";
                    c27.Birthday = "30758";
                    c27.StreetAddress = "4780 Talisman Court";
                    c27.City = "San Marcos";
                    c27.State = "TX";
                    c27.ZipCode = "78667";

                    c27.Email = "joewin@xfactor.com";
                    c27.PhoneNumber = "9226301774";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c27, "joejoejoe");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c27 = _db.Users.FirstOrDefault(u => u.UserName == "joewin@xfactor.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c27, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c27, "Customer");
                }

                LastAdded = c27.Email;

                _db.SaveChanges();



                AppUser c28 = _db.Users.FirstOrDefault(u => u.Email == "orielly@foxnews.cnn");

                //if manager hasn't been created, then add them
                if (c28 == null)
                {

                    c28 = new AppUser();


                    c28.UserName = "orielly@foxnews.cnn";
                    c28.LastName = "O'Reilly";
                    c28.FirstName = "Bill";
                    c28.MiddleInitial = "T";
                    c28.Birthday = "21739";
                    c28.StreetAddress = "4154 Delladonna Plaza";
                    c28.City = "Bergheim";
                    c28.State = "TX";
                    c28.ZipCode = "78004";

                    c28.Email = "orielly@foxnews.cnn";
                    c28.PhoneNumber = "2537646912";

                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c28, "billyboy");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c28 = _db.Users.FirstOrDefault(u => u.UserName == "orielly@foxnews.cnn");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c28, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c28, "Customer");
                }
                LastAdded = c28.Email;
                _db.SaveChanges();



                AppUser c29 = _db.Users.FirstOrDefault(u => u.Email == "ankaisrad@gogle.com");

                //if manager hasn't been created, then add them
                if (c29 == null)
                {
                    c29 = new AppUser();

                    c29.UserName = "ankaisrad@gogle.com";
                    c29.LastName = "Radkovich";
                    c29.FirstName = "Anka";
                    c29.MiddleInitial = "L";
                    c29.Birthday = "24246";
                    c29.StreetAddress = "72361 Bayside Drive";
                    c29.City = "Austin";
                    c29.State = "TX";
                    c29.ZipCode = "78789";

                    c29.Email = "ankaisrad@gogle.com";
                    c29.PhoneNumber = "2182889379";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c29, "radgirl");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c29 = _db.Users.FirstOrDefault(u => u.UserName == "ankaisrad@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c29, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c29, "Customer");
                }
                LastAdded = c29.Email;
                _db.SaveChanges();



                AppUser c30 = _db.Users.FirstOrDefault(u => u.Email == "megrhodes@freserve.co.uk");

                //if manager hasn't been created, then add them
                if (c30 == null)
                {

                    c30 = new AppUser();
                    c30.UserName = "megrhodes@freserve.co.uk";
                    c30.LastName = "Rhodes";
                    c30.FirstName = "Megan";
                    c30.MiddleInitial = "C.";
                    c30.Birthday = "23813";
                    c30.StreetAddress = "76875 Hoffman Point";
                    c30.City = "Orlando";
                    c30.State = "FL";
                    c30.ZipCode = "32830";

                    c30.Email = "megrhodes@freserve.co.uk";
                    c30.PhoneNumber = "9532396075";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c30, "meganr34");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c30 = _db.Users.FirstOrDefault(u => u.UserName == "megrhodes@freserve.co.uk");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c30, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c30, "Customer");
                }
                LastAdded = c30.Email;
                _db.SaveChanges();


                AppUser c31 = _db.Users.FirstOrDefault(u => u.Email == "erynrice@aoll.com");

                //if manager hasn't been created, then add them
                if (c31 == null)
                {

                    c31 = new AppUser();

                    c31.UserName = "erynrice@aoll.com";
                    c31.LastName = "Rice";
                    c31.FirstName = "Eryn";
                    c31.MiddleInitial = "M.";
                    c31.Birthday = "27512";
                    c31.StreetAddress = "048 Elmside Park";
                    c31.City = "South Padre Island";
                    c31.State = "TX";
                    c31.ZipCode = "78597";

                    c31.Email = "erynrice@aoll.com";
                    c31.PhoneNumber = "7303815953";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c31, "ricearoni");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c31 = _db.Users.FirstOrDefault(u => u.UserName == "erynrice@aoll.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c31, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c31, "Customer");
                }
                LastAdded = c31.Email;

                _db.SaveChanges();




                AppUser c32 = _db.Users.FirstOrDefault(u => u.Email == "jorge@noclue.com");

                //if manager hasn't been created, then add them
                if (c32 == null)
                {

                    c32 = new AppUser();


                    c32.UserName = "jorge@noclue.com";
                    c32.LastName = "Rodriguez";
                    c32.FirstName = "Jorge";
                    c32.MiddleInitial = "";
                    c32.Birthday = "19701";
                    c32.StreetAddress = "01 Browning Pass";
                    c32.City = "Austin";
                    c32.State = "TX";
                    c32.ZipCode = "78744";

                    c32.Email = "jorge@noclue.com";
                    c32.PhoneNumber = "3677322422";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c32, "alaskaboy");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c32 = _db.Users.FirstOrDefault(u => u.UserName == "jorge@noclue.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c32, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c32, "Customer");
                }
                LastAdded = c32.Email;
                _db.SaveChanges();




                AppUser c33 = _db.Users.FirstOrDefault(u => u.Email == "mrrogers@lovelyday.com");

                //if manager hasn't been created, then add them
                if (c33 == null)
                {
                    c33 = new AppUser();


                    c33.UserName = "mrrogers@lovelyday.com";
                    c33.LastName = "Rogers";
                    c33.FirstName = "Allen";
                    c33.MiddleInitial = "B.";
                    c33.Birthday = "26776";
                    c33.StreetAddress = "844 Anderson Alley";
                    c33.City = "Canyon Lake";
                    c33.State = "TX";
                    c33.ZipCode = "78133";

                    c33.Email = "mrrogers@lovelyday.com";
                    c33.PhoneNumber = "3911705385";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c33, "bunnyhop");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c33 = _db.Users.FirstOrDefault(u => u.UserName == "mrrogers@lovelyday.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c33, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c33, "Customer");
                }
                LastAdded = c33.Email;

                _db.SaveChanges();



                AppUser c34 = _db.Users.FirstOrDefault(u => u.Email == "stjean@athome.com");

                //if manager hasn't been created, then add them
                if (c34 == null)
                {


                    c34 = new AppUser();


                    c34.UserName = "stjean@athome.com";
                    c34.LastName = "Saint-Jean";
                    c34.FirstName = "Olivier";
                    c34.MiddleInitial = "M";
                    c34.Birthday = "34749";
                    c34.StreetAddress = "1891 Docker Point";
                    c34.City = "Austin";
                    c34.State = "TX";
                    c34.ZipCode = "78779";

                    c34.Email = "stjean@athome.com";
                    c34.PhoneNumber = "7351610920";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c34, "dustydusty");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c34 = _db.Users.FirstOrDefault(u => u.UserName == "stjean@athome.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c34, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c34, "Customer");
                }
                LastAdded = c34.Email;
                _db.SaveChanges();



                AppUser c35 = _db.Users.FirstOrDefault(u => u.Email == "saunders@pen.com");

                //if manager hasn't been created, then add them
                if (c35 == null)
                {


                    c35 = new AppUser();

                    c35.UserName = "saunders@pen.com";
                    c35.LastName = "Saunders";
                    c35.FirstName = "Sarah";
                    c35.MiddleInitial = "J.";
                    c35.Birthday = "28540";
                    c35.StreetAddress = "1469 Upham Road";
                    c35.City = "Austin";
                    c35.State = "TX";
                    c35.ZipCode = "78720";

                    c35.Email = "saunders@pen.com";
                    c35.PhoneNumber = "5269661692";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c35, "jrod2017");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c35 = _db.Users.FirstOrDefault(u => u.UserName == "saunders@pen.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c35, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c35, "Customer");
                }

                LastAdded = c35.Email;

                _db.SaveChanges();



                AppUser c36 = _db.Users.FirstOrDefault(u => u.Email == "willsheff@email.com");

                //if manager hasn't been created, then add them
                if (c36 == null)
                {


                    c36 = new AppUser();

                    c36.UserName = "willsheff@email.com";
                    c36.LastName = "Sewell";
                    c36.FirstName = "William";
                    c36.MiddleInitial = "T.";
                    c36.Birthday = "38344";
                    c36.StreetAddress = "1672 Oak Valley Circle";
                    c36.City = "Austin";
                    c36.State = "TX";
                    c36.ZipCode = "78705";

                    c36.Email = "willsheff@email.com";
                    c36.PhoneNumber = "1875727246";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c36, "martin1234");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c36 = _db.Users.FirstOrDefault(u => u.UserName == "willsheff@email.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c36, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c36, "Customer");
                }
                LastAdded = c36.Email;

                _db.SaveChanges();




                AppUser c37 = _db.Users.FirstOrDefault(u => u.Email == "sheffiled@gogle.com");

                //if manager hasn't been created, then add them
                if (c37 == null)
                {

                    c37 = new AppUser();


                    c37.UserName = "sheffiled@gogle.com";
                    c37.LastName = "Sheffield";
                    c37.FirstName = "Martin";
                    c37.MiddleInitial = "J.";
                    c37.Birthday = "22044";
                    c37.StreetAddress = "816 Kennedy Place";
                    c37.City = "Round Rock";
                    c37.State = "TX";
                    c37.ZipCode = "78680";


                    c37.Email = "sheffiled@gogle.com";
                    c37.PhoneNumber = "1394323615";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c37, "penguin12");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c37 = _db.Users.FirstOrDefault(u => u.UserName == "sheffiled@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c37, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c37, "Customer");
                }
                LastAdded = c37.Email;
                _db.SaveChanges();




                AppUser c38 = _db.Users.FirstOrDefault(u => u.Email == "johnsmith187@aoll.com");

                //if manager hasn't been created, then add them
                if (c38 == null)
                {

                    c38 = new AppUser();


                    c38.UserName = "johnsmith187@aoll.com";
                    c38.LastName = "Smith";
                    c38.FirstName = "John";
                    c38.MiddleInitial = "A";
                    c38.Birthday = "20265";
                    c38.StreetAddress = "0745 Golf Road";
                    c38.City = "Austin";
                    c38.State = "TX";
                    c38.ZipCode = "78760";

                    c38.Email = "johnsmith187@aoll.com";
                    c38.PhoneNumber = "6645937874";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c38, "rogerthat");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c38 = _db.Users.FirstOrDefault(u => u.UserName == "johnsmith187@aoll.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c38, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c38, "Customer");
                }
                LastAdded = c38.Email;
                _db.SaveChanges();



                AppUser c39 = _db.Users.FirstOrDefault(u => u.Email == "dustroud@mail.com");

                //if manager hasn't been created, then add them
                if (c39 == null)
                {
                    c39 = new AppUser();

                    c39.UserName = "dustroud@mail.com";
                    c39.LastName = "Stroud";
                    c39.FirstName = "Dustin";
                    c39.MiddleInitial = "P";
                    c39.Birthday = "24679";
                    c39.StreetAddress = "505 Dexter Plaza";
                    c39.City = "Sweet Home";
                    c39.State = "TX";
                    c39.ZipCode = "77987";

                    c39.Email = "dustroud@mail.com";
                    c39.PhoneNumber = "6470254680";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c39, "smitty444");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c39 = _db.Users.FirstOrDefault(u => u.UserName == "dustroud@mail.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c39, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c39, "Customer");
                }
                LastAdded = c39.Email;
                _db.SaveChanges();



                AppUser c40 = _db.Users.FirstOrDefault(u => u.Email == "estuart@anchor.net");

                //if manager hasn't been created, then add them
                if (c40 == null)
                {

                    c40 = new AppUser();

                    c40.UserName = "estuart@anchor.net";
                    c40.LastName = "Stuart";
                    c40.FirstName = "Eric";
                    c40.MiddleInitial = "D.";
                    c40.Birthday = "17505";
                    c40.StreetAddress = "585 Claremont Drive";
                    c40.City = "Corpus Christi";
                    c40.State = "TX";
                    c40.ZipCode = "78412";

                    c40.Email = "estuart@anchor.net";
                    c40.PhoneNumber = "7701621022";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c40, "stewball");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c40 = _db.Users.FirstOrDefault(u => u.UserName == "estuart@anchor.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c40, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c40, "Customer");
                }
                LastAdded = c40.Email;
                _db.SaveChanges();



                AppUser c41 = _db.Users.FirstOrDefault(u => u.Email == "peterstump@noclue.com");

                //if manager hasn't been created, then add them
                if (c41 == null)
                {
                    c41 = new AppUser();

                    c41.UserName = "peterstump@noclue.com";
                    c41.LastName = "Stump";
                    c41.FirstName = "Peter";
                    c41.MiddleInitial = "L";
                    c41.Birthday = "27220";
                    c41.StreetAddress = "89035 Welch Circle";
                    c41.City = "Pflugerville";
                    c41.State = "TX";
                    c41.ZipCode = "78660";

                    c41.Email = "peterstump@noclue.com";
                    c41.PhoneNumber = "2181960061";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c41, "slowwind");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c41 = _db.Users.FirstOrDefault(u => u.UserName == "peterstump@noclue.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c41, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c41, "Customer");
                }
                LastAdded = c41.Email;

                _db.SaveChanges();



                AppUser c42 = _db.Users.FirstOrDefault(u => u.Email == "jtanner@mustang.net");

                //if manager hasn't been created, then add them
                if (c42 == null)
                {

                    c42 = new AppUser();

                    c42.UserName = "jtanner@mustang.net";
                    c42.LastName = "Tanner";
                    c42.FirstName = "Jeremy";
                    c42.MiddleInitial = "S.";
                    c42.Birthday = "16082";
                    c42.StreetAddress = "4 Stang Trail";
                    c42.City = "Austin";
                    c42.State = "TX";
                    c42.ZipCode = "78702";

                    c42.Email = "jtanner@mustang.net";
                    c42.PhoneNumber = "9908469499";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c42, "tanner5454");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c42 = _db.Users.FirstOrDefault(u => u.UserName == "jtanner@mustang.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c42, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c42, "Customer");
                }
                LastAdded = c42.Email;
                _db.SaveChanges();



                AppUser c43 = _db.Users.FirstOrDefault(u => u.Email == "taylordjay@aoll.com");

                //if manager hasn't been created, then add them
                if (c43 == null)
                {

                    c43 = new AppUser();


                    c43.UserName = "taylordjay@aoll.com";
                    c43.LastName = "Taylor";
                    c43.FirstName = "Allison";
                    c43.MiddleInitial = "R.";
                    c43.Birthday = "33191";
                    c43.StreetAddress = "726 Twin Pines Avenue";
                    c43.City = "Austin";
                    c43.State = "TX";
                    c43.ZipCode = "78713";

                    c43.Email = "taylordjay@aoll.com";
                    c43.PhoneNumber = "7011918647";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c43, "allyrally");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c43 = _db.Users.FirstOrDefault(u => u.UserName == "taylordjay@aoll.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c43, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c43, "Customer");
                }
                LastAdded = c43.Email;
                _db.SaveChanges();




                AppUser c44 = _db.Users.FirstOrDefault(u => u.Email == "rtaylor@gogle.com");

                //if manager hasn't been created, then add them
                if (c44 == null)
                {

                    c44 = new AppUser();


                    c44.UserName = "rtaylor@gogle.com";
                    c44.LastName = "Taylor";
                    c44.FirstName = "Rachel";
                    c44.MiddleInitial = "K.";
                    c44.Birthday = "27777";
                    c44.StreetAddress = "06605 Sugar Drive";
                    c44.City = "Austin";
                    c44.State = "TX";
                    c44.ZipCode = "78712";

                    c44.Email = "rtaylor@gogle.com";
                    c44.PhoneNumber = "8937910053";

                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c44, "taylorbaylor");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c44 = _db.Users.FirstOrDefault(u => u.UserName == "rtaylor@gogle.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c44, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c44, "Customer");
                }
                LastAdded = c44.Email;

                _db.SaveChanges();





                AppUser c45 = _db.Users.FirstOrDefault(u => u.Email == "teefrank@noclue.com");

                //if manager hasn't been created, then add them
                if (c45 == null)
                {

                    c45 = new AppUser();

                    c45.UserName = "teefrank@noclue.com";
                    c45.LastName = "Tee";
                    c45.FirstName = "Frank";
                    c45.MiddleInitial = "J";
                    c45.Birthday = "36044";
                    c45.StreetAddress = "3567 Dawn Plaza";
                    c45.City = "Austin";
                    c45.State = "TX";
                    c45.ZipCode = "78786";

                    c45.Email = "teefrank@noclue.com";
                    c45.PhoneNumber = "6394568913";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c45, "teeoff22");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c45 = _db.Users.FirstOrDefault(u => u.UserName == "teefrank@noclue.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c45, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c45, "Customer");
                }
                LastAdded = c45.Email;
                _db.SaveChanges();




                AppUser c46 = _db.Users.FirstOrDefault(u => u.Email == "ctucker@alphabet.co.uk");

                //if manager hasn't been created, then add them
                if (c46 == null)
                {

                    c46 = new AppUser();


                    c46.UserName = "ctucker@alphabet.co.uk";
                    c46.LastName = "Tucker";
                    c46.FirstName = "Clent";
                    c46.MiddleInitial = "J";
                    c46.Birthday = "15762";
                    c46.StreetAddress = "704 Northland Alley";
                    c46.City = "San Antonio";
                    c46.State = "TX";
                    c46.ZipCode = "78279";

                    c46.Email = "ctucker@alphabet.co.uk";
                    c46.PhoneNumber = "2676838676";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c46, "tucksack1");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c46 = _db.Users.FirstOrDefault(u => u.UserName == "ctucker@alphabet.co.uk");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c46, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c46, "Customer");
                }

                LastAdded = c46.Email;

                _db.SaveChanges();




                AppUser c47 = _db.Users.FirstOrDefault(u => u.Email == "avelasco@yoho.com");

                //if manager hasn't been created, then add them
                if (c47 == null)
                {

                    c47 = new AppUser();

                    c47.UserName = "avelasco@yoho.com";
                    c47.LastName = "Velasco";
                    c47.FirstName = "Allen";
                    c47.MiddleInitial = "G";
                    c47.Birthday = "31300";
                    c47.StreetAddress = "72 Harbort Point";
                    c47.City = "Navasota";
                    c47.State = "TX";
                    c47.ZipCode = "77868";

                    c47.Email = "avelasco@yoho.com";
                    c47.PhoneNumber = "3452909754";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c47, "meow88");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c47 = _db.Users.FirstOrDefault(u => u.UserName == "avelasco@yoho.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c47, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c47, "Customer");
                }
                LastAdded = c47.Email;
                _db.SaveChanges();




                AppUser c48 = _db.Users.FirstOrDefault(u => u.Email == "vinovino@grapes.com");

                //if manager hasn't been created, then add them
                if (c48 == null)
                {


                    c48 = new AppUser();

                    c48.UserName = "vinovino@grapes.com";
                    c48.LastName = "Vino";
                    c48.FirstName = "Janet";
                    c48.MiddleInitial = "E";
                    c48.Birthday = "31085";
                    c48.StreetAddress = "1 Oak Valley Place";
                    c48.City = "Boston";
                    c48.State = "MA";
                    c48.ZipCode = "02114";

                    c48.Email = "vinovino@grapes.com";
                    c48.PhoneNumber = "8567089194";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c48, "vinovino");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c48 = _db.Users.FirstOrDefault(u => u.UserName == "vinovino@grapes.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c48, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c48, "Customer");
                }

                LastAdded = c48.Email;

                _db.SaveChanges();




                AppUser c49 = _db.Users.FirstOrDefault(u => u.Email == "westj@pioneer.net");

                //if manager hasn't been created, then add them
                if (c49 == null)
                {

                    c49 = new AppUser();


                    c49.UserName = "westj@pioneer.net";
                    c49.LastName = "West";
                    c49.FirstName = "Jake";
                    c49.MiddleInitial = "T";
                    c49.Birthday = "27768";
                    c49.StreetAddress = "48743 Banding Parkway";
                    c49.City = "Marble Falls";
                    c49.State = "TX";
                    c49.ZipCode = "78654";

                    c49.Email = "westj@pioneer.net";
                    c49.PhoneNumber = "6260784394";


                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c49, "gowest");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c49 = _db.Users.FirstOrDefault(u => u.UserName == "westj@pioneer.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c49, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c49, "Customer");
                }
                LastAdded = c49.Email;

                _db.SaveChanges();


                AppUser c50 = _db.Users.FirstOrDefault(u => u.Email == "winner@hootmail.com");

                //if manager hasn't been created, then add them
                if (c50 == null)
                {

                    c50 = new AppUser();
                    c50.UserName = "winner@hootmail.com";
                    c50.LastName = "Winthorpe";
                    c50.FirstName = "Louis";
                    c50.MiddleInitial = "L";
                    c50.Birthday = "19468";
                    c50.StreetAddress = "96850 Summit Crossing";
                    c50.City = "Austin";
                    c50.State = "TX";
                    c50.ZipCode = "78730";

                    c50.Email = "winner@hootmail.com";
                    c50.PhoneNumber = "3733971174";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c50, "louielouie");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c50 = _db.Users.FirstOrDefault(u => u.UserName == "winner@hootmail.com");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c50, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c50, "Customer");
                }
                LastAdded = c50.Email;

                _db.SaveChanges();



                AppUser c51 = _db.Users.FirstOrDefault(u => u.Email == "rwood@voyager.net");

                //if manager hasn't been created, then add them
                if (c51 == null)
                {

                    c51 = new AppUser();


                    c51.UserName = "rwood@voyager.net";
                    c51.LastName = "Wood";
                    c51.FirstName = "Reagan";
                    c51.MiddleInitial = "B.";
                    c51.Birthday = "37618";
                    c51.StreetAddress = "18354 Bluejay Street";
                    c51.City = "Austin";
                    c51.State = "TX";
                    c51.ZipCode = "78712";

                    c51.Email = "rwood@voyager.net";
                    c51.PhoneNumber = "8433359800";



                    //NOTE: Ask the user manager to create the new user
                    //The second parameter for .CreateAsync is the user's password
                    var result = await _userManager.CreateAsync(c51, "woodyman1");
                    Count += 1;
                    if (result.Succeeded == false)
                    {
                        throw new Exception("This user can't be added - " + result.ToString());
                    }
                    _db.SaveChanges();
                    c51 = _db.Users.FirstOrDefault(u => u.UserName == "rwood@voyager.net");
                }

                //make sure user is in role
                if (await _userManager.IsInRoleAsync(c51, "Customer") == false)
                {
                    await _userManager.AddToRoleAsync(c51, "Customer");
                }

                LastAdded = c51.Email;
                _db.SaveChanges();

            }
            catch (Exception e)
            {
                String msg = "We have added " + Count + " users.  The last added is" + LastAdded;
                InvalidOperationException z2 = new InvalidOperationException(msg, e);
                Console.WriteLine(msg);
                throw z2;
            }




    }

    }
}