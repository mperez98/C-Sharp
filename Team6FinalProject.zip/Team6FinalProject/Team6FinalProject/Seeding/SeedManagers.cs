﻿using Team6FinalProject.Models;
using Team6FinalProject.DAL;
using System.Collections.Generic;
using System;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

namespace Team6FinalProject.Seeding
{
        public static class SeedManagers
        {
            public static void SeedingManagers(AppDbContext db)
            {
                Int32 intManagersAdded = 0;
                String ManagerName = "Begin"; //helps to keep track of error on repos                 List<AppUser> AppUsers = new List<AppUser>();

                try
                {

                AppUser m1 = new AppUser();
                m1.LastName = "Baker";
                m1.FirstName = "Christopher";
                m1.MiddleInitial = "E";
                m1.StreetAddress = "1245 Lake Libris Dr.";
                m1.City = "Cedar Park";
                m1.State = "TX";
                m1.ZipCode = "78613";
                m1.PhoneNumber = "3395325649";
                m1.Email = "c.baker@bevosbooks.com";
               
                //creating the user 
                var result = await _userManager.CreateAsync(m1, "dewey4");

                if (result.Succeeded == false)
                {
                    throw new Exception("This user can't be added - " + result.ToString());
                }
                

                if (await _userManager.IsInRoleAsync(manager, "Manager") == false)
                {
                    await _userManager.AddToRoleAsync(manager, "Manager");
                }
                _db.SaveChanges();

                AppUser m2 = new AppUser();
                m2.LastName = "Rice";
                m2.FirstName = "Eryn";
                m2.MiddleInitial = "M";
                m2.StreetAddress = "3405 Rio Grande";
                m2.City = "Austin";
                m2.State = "TX";
                m2.ZipCode = "78746";
                m2.PhoneNumber = "270660503";
                m2.Email = "e.rice@bevosbooks.com";
                

               result = await _userManager.CreateAsync(m2, "arched");

                if (result.Succeeded == false)
                {
                    throw new Exception("This user can't be added - " + result.ToString());
                }
                _db.SaveChanges();


                AppUser m3 = new AppUser();
                m3.LastName = "Rogers";
                m3.FirstName = "Allen";
                m3.MiddleInitial = "H";
                m3.StreetAddress = "4965 Oak Hill";
                m3.City = "Austin";
                m3.State = "TX";
                m3.ZipCode = "78705";
                m3.PhoneNumber = "4139645586";
                m3.Email = "a.rogers@bevosbooks.com";
                // AppUsers.Add(b3);


                var result = await _userManager.CreateAsync(b3, "lottery");

                if (result.Succeeded == false)
                {
                    throw new Exception("This user can't be added - " + result.ToString());
                }
                _db.SaveChanges();



                AppUser m4 = new AppUser();
                m4.LastName = "Sewell";
                m4.FirstName = "William";
                m4.MiddleInitial = "G";

                m4.StreetAddress = "2365 51st St.";
                m4.City = "Austin";
                m4.State = "TX";
                m4.ZipCode = "78755";
                m4.PhoneNumber = "744308314";
                m4.Email = "w.sewell@bevosbooks.com";
                // AppUsers.Add(b4);

                var result = await _userManager.CreateAsync(b4, "offbeat");

                if (result.Succeeded == false)
                {
                    throw new Exception("This user can't be added - " + result.ToString());
                }
                _db.SaveChanges();


                AppUser m5 = new AppUser();
                m5.LastName = "Taylor";
                m5.FirstName = "Rachel";
                m5.MiddleInitial = "O";
                m5.StreetAddress = "345 Longview Dr.";
                m5.City = "Austin";
                m5.State = "TX";
                m5.ZipCode = "78746";
                m5.PhoneNumber = "9071236087";
                m5.Email = "r.taylor@bevosbooks.com";
                //AppUsers.Add(b5);


                var result = await _userManager.CreateAsync(m5, "landus");

                if (result.Succeeded == false)
                {
                    throw new Exception("This user can't be added - " + result.ToString());
                }
                _db.SaveChanges();



                //loop through repos
                foreach (AppUser aAppUser in AppUsers)
                {
                    //set name of repo to help debug
                    AppUserPhoneNumber = aAppUser.PhoneNumber;

                    //see if repo exists in database
                    AppUser dbAppUser = db.AppUsers.FirstOrDefault(r => r.PhoneNumber == aAppUser.PhoneNumber);

                    if (dbAppUser == null) //Employee does not exist in database
                    {
                        db.AppUsers.Add(aAppUser);
                        db.SaveChanges();
                        intManagersAdded += 1;
                    }
                    else
                    {
                        dbAppUser.LastName = aAppUser.LastName;
                        dbAppUser.FirstName = aAppUser.FirstName;
                        dbAppUser.MiddleInitial = aAppUser.MiddleInitial;



                        dbAppUser.StreetAddress = aAppUser.StreetAddress;
                        dbAppUser.City = aAppUser.City;
                        dbAppUser.State = aAppUser.State;
                        dbAppUser.ZipCode = aAppUser.ZipCode;

                        dbAppUser.PhoneNumber = aAppUser.PhoneNumber;
                        dbAppUser.Email = aAppUser.Email;
                        db.Update(dbAppUser);
                        db.SaveChanges();
                    }
                }

            }
            catch
            {
            

                {
                    String msg = "Managers added:" + intManagersAdded + "; Error on " + AppUserPhoneNumber;
                    throw new InvalidOperationException(msg);
                }
            }
        }
    }
}
                
  