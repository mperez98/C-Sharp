﻿using Team6FinalProject.Models;
using Team6FinalProject.DAL;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Team6FinalProject.Seeding
{
    public static class SeedEmployees
    {
        public static void SeedAllEmployees(AppDbContext db)
        {
          

            Int32 intEmployeesAdded = 0;
            String AppUserPhoneNumber = "Begin"; //helps to keep track of error on repos
            List<AppUser> AppUsers = new List<AppUser>();

            try
            {
                
                AppUser b1 = new AppUser();
                b1.LastName = "Barnes";
                b1.FirstName = "Susan";
                b1.MiddleInitial = "M";
               // b1.Password = "smitty";
              
               
                b1.StreetAddress = "888 S. Main";
                b1.City = "Kyle";
                b1.State = "TX";
                b1.ZipCode = "78640";
                b1.PhoneNumber = "9636389416";
                b1.Email = "s.barnes@bevosbooks.com";
                AppUsers.Add(b1);

                AppUser b3 = new AppUser();
                b3.LastName = "Garcia";
                b3.FirstName = "Hector";
                b3.MiddleInitial = "W";
                //   b3.Password = "squirrel";


                b3.StreetAddress = "777 PBR Drive";
                b3.City = "Austin";
                b3.State = "TX";
                b3.ZipCode = "78712";
                b3.PhoneNumber = "4547135738";
                b3.Email = "h.garcia@bevosbooks.com";
                AppUsers.Add(b3);

                AppUser b4 = new AppUser();
                b4.LastName = "Ingram";
                b4.FirstName = "Brad";
                b4.MiddleInitial = "S";
                // b4.Password = "changalang";


                b4.StreetAddress = "6548 La Posada Ct.";
                b4.City = "Austin";
                b4.State = "TX";
                b4.ZipCode = "78705";
                b4.PhoneNumber = "5817343315";
                b4.Email = "b.ingram@bevosbooks.com";
                AppUsers.Add(b4);

                AppUser b5 = new AppUser();
                b5.LastName = "Jackson";
                b5.FirstName = "Jack";
                b5.MiddleInitial = "J";
                // b5.Password = "rhythm";


                b5.StreetAddress = "222 Main";
                b5.City = "Austin";
                b5.State = "TX";
                b5.ZipCode = "78760";
                b5.PhoneNumber = "8241915317";
                b5.Email = "j.jackson@bevosbooks.com";
                AppUsers.Add(b5);

                AppUser b6 = new AppUser();
                b6.LastName = "Jacobs";
                b6.FirstName = "Todd";
                b6.MiddleInitial = "L";
                //  b6.Password = "approval";


                b6.StreetAddress = "4564 Elm St.";
                b6.City = "Georgetown";
                b6.State = "TX";
                b6.ZipCode = "78628";
                b6.PhoneNumber = "2477822475";
                b6.Email = "t.jacobs@bevosbooks.com";
                AppUsers.Add(b6);

                AppUser b7 = new AppUser();
                b7.LastName = "Jones";
                b7.FirstName = "Lester";
                b7.MiddleInitial = "L";
                b7.Password = "society";
              
                b7.StreetAddress = "999 LeBlat";
                b7.City = "Austin";
                b7.State = "TX";
                b7.ZipCode = "78747";
                b7.PhoneNumber = "4764966462";
                b7.Email = "l.jones@bevosbooks.com";
                AppUsers.Add(b7);

                AppUser b8 = new AppUser();
                b8.LastName = "Larson";
                b8.FirstName = "Bill";
                b8.MiddleInitial = "B";
                b8.Password = "tanman";
              
               
                b8.StreetAddress = "1212 N. First Ave";
                b8.City = "Round Rock";
                b8.State = "TX";
                b8.ZipCode = "78665";
                b8.PhoneNumber = "3355258855";
                b8.Email = "b.larson@bevosbooks.com";
                AppUsers.Add(b8);

                AppUser b9 = new AppUser();
                b9.LastName = "Lawrence";
                b9.FirstName = "Victoria";
                b9.MiddleInitial = "Y";
                b9.Password = "longhorns";
          
                b9.StreetAddress = "6639 Bookworm Ln.";
                b9.City = "Austin";
                b9.State = "TX";
                b9.ZipCode = "78712";
                b9.PhoneNumber = "7511273054";
                b9.Email = "v.lawrence@bevosbooks.com";
                AppUsers.Add(b9);

                AppUser b10 = new AppUser();
                b10.LastName = "Lopez";
                b10.FirstName = "Marshall";
                b10.MiddleInitial = "T";
                b10.Password = "swansong";
               
              
                b10.StreetAddress = "90 SW North St";
                b10.City = "Austin";
                b10.State = "TX";
                b10.ZipCode = "78729";
                b10.PhoneNumber = "7477907070";
                b10.Email = "m.lopez@bevosbooks.com";
                AppUsers.Add(b10);

                AppUser b11 = new AppUser();
                b11.LastName = "MacLeod";
                b11.FirstName = "Jennifer";
                b11.MiddleInitial = "D";
                b11.Password = "fungus";
                
            
                b11.StreetAddress = "2504 Far West Blvd.";
                b11.City = "Austin";
                b11.State = "TX";
                b11.ZipCode = "78705";
                b11.PhoneNumber = "2621216845";
                b11.Email = "j.macleod@bevosbooks.com";
                AppUsers.Add(b11);

                AppUser b12 = new AppUser();
                b12.LastName = "Markham";
                b12.FirstName = "Elizabeth";
                b12.MiddleInitial = "K";
                b12.Password = "median";
             
                b12.StreetAddress = "7861 Chevy Chase";
                b12.City = "Austin";
                b12.State = "TX";
                b12.ZipCode = "78785";
                b12.PhoneNumber = "5028075807";
                b12.Email = "e.markham@bevosbooks.com";
                AppUsers.Add(b12);

                AppUser b13 = new AppUser();
                b13.LastName = "Martinez";
                b13.FirstName = "Gregory";
                b13.MiddleInitial = "R";
                b13.Password = "decorate";
            

                b13.StreetAddress = "8295 Sunset Blvd.";
                b13.City = "Austin";
                b13.State = "TX";
                b13.ZipCode = "78712";
                b13.PhoneNumber = "1994708542";
                b13.Email = "g.martinez@bevosbooks.com";
                AppUsers.Add(b13);

                AppUser b14 = new AppUser();
                b14.LastName = "Mason";
                b14.FirstName = "Jack";
                b14.MiddleInitial = "L";
                b14.Password = "rankmary";
               
                
                b14.StreetAddress = "444 45th St";
                b14.City = "Austin";
                b14.State = "TX";
                b14.ZipCode = "78701";
                b14.PhoneNumber = "1748136441";
                b14.Email = "j.mason@bevosbooks.com";
                AppUsers.Add(b14);

                AppUser b15 = new AppUser();
                b15.LastName = "Miller";
                b15.FirstName = "Charles";
                b15.MiddleInitial = "R";
                b15.Password = "kindly";
              
             
                b15.StreetAddress = "8962 Main St.";
                b15.City = "Austin";
                b15.State = "TX";
                b15.ZipCode = "78709";
                b15.PhoneNumber = "8999319585";
                b15.Email = "c.miller@bevosbooks.com";
                AppUsers.Add(b15);

                AppUser b16 = new AppUser();
                b16.LastName = "Nguyen";
                b16.FirstName = "Mary";
                b16.MiddleInitial = "J";
                b16.Password = "ricearoni";
          
                b16.StreetAddress = "465 N. Bear Cub";
                b16.City = "Austin";
                b16.State = "TX";
                b16.ZipCode = "78734";
                b16.PhoneNumber = "8716746381";
                b16.Email = "m.nguyen@bevosbooks.com";
                AppUsers.Add(b16);

                AppUser b17 = new AppUser();
                b17.LastName = "Rankin";
                b17.FirstName = "Suzie";
                b17.MiddleInitial = "R";
                b17.Password = "walkamile";
               
                
                b17.StreetAddress = "23 Dewey Road";
                b17.City = "Austin";
                b17.State = "TX";
                b17.ZipCode = "78712";
                b17.PhoneNumber = "5239029525";
                b17.Email = "s.rankin@bevosbooks.com";
                AppUsers.Add(b17);

                AppUser b18 = new AppUser();
                b18.LastName = "Rhodes";
                b18.FirstName = "Megan";
                b18.MiddleInitial = "C";
                b18.Password = "ingram45";
              
              
                b18.StreetAddress = "4587 Enfield Rd.";
                b18.City = "Austin";
                b18.State = "TX";
                b18.ZipCode = "78729";
                b18.PhoneNumber = "1232139514";
                b18.Email = "m.rhodes@bevosbooks.com";
                AppUsers.Add(b18);

                
               
                AppUser b21 = new AppUser();
                b21.LastName = "Saunders";
                b21.FirstName = "Sarah";
                b21.MiddleInitial = "M";
                b21.Password = "nostalgic";
            
           
                b21.StreetAddress = "332 Avenue C";
                b21.City = "Austin";
                b21.State = "TX";
                b21.ZipCode = "78733";
                b21.PhoneNumber = "9036349587";
                b21.Email = "s.saunders@bevosbooks.com";
                AppUsers.Add(b21);


                AppUser b23 = new AppUser();
                b23.LastName = "Sheffield";
                b23.FirstName = "Martin";
                b23.MiddleInitial = "J";
                b23.Password = "evanescent";
              
             
                b23.StreetAddress = "3886 Avenue A";
                b23.City = "San Marcos";
                b23.State = "TX";
                b23.ZipCode = "78666";
                b23.PhoneNumber = "9349192978";
                b23.Email = "m.sheffield@bevosbooks.com";
                AppUsers.Add(b23);

                AppUser b24 = new AppUser();
                b24.LastName = "Silva";
                b24.FirstName = "Cindy";
                b24.MiddleInitial = "S";
                b24.Password = "stewboy";
            
                
                b24.StreetAddress = "900 4th St";
                b24.City = "Austin";
                b24.State = "TX";
                b24.ZipCode = "78758";
                b24.PhoneNumber = "4874328170";
                b24.Email = "c.silva@bevosbooks.com";
                AppUsers.Add(b24);

                AppUser b25 = new AppUser();
                b25.LastName = "Stuart";
                b25.FirstName = "Eric";
                b25.MiddleInitial = "F";
                b25.Password = "instrument";
             

                b25.StreetAddress = "5576 Toro Ring";
                b25.City = "Austin";
                b25.State = "TX";
                b25.ZipCode = "78758";
                b25.PhoneNumber = "1967846827";
                b25.Email = "e.stuart@bevosbooks.com";
                AppUsers.Add(b25);

                AppUser b26 = new AppUser();
                b26.LastName = "Tanner";
                b26.FirstName = "Jeremy";
                b26.MiddleInitial = "S";
                b26.Password = "hecktour";
              
               
                b26.StreetAddress = "4347 Almstead";
                b26.City = "Austin";
                b26.State = "TX";
                b26.ZipCode = "78712";
                b26.PhoneNumber = "5923026779";
                b26.Email = "j.tanner@bevosbooks.com";
                AppUsers.Add(b26);

                AppUser b27 = new AppUser();
                b27.LastName = "Taylor";
                b27.FirstName = "Allison";
                b27.MiddleInitial = "R";
                b27.Password = "countryrhodes";
              
                b27.StreetAddress = "467 Nueces St.";
                b27.City = "Austin";
                b27.State = "TX";
                b27.ZipCode = "78727";
                b27.PhoneNumber = "7246195827";
                b27.Email = "a.taylor@bevosbooks.com";
                AppUsers.Add(b27);

              


                //loop through repos
                foreach (AppUser aAppUser in AppUsers)
                {
                    //set name of repo to help debug
                    AppUserPhoneNumber = aAppUser.PhoneNumber;

                    //see if repo exists in database
                    AppUser dbAppUser = db.AppUsers.FirstOrDefault(r => r.PhoneNumber == aAppUser.PhoneNumber);

                    if (dbAppUser == null) //Employee does not exist in database
                    {
                        db.AppUsers.Add(aAppUser);
                        db.SaveChanges();
                        intEmployeesAdded += 1;
                    }
                    else
                    {
                        dbAppUser.LastName = aAppUser.LastName;
                        dbAppUser.FirstName = aAppUser.FirstName;
                        dbAppUser.MiddleInitial = aAppUser.MiddleInitial;
                        dbAppUser.Password = aAppUser.Password;

   
                        dbAppUser.StreetAddress = aAppUser.StreetAddress;
                        dbAppUser.City = aAppUser.City;
                        dbAppUser.State = aAppUser.State;
                        dbAppUser.ZipCode = aAppUser.ZipCode;

                        dbAppUser.PhoneNumber = aAppUser.PhoneNumber;
                        dbAppUser.Email = aAppUser.Email;
                        db.Update(dbAppUser);
                        db.SaveChanges();
                    }
                }
            }
            catch
            {
                String msg = "Employees added:" + intEmployeesAdded + "; Error on " + AppUserPhoneNumber;
                throw new InvalidOperationException(msg);
            }
        }
    }
}
